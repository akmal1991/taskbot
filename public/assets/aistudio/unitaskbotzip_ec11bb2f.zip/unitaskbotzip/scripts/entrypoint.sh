#!/usr/bin/env sh
# Container entrypoint. Always applies pending Alembic migrations first (so a
# fresh DB or an upgraded image never starts against a stale schema), then
# launches whichever process this container is for.
#
# Usage: entrypoint.sh {bot|web|migrate}
set -e

echo "[entrypoint] waiting for database and applying migrations..."
# A fresh `docker compose up` can start this container before Postgres is
# actually accepting connections even though the `depends_on: condition:
# service_healthy` gate passed, so retry briefly rather than crash-looping.
attempt=0
until alembic upgrade head; do
  attempt=$((attempt + 1))
  if [ "$attempt" -ge 10 ]; then
    echo "[entrypoint] migrations still failing after $attempt attempts, giving up"
    exit 1
  fi
  echo "[entrypoint] migration attempt $attempt failed, retrying in 3s..."
  sleep 3
done
echo "[entrypoint] migrations applied."

case "$1" in
  bot)
    echo "[entrypoint] starting Telegram bot + scheduler..."
    exec python -m app.bot.main
    ;;
  web)
    echo "[entrypoint] starting web dashboard..."
    exec uvicorn app.web.main:app --host "${WEB_HOST:-0.0.0.0}" --port "${WEB_PORT:-8080}"
    ;;
  migrate)
    echo "[entrypoint] migrate-only mode, exiting."
    exit 0
    ;;
  *)
    echo "Usage: entrypoint.sh {bot|web|migrate}" >&2
    exit 1
    ;;
esac

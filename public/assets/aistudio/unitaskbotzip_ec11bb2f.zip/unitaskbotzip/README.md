# ToshTech Task Management & Executive Monitoring Bot

A Telegram bot (+ optional web dashboard) that replaces
Excel-based task tracking with a database-driven system of record for task
creation, assignment, progress tracking, deadline monitoring, escalation,
and executive reporting.

PostgreSQL is the single source of truth. Excel is supported only as an
import/export format (bringing in an existing register, exporting a report
for a meeting) — not as the thing the system runs on.

## What's here

```
app/
  bot/            Telegram bot: handlers, FSM wizards, i18n, keyboards, scheduler-fed notifier
  web/             FastAPI executive dashboard (Telegram-token login, no passwords)
  core/            Settings, DB engine/session plumbing
  models/          SQLAlchemy ORM models
  services/        Business logic: RBAC, task lifecycle, escalation, reminders, audit, excel I/O
  scheduler/       APScheduler job definitions + wiring
  excel_io/        Excel import/export
migrations/        Alembic migrations (async)
tests/             PostgreSQL integration tests + isolated Telegram delivery tests
docker/            Dockerfile
docker-compose.yml Full stack: db, redis, migrate (one-shot), bot, web
main.py            Combined single-process entrypoint (Replit, or any one-command host)
.replit            Replit configuration
docs/              Architecture, admin manual, user manual, backup & recovery, Replit & VPS guides
```

## Quick start (Replit)

If you're deploying on [Replit](https://replit.com), skip straight to
[`docs/REPLIT_SETUP.md`](docs/REPLIT_SETUP.md) — it covers importing the
project, adding a Postgres database, setting Secrets, and keeping it
running 24/7 via Replit Deployments. `main.py` + `.replit` already do the
work of running the bot, scheduler, and web dashboard together as the one
process a Repl expects.

For this imported workspace, dependencies and the development database are
already configured. Save a fresh `BOT_TOKEN` securely, set the administrator's
numeric `BOOTSTRAP_SUPER_ADMIN_TELEGRAM_ID`, and click **Run**. Never paste
tokens into chat or source code. The dashboard's session key uses the existing
`SESSION_SECRET` unless `WEB_SECRET_KEY` is explicitly supplied.

Audit fixes, verification results, and known verification limits are recorded
in [`docs/AUDIT_RESULTS.md`](docs/AUDIT_RESULTS.md).

## Quick start (a VPS, no Docker)

See [`docs/VPS_SETUP_NO_DOCKER.md`](docs/VPS_SETUP_NO_DOCKER.md) for the
full copy-paste sequence on a plain Ubuntu server: installing
Postgres/Redis/Python natively and running the bot + dashboard as two
systemd services (`scripts/systemd/`) so they survive reboots.

## Quick start (Docker Compose)

```bash
cp .env.example .env
# edit .env: set a real BOT_TOKEN, a strong POSTGRES_PASSWORD / WEB_SECRET_KEY,
# your real WEB_BASE_URL, and BOOTSTRAP_SUPER_ADMIN_TELEGRAM_ID (see docs/ADMIN_MANUAL.md)

docker compose up -d --build
docker compose logs -f bot   # confirm it connects and starts polling
```

This starts four containers: `db` (Postgres 16), `redis`, a one-shot
`migrate` job that applies Alembic migrations, `bot` (polling + scheduler),
and `web` (the dashboard on `WEB_PORT`, default 8080).

**Note on this repository's own test environment:** development and the
full automated test suite (50 tests, see `tests/`) ran against a real
Postgres 16 + Redis 7 instance running directly in the sandbox used to build
this project — not inside Docker. The Docker Compose configuration itself
was written and validated for syntax (`docker compose config`), but this
sandbox's network policy blocks pulling base images from Docker Hub
(`registry-1.docker.io`) *and* connecting to `api.telegram.org` outright, so
neither the containerized stack nor a live bot could be run end-to-end in
*this* environment. Both work normally on any host with ordinary internet
access — see `docs/DEPLOYMENT.md`, `docs/VPS_SETUP_NO_DOCKER.md`, or
`docs/REPLIT_SETUP.md` depending on where you're deploying.

## Quick start (without Docker, for local development)

```bash
python3.13 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt -r requirements-dev.txt

# Postgres + Redis must be reachable at the URLs in .env
alembic upgrade head

python -m app.bot.main          # bot + scheduler
uvicorn app.web.main:app --reload --port 8080   # dashboard, in another shell
```

## Tests

```bash
pytest -q
```

All 50 tests run against a real, migrated Postgres database (`DATABASE_URL`
pointed at a `_test` database by `tests/conftest.py`) — none of the service
layer, lifecycle rules, escalation logic, RBAC, audit logging, Excel
import/export, or web dashboard is mocked.

## Documentation

- [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) — system design, data model, decisions made and why
- [`docs/ADMIN_MANUAL.md`](docs/ADMIN_MANUAL.md) — first-run setup, registration approval, roles, escalation config
- [`docs/USER_MANUAL.md`](docs/USER_MANUAL.md) — day-to-day bot usage for every role
- [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md) — deployment checklist, external services required, what to verify
- [`docs/REPLIT_SETUP.md`](docs/REPLIT_SETUP.md) — running on Replit specifically
- [`docs/VPS_SETUP_NO_DOCKER.md`](docs/VPS_SETUP_NO_DOCKER.md) — running on a plain Ubuntu VPS, no Docker
- [`docs/BACKUP_RECOVERY.md`](docs/BACKUP_RECOVERY.md) — backup strategy and tested restore procedure

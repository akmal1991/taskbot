"""Configuration checks that run without a database.

Run: python -m unittest discover -s tests -p test_replit_config.py
"""
import unittest
from unittest.mock import patch

from sqlalchemy.engine import make_url

from app.core.config import Settings


class ReplitConfigTests(unittest.TestCase):
    def test_bootstrap_accepts_myid_reply_and_blank(self):
        self.assertEqual(
            Settings(_env_file=None, bootstrap_super_admin_telegram_id="Telegram ID: 123456").bootstrap_super_admin_telegram_id,
            123456,
        )
        self.assertIsNone(Settings(_env_file=None, bootstrap_super_admin_telegram_id=" ").bootstrap_super_admin_telegram_id)

    def test_standard_botfather_reply_with_one_token_is_unambiguous(self):
        token = "123456:" + "x" * 35
        reply = f"Use this token to access the HTTP API:\n{token}\n\n@sample_bot"
        self.assertEqual(Settings(_env_file=None, bot_token=reply).bot_token, token)

    def test_multiple_tokens_in_reply_are_not_guessed(self):
        reply = "Use this token to access the HTTP API:\n" + "123456:" + "x" * 35 + "\n" + "654321:" + "y" * 35
        self.assertEqual(Settings(_env_file=None, bot_token=reply).bot_token, reply)

    def test_copied_token_trims_only_surrounding_whitespace(self):
        settings = Settings(_env_file=None, bot_token=" \n123456:test-only-token\n ")
        self.assertEqual(settings.bot_token, "123456:test-only-token")
        self.assertEqual(
            Settings(_env_file=None, bot_token="123456:has embedded space").bot_token,
            "123456:has embedded space",
        )

    def test_postgres_scheme_and_tls_mode(self):
        settings = Settings(
            _env_file=None,
            database_url="postgres://demo:example@db.example/app?sslmode=require",
        )
        url = make_url(settings.database_url)
        self.assertEqual(url.drivername, "postgresql+asyncpg")
        self.assertEqual(url.query, {"ssl": "require"})

    def test_encoded_password_and_other_options_survive(self):
        settings = Settings(
            _env_file=None,
            database_url=(
                "postgresql://demo:p%40ss%25word@db.example/app"
                "?sslmode=verify-full&application_name=taskbot"
            ),
        )
        url = make_url(settings.database_url)
        self.assertEqual(url.password, "p@ss%word")
        self.assertEqual(url.query["ssl"], "verify-full")
        self.assertEqual(url.query["application_name"], "taskbot")

    def test_explicit_asyncpg_ssl_option_wins(self):
        settings = Settings(
            _env_file=None,
            database_url="postgresql+asyncpg://demo:example@db.example/app?ssl=require&sslmode=prefer",
        )
        self.assertEqual(make_url(settings.database_url).query, {"ssl": "require"})

    def test_session_secret_alias_and_override(self):
        with patch.dict("os.environ", {"SESSION_SECRET": "unit-test-only"}, clear=True):
            self.assertEqual(Settings(_env_file=None).web_secret_key, "unit-test-only")
            self.assertEqual(
                Settings(_env_file=None, web_secret_key="explicit-test-key").web_secret_key,
                "explicit-test-key",
            )

    def test_development_link_and_explicit_url(self):
        with patch.dict("os.environ", {"REPLIT_DEV_DOMAIN": "demo.replit.dev"}, clear=True):
            self.assertEqual(Settings(_env_file=None).web_base_url, "https://demo.replit.dev")
            self.assertEqual(
                Settings(_env_file=None, web_base_url="https://tasks.example.edu").web_base_url,
                "https://tasks.example.edu",
            )

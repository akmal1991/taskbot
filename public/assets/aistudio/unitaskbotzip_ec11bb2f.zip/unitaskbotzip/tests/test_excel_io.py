from __future__ import annotations

import datetime as dt
import os
import tempfile

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from app.excel_io.export import build_register_workbook
from app.excel_io.import_ import import_register
from app.models.enums import Priority, TaskStatus, UserRole
from app.services import tasks as task_service
from app.services.permissions import Actor
from tests.factories import make_department, make_user


async def _actor(user) -> Actor:
    return Actor.from_user(user)


@pytest.mark.asyncio
async def test_export_then_import_round_trip_preserves_public_code(session: AsyncSession):
    dept = await make_department(session, name="Ilmiy bo'lim")
    manager = await make_user(session, role=UserRole.VICE_RECTOR, full_name="Vice Rector Test")
    employee = await make_user(session, role=UserRole.EMPLOYEE, full_name="Employee Test", department_id=dept.id)

    task = await task_service.create_task(
        session, actor=await _actor(manager), title="Export me", description="desc", expected_outcome=None,
        acceptance_criteria=None, source_reference=None, department_id=dept.id,
        primary_responsible_id=employee.id, priority=Priority.HIGH,
        deadline=dt.date.today() + dt.timedelta(days=10),
    )
    await session.commit()

    wb = await build_register_workbook(session)
    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as f:
        path = f.name
    wb.save(path)

    try:
        # Mutate the exported file's progress value, then re-import: it should
        # UPDATE the existing task (matched by Public Code), not duplicate it.
        import openpyxl

        wb2 = openpyxl.load_workbook(path)
        ws = wb2.active
        header = {c.value: c.column for c in ws[1]}
        ws.cell(row=2, column=header["Progress %"], value=42)
        wb2.save(path)

        admin = await make_user(session, role=UserRole.SUPER_ADMIN, full_name="Importer")
        report = await import_register(session, actor=await _actor(admin), file_path=path)
        await session.commit()

        assert report.created == 0
        assert report.updated == 1
        assert report.errors == []

        refreshed = await task_service.get_task(session, task.id)
        assert refreshed.progress_percent == 42
        assert refreshed.public_code == task.public_code
    finally:
        os.unlink(path)


@pytest.mark.asyncio
async def test_import_creates_new_tasks_and_auto_creates_department(session: AsyncSession):
    admin = await make_user(session, role=UserRole.SUPER_ADMIN, full_name="Importer2")

    import openpyxl
    from app.excel_io.columns import COLUMNS

    wb = openpyxl.Workbook()
    ws = wb.active
    for i, name in enumerate(COLUMNS, start=1):
        ws.cell(row=1, column=i, value=name)
    header = {name: i + 1 for i, name in enumerate(COLUMNS)}
    ws.cell(row=2, column=header["Title"], value="Brand new imported task")
    ws.cell(row=2, column=header["Department"], value="Yangi bo'lim (import orqali)")
    ws.cell(row=2, column=header["Priority"], value="high")
    ws.cell(row=2, column=header["Status"], value="created")

    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as f:
        path = f.name
    wb.save(path)

    try:
        report = await import_register(session, actor=await _actor(admin), file_path=path)
        await session.commit()
        assert report.created == 1
        assert report.errors == []

        from sqlalchemy import select
        from app.models.department import Department

        result = await session.execute(select(Department).where(Department.name == "Yangi bo'lim (import orqali)"))
        assert result.scalar_one_or_none() is not None
    finally:
        os.unlink(path)

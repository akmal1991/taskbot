import datetime as dt
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError, TelegramRetryAfter
from aiogram.methods import SendMessage

from app.bot.notifier import flush_notification_queue
from app.core import clock
from app.core.config import get_settings
from app.models.enums import NotificationType, UserRole
from app.scheduler.runner import build_scheduler
from app.services.notifications import enqueue, list_due
from tests.factories import make_user


@pytest.mark.parametrize("kind", ["forbidden", "bad_request", "rate_limit", "transient"])
@pytest.mark.asyncio
async def test_delivery_failures_are_classified_without_external_api_calls(session, kind):
    recipient = await make_user(session, role=UserRole.EMPLOYEE)
    notification = await enqueue(
        session, task_id=None, recipient_user_id=recipient.id,
        notif_type=NotificationType.DEADLINE_REMINDER, dedup_key=f"delivery:{kind}",
        text_rendered="<user text> & more",
    )
    await session.commit()
    method = SendMessage(chat_id=recipient.telegram_id, text="Example")
    errors = {
        "forbidden": TelegramForbiddenError(method=method, message="Blocked"),
        "bad_request": TelegramBadRequest(method=method, message="Rejected"),
        "rate_limit": TelegramRetryAfter(method=method, message="Slow down", retry_after=120),
        "transient": ConnectionError("Network unavailable"),
    }
    bot = SimpleNamespace(send_message=AsyncMock(side_effect=errors[kind]))
    await flush_notification_queue(bot)
    await session.refresh(notification)
    assert bot.send_message.await_args.kwargs["parse_mode"] is None
    assert notification.sent_at is None
    if kind in {"forbidden", "bad_request"}:
        assert notification.failed_reason is not None
    else:
        assert notification.failed_reason is None
        assert notification.scheduled_for > dt.datetime.now(dt.timezone.utc)
    assert await list_due(session) == []


@pytest.mark.asyncio
async def test_successful_delivery_is_sent_once_and_respects_text_limit(session):
    recipient = await make_user(session, role=UserRole.EMPLOYEE)
    notification = await enqueue(
        session, task_id=None, recipient_user_id=recipient.id,
        notif_type=NotificationType.DEADLINE_REMINDER, dedup_key="delivery:success", text_rendered="x" * 5000,
    )
    await session.commit()
    bot = SimpleNamespace(send_message=AsyncMock())
    assert await flush_notification_queue(bot) == (1, 0)
    assert await flush_notification_queue(bot) == (0, 0)
    await session.refresh(notification)
    assert notification.sent_at is not None
    bot.send_message.assert_awaited_once()
    assert len(bot.send_message.await_args.kwargs["text"]) == 4096


def test_calendar_uses_configured_timezone_at_midnight(monkeypatch):
    monkeypatch.setenv("SCHEDULER_TIMEZONE", "Asia/Tashkent")
    get_settings.cache_clear()
    original = dt.datetime

    class FixedDateTime(original):
        @classmethod
        def now(cls, tz=None):
            return original(2026, 10, 20, 21, tzinfo=dt.timezone.utc).astimezone(tz)

    monkeypatch.setattr(clock.dt, "datetime", FixedDateTime)
    assert clock.today() == dt.date(2026, 10, 21)


def test_scheduler_honors_local_morning_and_overdue_interval(monkeypatch):
    monkeypatch.setenv("SCHEDULER_TIMEZONE", "Asia/Tashkent")
    monkeypatch.setenv("OVERDUE_REMINDER_INTERVAL_HOURS", "6")
    get_settings.cache_clear()
    scheduler = build_scheduler(SimpleNamespace())
    assert str(scheduler.get_job("send_reminders").trigger.timezone) == "Asia/Tashkent"
    assert scheduler.get_job("send_overdue_reminders").trigger.interval == dt.timedelta(hours=6)

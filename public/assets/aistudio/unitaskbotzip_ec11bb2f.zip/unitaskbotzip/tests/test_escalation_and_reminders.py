from __future__ import annotations

import datetime as dt

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.enums import EscalationLevel, NotificationType, Priority, TaskStatus, UserRole
from app.services import escalation as escalation_service
from app.services import notifications as notif_service
from app.services import reminders as reminder_service
from app.services import tasks as task_service
from app.services.permissions import Actor
from tests.factories import make_department, make_user


async def _actor(user) -> Actor:
    return Actor.from_user(user)


@pytest.mark.asyncio
async def test_escalation_fires_each_level_once_and_targets_right_people(session: AsyncSession):
    dept = await make_department(session)
    vice_rector = await make_user(session, role=UserRole.VICE_RECTOR)
    rector = await make_user(session, role=UserRole.RECTOR)
    dept_head = await make_user(session, role=UserRole.DEPARTMENT_HEAD, department_id=dept.id)
    dept.head_user_id = dept_head.id
    await session.flush()
    employee = await make_user(session, role=UserRole.EMPLOYEE, department_id=dept.id)

    task = await task_service.create_task(
        session, actor=await _actor(vice_rector), title="Critical report", description=None, expected_outcome=None,
        acceptance_criteria=None, source_reference=None, department_id=dept.id,
        primary_responsible_id=employee.id, priority=Priority.CRITICAL,
        deadline=dt.date.today() + dt.timedelta(days=1),
    )
    task.deadline = dt.date.today() - dt.timedelta(days=1)  # 1 day overdue
    await session.flush()
    await task_service.sweep_overdue_tasks(session)
    task = await task_service.get_task(session, task.id)
    assert task.status == TaskStatus.OVERDUE

    events = await escalation_service.run_escalations_for_task(session, task)
    assert {e.level for e in events} == {EscalationLevel.DEPARTMENT_HEAD}

    # Running again the same day must NOT duplicate the department-head escalation.
    events2 = await escalation_service.run_escalations_for_task(session, task)
    assert events2 == []

    # Push to 3 days overdue -> vice-rector level should now fire (dept head already fired, skip).
    task.deadline = dt.date.today() - dt.timedelta(days=3)
    await session.flush()
    events3 = await escalation_service.run_escalations_for_task(session, task)
    assert {e.level for e in events3} == {EscalationLevel.VICE_RECTOR}

    # Push to 7 days overdue -> rector level fires too.
    task.deadline = dt.date.today() - dt.timedelta(days=7)
    await session.flush()
    events4 = await escalation_service.run_escalations_for_task(session, task)
    assert {e.level for e in events4} == {EscalationLevel.RECTOR}

    due = await notif_service.list_due(session)
    recipients = {n.recipient_user_id for n in due}
    assert dept_head.id in recipients
    assert vice_rector.id in recipients
    assert rector.id in recipients


@pytest.mark.asyncio
async def test_completed_task_is_never_swept_into_overdue_even_if_past_deadline(session: AsyncSession):
    manager = await make_user(session, role=UserRole.VICE_RECTOR)
    employee = await make_user(session, role=UserRole.EMPLOYEE)
    task = await task_service.create_task(
        session, actor=await _actor(manager), title="Done early", description=None, expected_outcome=None,
        acceptance_criteria=None, source_reference=None, department_id=None,
        primary_responsible_id=employee.id, priority=Priority.LOW,
        deadline=dt.date.today() + dt.timedelta(days=5),
    )
    emp_actor = await _actor(employee)
    await task_service.update_progress(session, actor=emp_actor, task_id=task.id, progress_percent=100)
    await task_service.submit_for_review(session, actor=emp_actor, task_id=task.id)
    await task_service.approve_task(session, actor=await _actor(manager), task_id=task.id)

    # Now artificially move the deadline into the past (e.g. a data correction).
    task.deadline = dt.date.today() - dt.timedelta(days=1)
    await session.flush()

    flagged = await task_service.sweep_overdue_tasks(session)
    assert task.id not in {t.id for t in flagged}
    refreshed = await task_service.get_task(session, task.id)
    assert refreshed.status == TaskStatus.COMPLETED


@pytest.mark.asyncio
async def test_notification_dedup_prevents_double_send(session: AsyncSession):
    manager = await make_user(session, role=UserRole.VICE_RECTOR)
    employee = await make_user(session, role=UserRole.EMPLOYEE)
    task = await task_service.create_task(
        session, actor=await _actor(manager), title="X", description=None, expected_outcome=None,
        acceptance_criteria=None, source_reference=None, department_id=None,
        primary_responsible_id=employee.id, priority=Priority.LOW,
        deadline=dt.date.today() + dt.timedelta(days=3),
    )
    first = await notif_service.enqueue(
        session, task_id=task.id, recipient_user_id=employee.id, notif_type=NotificationType.DEADLINE_REMINDER,
        dedup_key=f"reminder:{task.id}:days_before:3", text_rendered="3 days left",
    )
    second = await notif_service.enqueue(
        session, task_id=task.id, recipient_user_id=employee.id, notif_type=NotificationType.DEADLINE_REMINDER,
        dedup_key=f"reminder:{task.id}:days_before:3", text_rendered="3 days left (duplicate attempt)",
    )
    assert first is not None
    assert second is None

    due = [n for n in await notif_service.list_due(session) if n.notif_type == NotificationType.DEADLINE_REMINDER]
    assert len(due) == 1


@pytest.mark.asyncio
async def test_pre_deadline_reminders_only_fire_on_configured_days(session: AsyncSession):
    manager = await make_user(session, role=UserRole.VICE_RECTOR)
    employee = await make_user(session, role=UserRole.EMPLOYEE)

    task_3d = await task_service.create_task(
        session, actor=await _actor(manager), title="3 days out", description=None, expected_outcome=None,
        acceptance_criteria=None, source_reference=None, department_id=None,
        primary_responsible_id=employee.id, priority=Priority.LOW,
        deadline=dt.date.today() + dt.timedelta(days=3),
    )
    task_5d = await task_service.create_task(
        session, actor=await _actor(manager), title="5 days out (not a reminder day)", description=None,
        expected_outcome=None, acceptance_criteria=None, source_reference=None, department_id=None,
        primary_responsible_id=employee.id, priority=Priority.LOW,
        deadline=dt.date.today() + dt.timedelta(days=5),
    )

    count = await reminder_service.send_pre_deadline_reminders(session, [task_3d, task_5d])
    assert count == 1
    due = [n for n in await notif_service.list_due(session) if n.notif_type == NotificationType.DEADLINE_REMINDER]
    assert len(due) == 1
    assert due[0].task_id == task_3d.id

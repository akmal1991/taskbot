import asyncio
import datetime as dt

import pytest
from sqlalchemy import select
from sqlalchemy.ext.asyncio import async_sessionmaker

from app.models.enums import NotificationType, Priority, TaskStatus, UserRole
from app.models.notification import Notification
from app.services import tasks
from app.services.exceptions import InvalidTransitionError, ValidationError
from app.services.permissions import Actor
from tests.factories import make_user


async def create(session, actor, **overrides):
    fields = dict(
        actor=actor, title="Example", description=None, expected_outcome=None, acceptance_criteria=None,
        source_reference=None, department_id=None, primary_responsible_id=None,
        priority=Priority.MEDIUM, deadline=dt.date.today() + dt.timedelta(days=2),
    )
    fields.update(overrides)
    return await tasks.create_task(session, **fields)


@pytest.mark.asyncio
async def test_public_codes_remain_unique_when_numbering_has_gaps(session, engine):
    admin = await make_user(session, role=UserRole.SUPER_ADMIN)
    actor = Actor.from_user(admin)
    first = await create(session, actor)
    first.public_code = f"T-{dt.date.today().year}-0003"
    await session.commit()
    factory = async_sessionmaker(engine, expire_on_commit=False)

    async def create_and_commit():
        async with factory() as worker:
            task = await create(worker, actor)
            await worker.commit()
            return task.public_code

    codes = await asyncio.gather(create_and_commit(), create_and_commit())
    assert len(set(codes)) == 2
    assert {code.rsplit("-", 1)[1] for code in codes} == {"0004", "0005"}


@pytest.mark.asyncio
async def test_invalid_assignee_is_rejected_without_pending_task(session):
    admin = await make_user(session, role=UserRole.SUPER_ADMIN)
    with pytest.raises(ValidationError, match="selected user"):
        await create(session, Actor.from_user(admin), primary_responsible_id=2147483647)
    from app.models.task import Task
    assert await session.scalar(select(Task)) is None


@pytest.mark.asyncio
async def test_observer_cannot_acknowledge_even_when_assigned(session):
    admin = await make_user(session, role=UserRole.SUPER_ADMIN)
    observer = await make_user(session, role=UserRole.OBSERVER)
    task = await create(session, Actor.from_user(admin), primary_responsible_id=observer.id)
    with pytest.raises(ValidationError):
        await tasks.acknowledge_task(session, actor=Actor.from_user(observer), task_id=task.id)
    assert task.status == TaskStatus.ASSIGNED


@pytest.mark.asyncio
async def test_completed_task_rejects_progress_without_partial_writes(session):
    admin = await make_user(session, role=UserRole.SUPER_ADMIN)
    employee = await make_user(session, role=UserRole.EMPLOYEE)
    actor, assignee = Actor.from_user(admin), Actor.from_user(employee)
    task = await create(session, actor, primary_responsible_id=employee.id)
    await tasks.update_progress(session, actor=assignee, task_id=task.id, progress_percent=100)
    await tasks.submit_for_review(session, actor=assignee, task_id=task.id)
    await tasks.approve_task(session, actor=actor, task_id=task.id)
    with pytest.raises(InvalidTransitionError):
        await tasks.update_progress(session, actor=assignee, task_id=task.id, progress_percent=5, comment="Must not save")
    assert task.progress_percent == 100
    assert task.comments == []
    with pytest.raises(InvalidTransitionError):
        await tasks.change_deadline(session, actor=actor, task_id=task.id, new_deadline=dt.date.today())


@pytest.mark.asyncio
async def test_assignment_review_and_approval_queue_real_notifications(session):
    admin = await make_user(session, role=UserRole.SUPER_ADMIN)
    employee = await make_user(session, role=UserRole.EMPLOYEE)
    actor, assignee = Actor.from_user(admin), Actor.from_user(employee)
    task = await create(session, actor, primary_responsible_id=employee.id)
    await tasks.update_progress(session, actor=assignee, task_id=task.id, progress_percent=90)
    await tasks.submit_for_review(session, actor=assignee, task_id=task.id)
    await tasks.approve_task(session, actor=actor, task_id=task.id)
    notifications = list((await session.scalars(select(Notification))).all())
    assert {(n.notif_type, n.recipient_user_id) for n in notifications} == {
        (NotificationType.NEW_ASSIGNMENT, employee.id),
        (NotificationType.SUBMITTED_FOR_REVIEW, admin.id),
        (NotificationType.APPROVED, employee.id),
    }


@pytest.mark.asyncio
async def test_failed_extension_approval_does_not_approve_request(session):
    admin = await make_user(session, role=UserRole.SUPER_ADMIN)
    employee = await make_user(session, role=UserRole.EMPLOYEE)
    actor, assignee = Actor.from_user(admin), Actor.from_user(employee)
    task = await create(session, actor, primary_responsible_id=employee.id)
    request = await tasks.request_extension(
        session, actor=assignee, task_id=task.id,
        requested_deadline=task.deadline + dt.timedelta(days=1), justification="More time needed",
    )
    request.requested_deadline = dt.date.today() - dt.timedelta(days=1)
    await session.flush()
    old_deadline = task.deadline
    with pytest.raises(ValidationError):
        await tasks.review_extension(session, actor=actor, extension_request_id=request.id, approve=True)
    assert request.status == "pending"
    assert request.reviewed_by_id is None
    assert task.deadline == old_deadline


@pytest.mark.asyncio
async def test_concurrent_approvals_cannot_duplicate_task_history(session, engine):
    admin = await make_user(session, role=UserRole.SUPER_ADMIN)
    employee = await make_user(session, role=UserRole.EMPLOYEE)
    actor, assignee = Actor.from_user(admin), Actor.from_user(employee)
    task = await create(session, actor, primary_responsible_id=employee.id)
    await tasks.update_progress(session, actor=assignee, task_id=task.id, progress_percent=100)
    await tasks.submit_for_review(session, actor=assignee, task_id=task.id)
    await session.commit()
    factory = async_sessionmaker(engine, expire_on_commit=False)

    async def approve():
        async with factory() as worker:
            try:
                await tasks.approve_task(worker, actor=actor, task_id=task.id)
                await worker.commit()
                return True
            except InvalidTransitionError:
                await worker.rollback()
                return False

    assert sum(await asyncio.gather(approve(), approve())) == 1
    await session.refresh(task, attribute_names=["history"])
    assert sum(h.to_status == TaskStatus.COMPLETED for h in task.history) == 1

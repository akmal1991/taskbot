from __future__ import annotations

import datetime as dt
import os

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.enums import Priority, TaskStatus, UserRole
from app.services import tasks as task_service
from app.services.permissions import Actor
from tests.factories import make_user


async def _actor(user) -> Actor:
    return Actor.from_user(user)


@pytest.mark.asyncio
async def test_sweep_and_escalate_job_runs_against_real_db(session: AsyncSession, monkeypatch):
    # job_sweep_and_escalate opens its own session via session_scope(), which
    # reads DATABASE_URL from get_settings() — point that at the same test DB.
    manager = await make_user(session, role=UserRole.VICE_RECTOR)
    employee = await make_user(session, role=UserRole.EMPLOYEE)
    task = await task_service.create_task(
        session, actor=await _actor(manager), title="Will become overdue", description=None,
        expected_outcome=None, acceptance_criteria=None, source_reference=None, department_id=None,
        primary_responsible_id=employee.id, priority=Priority.LOW,
        deadline=dt.date.today() + dt.timedelta(days=1),
    )
    task.deadline = dt.date.today() - dt.timedelta(days=1)
    await session.commit()

    from app.core import config as config_module

    config_module.get_settings.cache_clear()
    from app.scheduler.jobs import job_sweep_and_escalate

    await job_sweep_and_escalate()

    # job_sweep_and_escalate ran in its own DB session/connection; refresh
    # this test's copy of the row rather than trusting the stale identity-map
    # object the earlier `session.commit()` left behind.
    await session.refresh(task)
    assert task.status == TaskStatus.OVERDUE

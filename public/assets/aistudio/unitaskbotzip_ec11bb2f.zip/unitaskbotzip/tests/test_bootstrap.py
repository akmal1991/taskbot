"""First-admin checks against an isolated PostgreSQL schema."""
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from sqlalchemy import select

from app.bot.handlers.start import cmd_start
from app.bot.states.forms import Registration
from app.core.config import get_settings
from app.models.enums import UserRole
from app.models.user import User


@pytest.mark.parametrize("sender_id,is_admin", [(111111, True), (222222, False)])
@pytest.mark.asyncio
async def test_only_configured_account_bootstraps_as_admin(session, monkeypatch, sender_id, is_admin):
    monkeypatch.setenv("BOOTSTRAP_SUPER_ADMIN_TELEGRAM_ID", "111111")
    get_settings.cache_clear()
    message = SimpleNamespace(
        from_user=SimpleNamespace(id=sender_id, username="test_account"),
        answer=AsyncMock(),
    )
    state = SimpleNamespace(clear=AsyncMock(), set_state=AsyncMock())
    await cmd_start(message, state, session, None)
    user = await session.scalar(select(User).where(User.telegram_id == sender_id))
    if is_admin:
        assert user is not None
        assert user.role == UserRole.SUPER_ADMIN
        assert user.is_active
        await session.commit()
        session.expunge_all()
        stored = await session.scalar(select(User).where(User.telegram_id == sender_id))
        assert stored.role == UserRole.SUPER_ADMIN
    else:
        assert user is None
        state.set_state.assert_awaited_once_with(Registration.full_name)

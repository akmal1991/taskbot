"""Local defensive checks; no requests are sent to Telegram."""
import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import async_sessionmaker

from app.bot.handlers.settings import weblogin
from app.bot.handlers.tasks_list import department_tasks
from app.models.enums import NotificationType, UserRole
from app.models.web_auth import WebLoginToken
from app.services import notifications, users
from app.services.exceptions import ValidationError
from app.services.permissions import Actor, can_create_task, can_update_progress, can_view_task
from app.services.web_auth import issue_login_token, redeem_login_token
from app.web.auth import _serializer, read_session_cookie
from tests.factories import make_department, make_user


@pytest.mark.asyncio
async def test_concurrent_login_redemption_has_one_winner(session, engine):
    user = await make_user(session, role=UserRole.RECTOR)
    token = await issue_login_token(session, user_id=user.id)
    await session.commit()
    factory = async_sessionmaker(engine, expire_on_commit=False)

    async def claim():
        async with factory() as claim_session:
            result = await redeem_login_token(claim_session, token=token)
            await claim_session.commit()
            return result is not None

    assert sum(await asyncio.gather(claim(), claim())) == 1


@pytest.mark.asyncio
async def test_inactive_user_cannot_redeem_login(session):
    user = await make_user(session, role=UserRole.RECTOR, is_active=False)
    token = await issue_login_token(session, user_id=user.id)
    assert await redeem_login_token(session, token=token) is None


@pytest.mark.parametrize("payload", [[], "text", {}, {"user_id": "1"}, {"user_id": True}, {"user_id": -1}])
def test_signed_but_malformed_session_is_rejected(payload):
    assert read_session_cookie(_serializer().dumps(payload)) is None


@pytest.mark.asyncio
async def test_group_weblogin_never_issues_bearer_token(session):
    user = await make_user(session, role=UserRole.RECTOR)
    message = SimpleNamespace(chat=SimpleNamespace(type="group"), answer=AsyncMock())
    await weblogin(message, session, user, Actor.from_user(user))
    assert await session.scalar(select(func.count()).select_from(WebLoginToken)) == 0
    message.answer.assert_awaited_once()


@pytest.mark.asyncio
async def test_employee_cannot_invoke_department_list_by_typing_menu_label(session):
    dept = await make_department(session)
    user = await make_user(session, role=UserRole.EMPLOYEE, department_id=dept.id)
    message = SimpleNamespace(answer=AsyncMock())
    await department_tasks(message, session, Actor.from_user(user), user)
    assert message.answer.await_args.kwargs.get("reply_markup") is None
    assert "rahbarlar" in message.answer.await_args.args[0]


@pytest.mark.asyncio
async def test_rejected_registration_can_be_resubmitted(session):
    admin = await make_user(session, role=UserRole.SUPER_ADMIN)
    fields = dict(
        telegram_id=987654, username=None, full_name="New User", phone=None,
        requested_role=UserRole.EMPLOYEE, requested_department_id=None,
    )
    first = await users.submit_registration_request(session, **fields)
    await users.reject_registration(session, actor=Actor.from_user(admin), request_id=first.id, reason="Please correct")
    second = await users.submit_registration_request(session, **fields)
    assert second.id == first.id
    assert second.status.value == "pending"
    assert second.rejection_reason is None
    assert second.reviewed_at is None


@pytest.mark.asyncio
async def test_last_administrator_cannot_be_disabled_or_demoted(session):
    admin = await make_user(session, role=UserRole.SUPER_ADMIN)
    actor = Actor.from_user(admin)
    with pytest.raises(ValidationError, match="last active"):
        await users.set_user_active(session, actor=actor, user_id=admin.id, is_active=False)
    with pytest.raises(ValidationError, match="last active"):
        await users.set_user_role(session, actor=actor, user_id=admin.id, new_role=UserRole.EMPLOYEE)
    assert admin.is_active
    assert admin.role == UserRole.SUPER_ADMIN


@pytest.mark.asyncio
async def test_permanently_failed_notifications_are_not_retried(session):
    user = await make_user(session, role=UserRole.EMPLOYEE)
    notification = await notifications.enqueue(
        session, task_id=None, recipient_user_id=user.id, notif_type=NotificationType.DEADLINE_REMINDER,
        dedup_key="permanent-failure", text_rendered="Example",
    )
    await notifications.mark_failed(session, notification.id, "blocked the bot")
    assert await notifications.list_due(session) == []


@pytest.mark.asyncio
async def test_concurrent_notification_dedup_preserves_other_writes(session, engine):
    user = await make_user(session, role=UserRole.EMPLOYEE)
    await session.commit()
    factory = async_sessionmaker(engine, expire_on_commit=False)

    async def enqueue(name):
        async with factory() as worker:
            await make_department(worker, name=name)
            result = await notifications.enqueue(
                worker, task_id=None, recipient_user_id=user.id,
                notif_type=NotificationType.DEADLINE_REMINDER, dedup_key="same-message", text_rendered="Example",
            )
            await worker.commit()
            return result is not None

    assert sum(await asyncio.gather(enqueue("First write"), enqueue("Second write"))) == 1
    from app.models.department import Department
    assert await session.scalar(select(func.count()).select_from(Department)) == 2


def test_inactive_actors_have_no_task_permissions():
    from app.models.task import Task
    task = Task(primary_responsible_id=1, created_by_id=1, approver_id=1)
    task.assignees = []
    actor = Actor(id=1, role=UserRole.SUPER_ADMIN, department_id=None, is_active=False)
    assert not can_create_task(actor)
    assert not can_view_task(actor, task)
    assert not can_update_progress(actor, task)

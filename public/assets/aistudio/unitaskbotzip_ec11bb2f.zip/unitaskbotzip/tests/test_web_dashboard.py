from __future__ import annotations

import datetime as dt

import pytest
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.enums import Priority, UserRole
from app.services import tasks as task_service
from app.services.permissions import Actor
from app.services.web_auth import issue_login_token
from app.web.auth import get_db_session
from app.web.main import app
from tests.factories import make_department, make_user


async def _actor(user) -> Actor:
    return Actor.from_user(user)


@pytest.fixture
def client(session: AsyncSession):
    # The FastAPI app's own get_db_session dependency opens sessions from a
    # module-global engine bound to whichever event loop created it, which
    # breaks across pytest-asyncio's per-test event loops (same class of bug
    # fixed for the `engine` fixture in conftest.py). For tests, override the
    # dependency to reuse this test's own session/engine/loop instead.
    async def _override_db_session():
        yield session

    app.dependency_overrides[get_db_session] = _override_db_session
    try:
        yield AsyncClient(transport=ASGITransport(app=app), base_url="https://test")
    finally:
        app.dependency_overrides.pop(get_db_session, None)


@pytest.mark.asyncio
async def test_login_with_valid_token_sets_session_cookie_and_reaches_dashboard(
    session: AsyncSession, client: AsyncClient
):
    manager = await make_user(session, role=UserRole.RECTOR)
    await session.commit()

    token = await issue_login_token(session, user_id=manager.id)
    await session.commit()

    async with client:
        resp = await client.get(f"/login?token={token}", follow_redirects=False)
        assert resp.status_code == 302
        assert resp.headers["location"] == "/dashboard"
        cookie = resp.cookies.get("session")
        assert cookie is not None

        resp2 = await client.get("/dashboard")
        assert resp2.status_code == 200
        assert "Jami vazifalar" in resp2.text


@pytest.mark.asyncio
async def test_login_with_invalid_token_is_rejected(session: AsyncSession, client: AsyncClient):
    async with client:
        resp = await client.get("/login?token=not-a-real-token")
        assert resp.status_code == 400
        assert "yaroqsiz" in resp.text


@pytest.mark.asyncio
async def test_login_token_is_single_use(session: AsyncSession, client: AsyncClient):
    manager = await make_user(session, role=UserRole.RECTOR)
    await session.commit()
    token = await issue_login_token(session, user_id=manager.id)
    await session.commit()

    async with client:
        first = await client.get(f"/login?token={token}", follow_redirects=False)
        assert first.status_code == 302

        second = await client.get(f"/login?token={token}", follow_redirects=False)
        assert second.status_code == 400


@pytest.mark.asyncio
async def test_login_token_expires(session: AsyncSession, client: AsyncClient):
    manager = await make_user(session, role=UserRole.RECTOR)
    await session.commit()
    token = await issue_login_token(session, user_id=manager.id)
    await session.commit()

    from app.models.web_auth import WebLoginToken
    from sqlalchemy import select

    row = (await session.execute(select(WebLoginToken).where(WebLoginToken.token == token))).scalar_one()
    row.expires_at = dt.datetime.now(dt.timezone.utc) - dt.timedelta(minutes=1)
    await session.commit()

    async with client:
        resp = await client.get(f"/login?token={token}", follow_redirects=False)
        assert resp.status_code == 400


@pytest.mark.asyncio
async def test_employee_without_dashboard_rights_is_blocked(session: AsyncSession, client: AsyncClient):
    employee = await make_user(session, role=UserRole.EMPLOYEE)
    await session.commit()
    token = await issue_login_token(session, user_id=employee.id)
    await session.commit()

    async with client:
        login_resp = await client.get(f"/login?token={token}", follow_redirects=False)
        cookie = login_resp.cookies.get("session")

        resp = await client.get("/dashboard")
        assert resp.status_code == 403
        # Jinja autoescapes the apostrophe in "yo'q" as &#39;, so match the
        # unambiguous substring rather than the raw Uzbek text.
        assert "huquqi yo" in resp.text


@pytest.mark.asyncio
async def test_dashboard_kpis_reflect_real_task_counts(session: AsyncSession, client: AsyncClient):
    manager = await make_user(session, role=UserRole.RECTOR)
    dept = await make_department(session, name="IT Department")
    employee = await make_user(session, role=UserRole.EMPLOYEE, department_id=dept.id)
    await session.commit()

    task = await task_service.create_task(
        session, actor=await _actor(manager), title="Demo vazifa", description=None,
        expected_outcome=None, acceptance_criteria=None, source_reference=None, department_id=dept.id,
        primary_responsible_id=employee.id, priority=Priority.HIGH,
        deadline=dt.date.today() + dt.timedelta(days=5),
    )
    await session.commit()

    token = await issue_login_token(session, user_id=manager.id)
    await session.commit()

    async with client:
        login_resp = await client.get(f"/login?token={token}", follow_redirects=False)
        cookie = login_resp.cookies.get("session")

        resp = await client.get("/dashboard")
        assert resp.status_code == 200
        assert task.public_code in resp.text
        assert "Demo vazifa" in resp.text
        assert "IT Department" in resp.text


@pytest.mark.asyncio
async def test_dashboard_export_xlsx_downloads_for_authorized_role(session: AsyncSession, client: AsyncClient):
    manager = await make_user(session, role=UserRole.SUPER_ADMIN)
    await session.commit()
    token = await issue_login_token(session, user_id=manager.id)
    await session.commit()

    async with client:
        login_resp = await client.get(f"/login?token={token}", follow_redirects=False)
        cookie = login_resp.cookies.get("session")

        resp = await client.get("/dashboard/export.xlsx")
        assert resp.status_code == 200
        assert resp.headers["content-type"].startswith("application/vnd.openxmlformats")


@pytest.mark.asyncio
async def test_blank_department_filter_and_security_headers(session: AsyncSession, client: AsyncClient):
    manager = await make_user(session, role=UserRole.RECTOR)
    await session.commit()
    token = await issue_login_token(session, user_id=manager.id)
    await session.commit()
    async with client:
        login = await client.get(f"/login?token={token}")
        assert "Secure" in login.headers["set-cookie"]
        response = await client.get("/dashboard?department_id=&status_filter=&priority_filter=")
        assert response.status_code == 200
        assert response.headers["cache-control"] == "no-store"
        assert response.headers["referrer-policy"] == "no-referrer"


@pytest.mark.asyncio
async def test_dashboard_escapes_user_supplied_html(session: AsyncSession, client: AsyncClient):
    manager = await make_user(session, role=UserRole.RECTOR, full_name="<script>alert(1)</script>")
    await session.commit()
    token = await issue_login_token(session, user_id=manager.id)
    await session.commit()
    async with client:
        await client.get(f"/login?token={token}")
        response = await client.get("/dashboard")
        assert response.status_code == 200
        assert "<script>alert(1)</script>" not in response.text
        assert "&lt;script&gt;" in response.text


@pytest.mark.asyncio
async def test_favicon_does_not_generate_browser_console_errors(client: AsyncClient):
    async with client:
        response = await client.get("/favicon.ico")
        assert response.status_code == 204

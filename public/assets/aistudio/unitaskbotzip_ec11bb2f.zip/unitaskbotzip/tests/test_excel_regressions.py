import datetime as dt

import openpyxl
import pytest
from sqlalchemy import select
from sqlalchemy.ext.asyncio import async_sessionmaker

from app.excel_io.export import build_register_workbook
from app.excel_io.import_ import import_register
from app.models.enums import Priority, TaskStatus, UserRole
from app.models.task import Task
from app.services import tasks
from app.services.exceptions import ValidationError
from app.services.permissions import Actor
from tests.factories import make_user


def workbook(tmp_path, headers, rows, filename="input.xlsx"):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(headers)
    for row in rows:
        ws.append(row)
    path = tmp_path / filename
    wb.save(path)
    wb.close()
    return str(path)


@pytest.mark.asyncio
async def test_subset_columns_do_not_read_unrelated_cells_or_collide(session, tmp_path):
    admin = await make_user(session, role=UserRole.SUPER_ADMIN)
    actor = Actor.from_user(admin)
    first = workbook(tmp_path, ["Title", "Description"], [["First", "Real description"]], "one.xlsx")
    second = workbook(tmp_path, ["Title"], [["Second"]], "two.xlsx")
    assert (await import_register(session, actor=actor, file_path=first)).created == 1
    assert (await import_register(session, actor=actor, file_path=second)).created == 1
    result = list((await session.scalars(select(Task).order_by(Task.id))).all())
    assert len({task.public_code for task in result}) == 2
    assert result[0].description == "Real description"
    assert result[0].public_code != "Real description"


@pytest.mark.asyncio
async def test_status_import_works_in_fresh_session_without_losing_omitted_fields(session, engine, tmp_path):
    admin = await make_user(session, role=UserRole.SUPER_ADMIN)
    actor = Actor.from_user(admin)
    task = await tasks.create_task(
        session, actor=actor, title="Original", description="Keep me", expected_outcome=None,
        acceptance_criteria=None, source_reference=None, department_id=None, primary_responsible_id=None,
        priority=Priority.HIGH, deadline=dt.date.today() + dt.timedelta(days=5),
    )
    await session.commit()
    path = workbook(tmp_path, ["Public Code", "Title", "Status"], [[task.public_code, "Edited", "assigned"]])
    factory = async_sessionmaker(engine, expire_on_commit=False)
    async with factory() as fresh:
        report = await import_register(fresh, actor=actor, file_path=path)
        assert report.errors == []
        assert report.updated == 1
        await fresh.commit()
        loaded = await tasks.get_task(fresh, task.id)
        assert loaded.status == TaskStatus.ASSIGNED
        assert loaded.description == "Keep me"
        assert loaded.priority == Priority.HIGH
        assert loaded.deadline == task.deadline
        assert len(loaded.history) == 2


@pytest.mark.asyncio
async def test_failed_import_row_does_not_count_or_break_later_rows(session, tmp_path):
    admin = await make_user(session, role=UserRole.SUPER_ADMIN)
    path = workbook(
        tmp_path, ["Title", "Deadline", "Department"],
        [["Bad date", "not-a-date", "Shared"], ["Good row", "25.12.2026", "Shared"]],
    )
    report = await import_register(session, actor=Actor.from_user(admin), file_path=path)
    assert report.created == 1
    assert len(report.errors) == 1
    assert (await session.scalar(select(Task))).title == "Good row"


@pytest.mark.asyncio
async def test_exported_user_text_is_literal_not_a_formula(session, tmp_path):
    admin = await make_user(session, role=UserRole.SUPER_ADMIN, full_name="=1+2")
    task = await tasks.create_task(
        session, actor=Actor.from_user(admin), title="=1+1", description="=SUM(1,2)", expected_outcome=None,
        acceptance_criteria=None, source_reference=None, department_id=None, primary_responsible_id=None,
        priority=Priority.LOW, deadline=None,
    )
    wb = await build_register_workbook(session)
    path = tmp_path / "export.xlsx"
    wb.save(path)
    wb.close()
    with_formulas = openpyxl.load_workbook(path, data_only=False)
    ws = with_formulas.active
    assert ws.cell(2, 3).data_type == "s"
    assert ws.cell(2, 3).value == task.title
    assert ws.cell(2, 16).data_type == "s"
    with_formulas.close()
    data = openpyxl.load_workbook(path, data_only=True)
    assert data.active.cell(2, 3).value == "=1+1"
    data.close()


@pytest.mark.asyncio
async def test_employee_cannot_import_tasks(session, tmp_path):
    employee = await make_user(session, role=UserRole.EMPLOYEE)
    path = workbook(tmp_path, ["Title"], [["Unauthorized"]])
    with pytest.raises(ValidationError, match="Super Administrator"):
        await import_register(session, actor=Actor.from_user(employee), file_path=path)

"""Direct unit tests for app.services.permissions.

These are pure functions of (Actor, Task) with no database I/O, so they are
tested here without any DB fixture at all — plain in-memory objects, never
added to a session. This is the dedicated RBAC coverage that the lifecycle
and escalation tests only exercise indirectly.
"""
from __future__ import annotations

import pytest

from app.models.enums import UserRole
from app.models.task import Task, TaskAssignee
from app.services.permissions import (
    Actor,
    can_approve_or_return,
    can_approve_registration,
    can_cancel_task,
    can_create_task,
    can_delegate_subtask,
    can_manage_departments,
    can_manage_users,
    can_reassign_or_change_deadline,
    can_update_progress,
    can_view_all_tasks,
    can_view_dashboard,
    can_view_task,
)


def _actor(role: UserRole, *, id: int = 1, department_id: int | None = None, is_active: bool = True) -> Actor:
    return Actor(id=id, role=role, department_id=department_id, is_active=is_active)


def _task(
    *,
    primary_responsible_id: int | None = None,
    created_by_id: int = 100,
    approver_id: int = 100,
    department_id: int | None = None,
    assignees: list[TaskAssignee] | None = None,
) -> Task:
    task = Task(
        public_code="T-TEST-0001",
        title="Test task",
        created_by_id=created_by_id,
        approver_id=approver_id,
        primary_responsible_id=primary_responsible_id,
        department_id=department_id,
    )
    task.assignees = assignees or []
    return task


# --- can_create_task / can_manage_* -----------------------------------

@pytest.mark.parametrize(
    "role,expected",
    [
        (UserRole.SUPER_ADMIN, True),
        (UserRole.RECTOR, True),
        (UserRole.VICE_RECTOR, True),
        (UserRole.DEPARTMENT_HEAD, True),
        (UserRole.EMPLOYEE, False),
        (UserRole.OBSERVER, False),
    ],
)
def test_can_create_task_matches_spec_roles(role, expected):
    assert can_create_task(_actor(role)) is expected


def test_only_super_admin_can_manage_users_and_departments():
    for role in UserRole:
        actor = _actor(role)
        expected = role == UserRole.SUPER_ADMIN
        assert can_manage_users(actor) is expected
        assert can_manage_departments(actor) is expected
        assert can_approve_registration(actor) is expected


# --- can_view_dashboard -------------------------------------------------

@pytest.mark.parametrize(
    "role,expected",
    [
        (UserRole.SUPER_ADMIN, True),
        (UserRole.RECTOR, True),
        (UserRole.OBSERVER, True),
        (UserRole.VICE_RECTOR, True),
        (UserRole.DEPARTMENT_HEAD, True),
        (UserRole.EMPLOYEE, False),
    ],
)
def test_can_view_dashboard_matches_spec_roles(role, expected):
    assert can_view_dashboard(_actor(role)) is expected


def test_can_view_all_tasks_is_narrower_than_can_view_dashboard():
    # Full cross-department task *visibility* is reserved for the top-level
    # oversight roles; dashboard access is broader (also Vice-Rector/Dept
    # Head), so these two sets must not be conflated.
    assert can_view_all_tasks(_actor(UserRole.VICE_RECTOR)) is False
    assert can_view_dashboard(_actor(UserRole.VICE_RECTOR)) is True
    assert can_view_all_tasks(_actor(UserRole.SUPER_ADMIN)) is True


# --- can_view_task -------------------------------------------------------

def test_responsible_employee_can_view_own_task():
    employee = _actor(UserRole.EMPLOYEE, id=42)
    task = _task(primary_responsible_id=42)
    assert can_view_task(employee, task) is True


def test_unrelated_employee_cannot_view_someone_elses_task():
    employee = _actor(UserRole.EMPLOYEE, id=42)
    task = _task(primary_responsible_id=99, created_by_id=1, approver_id=1)
    assert can_view_task(employee, task) is False


def test_department_head_can_view_task_in_own_department_even_if_not_assigned():
    head = _actor(UserRole.DEPARTMENT_HEAD, id=5, department_id=10)
    task = _task(department_id=10, primary_responsible_id=99)
    assert can_view_task(head, task) is True


def test_department_head_cannot_view_other_departments_task():
    head = _actor(UserRole.DEPARTMENT_HEAD, id=5, department_id=10)
    task = _task(department_id=11, primary_responsible_id=99)
    assert can_view_task(head, task) is False


def test_supporting_assignee_can_view_task():
    employee = _actor(UserRole.EMPLOYEE, id=7)
    task = _task(primary_responsible_id=99)
    task.assignees = [TaskAssignee(user_id=7)]
    assert can_view_task(employee, task) is True


# --- can_update_progress -------------------------------------------------

def test_only_responsible_or_supporting_assignee_can_update_progress():
    task = _task(primary_responsible_id=1)
    task.assignees = [TaskAssignee(user_id=2)]
    assert can_update_progress(_actor(UserRole.EMPLOYEE, id=1), task) is True
    assert can_update_progress(_actor(UserRole.EMPLOYEE, id=2), task) is True
    assert can_update_progress(_actor(UserRole.EMPLOYEE, id=3), task) is False
    # Even a manager who merely *views* the task may not log progress on it
    # themselves unless they are also the responsible/supporting person.
    assert can_update_progress(_actor(UserRole.RECTOR, id=999), task) is False


# --- can_approve_or_return: the self-approval guard ----------------------

def test_employee_can_never_approve_own_task_even_if_also_approver():
    # Deliberately contrived: a data error makes id=1 both the primary
    # responsible person AND the recorded approver. The self-approval rule
    # must still win.
    task = _task(primary_responsible_id=1, approver_id=1, created_by_id=1)
    assert can_approve_or_return(_actor(UserRole.EMPLOYEE, id=1), task) is False
    # A Super Admin generally may approve, but not when they are themselves
    # the one responsible for the task.
    assert can_approve_or_return(_actor(UserRole.SUPER_ADMIN, id=1), task) is False


def test_the_assigner_can_approve_their_own_assigned_task():
    task = _task(primary_responsible_id=2, created_by_id=1, approver_id=1)
    assert can_approve_or_return(_actor(UserRole.DEPARTMENT_HEAD, id=1), task) is True


def test_super_admin_can_approve_as_an_override_when_not_the_assignee():
    task = _task(primary_responsible_id=2, created_by_id=1, approver_id=1)
    assert can_approve_or_return(_actor(UserRole.SUPER_ADMIN, id=999), task) is True


def test_unrelated_manager_cannot_approve_someone_elses_task():
    task = _task(primary_responsible_id=2, created_by_id=1, approver_id=1)
    assert can_approve_or_return(_actor(UserRole.VICE_RECTOR, id=5), task) is False


# --- reassignment / cancellation -----------------------------------------

def test_reassign_and_cancel_restricted_to_creator_approver_or_super_admin():
    task = _task(created_by_id=1, approver_id=1)
    assert can_reassign_or_change_deadline(_actor(UserRole.DEPARTMENT_HEAD, id=1), task) is True
    assert can_cancel_task(_actor(UserRole.DEPARTMENT_HEAD, id=1), task) is True
    assert can_reassign_or_change_deadline(_actor(UserRole.VICE_RECTOR, id=999), task) is False
    assert can_reassign_or_change_deadline(_actor(UserRole.SUPER_ADMIN, id=999), task) is True


def test_delegation_requires_department_head_rank_or_above():
    assert can_delegate_subtask(_actor(UserRole.DEPARTMENT_HEAD)) is True
    assert can_delegate_subtask(_actor(UserRole.VICE_RECTOR)) is True
    assert can_delegate_subtask(_actor(UserRole.EMPLOYEE)) is False
    assert can_delegate_subtask(_actor(UserRole.OBSERVER)) is False

from __future__ import annotations

import datetime as dt

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.enums import Priority, TaskStatus, UserRole
from app.services import tasks as task_service
from app.services.exceptions import InvalidTransitionError, ValidationError
from app.services.permissions import Actor
from tests.factories import make_department, make_user


async def _actor(user) -> Actor:
    return Actor.from_user(user)


@pytest.mark.asyncio
async def test_create_task_auto_assigns_when_responsible_given(session: AsyncSession):
    dept = await make_department(session)
    manager = await make_user(session, role=UserRole.VICE_RECTOR)
    employee = await make_user(session, role=UserRole.EMPLOYEE, department_id=dept.id)

    task = await task_service.create_task(
        session, actor=await _actor(manager), title="Prepare accreditation report",
        description=None, expected_outcome=None, acceptance_criteria=None, source_reference="Rector's order #12",
        department_id=dept.id, primary_responsible_id=employee.id, priority=Priority.HIGH,
        deadline=dt.date.today() + dt.timedelta(days=10),
    )

    assert task.status == TaskStatus.ASSIGNED
    assert task.public_code.startswith(f"T-{dt.date.today().year}-")
    assert task.approver_id == manager.id
    assert len(task.history) == 2  # CREATED -> ASSIGNED
    assert task.history[0].to_status == TaskStatus.CREATED
    assert task.history[1].to_status == TaskStatus.ASSIGNED


@pytest.mark.asyncio
async def test_full_happy_path_lifecycle(session: AsyncSession):
    manager = await make_user(session, role=UserRole.VICE_RECTOR)
    employee = await make_user(session, role=UserRole.EMPLOYEE)

    task = await task_service.create_task(
        session, actor=await _actor(manager), title="Submit annual report",
        description=None, expected_outcome=None, acceptance_criteria=None, source_reference=None,
        department_id=None, primary_responsible_id=employee.id, priority=Priority.MEDIUM,
        deadline=dt.date.today() + dt.timedelta(days=5),
    )

    emp_actor = await _actor(employee)
    task = await task_service.acknowledge_task(session, actor=emp_actor, task_id=task.id)
    assert task.status == TaskStatus.ACKNOWLEDGED

    task = await task_service.update_progress(session, actor=emp_actor, task_id=task.id, progress_percent=50)
    assert task.status == TaskStatus.IN_PROGRESS
    assert task.progress_percent == 50

    # 100% progress must NOT auto-complete the task.
    task = await task_service.update_progress(session, actor=emp_actor, task_id=task.id, progress_percent=100)
    assert task.status == TaskStatus.IN_PROGRESS
    assert task.progress_percent == 100

    task = await task_service.submit_for_review(session, actor=emp_actor, task_id=task.id, comment="Done, see attachment")
    assert task.status == TaskStatus.SUBMITTED_FOR_REVIEW

    mgr_actor = await _actor(manager)
    task = await task_service.approve_task(session, actor=mgr_actor, task_id=task.id, comment="Looks good")
    assert task.status == TaskStatus.COMPLETED
    assert task.actual_completion_date == dt.date.today()
    assert task.progress_percent == 100


@pytest.mark.asyncio
async def test_employee_cannot_approve_own_task(session: AsyncSession):
    manager = await make_user(session, role=UserRole.VICE_RECTOR)
    employee = await make_user(session, role=UserRole.EMPLOYEE)
    task = await task_service.create_task(
        session, actor=await _actor(manager), title="Self task",
        description=None, expected_outcome=None, acceptance_criteria=None, source_reference=None,
        department_id=None, primary_responsible_id=employee.id, approver_id=employee.id,
        priority=Priority.LOW, deadline=None,
    )
    emp_actor = await _actor(employee)
    await task_service.acknowledge_task(session, actor=emp_actor, task_id=task.id)
    await task_service.update_progress(session, actor=emp_actor, task_id=task.id, progress_percent=100)
    await task_service.submit_for_review(session, actor=emp_actor, task_id=task.id)

    with pytest.raises(ValidationError):
        await task_service.approve_task(session, actor=emp_actor, task_id=task.id)


@pytest.mark.asyncio
async def test_cannot_complete_by_progress_percent_alone(session: AsyncSession):
    manager = await make_user(session, role=UserRole.VICE_RECTOR)
    employee = await make_user(session, role=UserRole.EMPLOYEE)
    task = await task_service.create_task(
        session, actor=await _actor(manager), title="X", description=None, expected_outcome=None,
        acceptance_criteria=None, source_reference=None, department_id=None,
        primary_responsible_id=employee.id, priority=Priority.LOW, deadline=None,
    )
    emp_actor = await _actor(employee)
    await task_service.update_progress(session, actor=emp_actor, task_id=task.id, progress_percent=100)
    task = await task_service.get_task(session, task.id)
    assert task.status != TaskStatus.COMPLETED
    assert task.status == TaskStatus.IN_PROGRESS

    # Trying to approve directly from IN_PROGRESS (skipping SUBMITTED_FOR_REVIEW) is rejected.
    mgr_actor = await _actor(manager)
    with pytest.raises(InvalidTransitionError):
        await task_service.approve_task(session, actor=mgr_actor, task_id=task.id)


@pytest.mark.asyncio
async def test_invalid_manual_transition_rejected(session: AsyncSession):
    manager = await make_user(session, role=UserRole.VICE_RECTOR)
    employee = await make_user(session, role=UserRole.EMPLOYEE)
    task = await task_service.create_task(
        session, actor=await _actor(manager), title="X", description=None, expected_outcome=None,
        acceptance_criteria=None, source_reference=None, department_id=None,
        primary_responsible_id=employee.id, priority=Priority.LOW, deadline=None,
    )
    mgr_actor = await _actor(manager)
    # CREATED/ASSIGNED straight to COMPLETED is never legal.
    with pytest.raises(InvalidTransitionError):
        await task_service.approve_task(session, actor=mgr_actor, task_id=task.id)


@pytest.mark.asyncio
async def test_blocked_task_requires_reason_and_unblocks(session: AsyncSession):
    manager = await make_user(session, role=UserRole.VICE_RECTOR)
    employee = await make_user(session, role=UserRole.EMPLOYEE)
    task = await task_service.create_task(
        session, actor=await _actor(manager), title="X", description=None, expected_outcome=None,
        acceptance_criteria=None, source_reference=None, department_id=None,
        primary_responsible_id=employee.id, priority=Priority.LOW, deadline=None,
    )
    emp_actor = await _actor(employee)
    await task_service.acknowledge_task(session, actor=emp_actor, task_id=task.id)
    await task_service.update_progress(session, actor=emp_actor, task_id=task.id, progress_percent=10)

    with pytest.raises(ValidationError):
        await task_service.block_task(session, actor=emp_actor, task_id=task.id, reason="   ")

    task = await task_service.block_task(session, actor=emp_actor, task_id=task.id, reason="Waiting for IT access")
    assert task.status == TaskStatus.PENDING_BLOCKED

    task = await task_service.unblock_task(session, actor=emp_actor, task_id=task.id)
    assert task.status == TaskStatus.IN_PROGRESS


@pytest.mark.asyncio
async def test_sweep_overdue_marks_past_deadline_tasks_and_skips_blocked_and_completed(session: AsyncSession):
    manager = await make_user(session, role=UserRole.VICE_RECTOR)
    employee = await make_user(session, role=UserRole.EMPLOYEE)

    overdue_task = await task_service.create_task(
        session, actor=await _actor(manager), title="Overdue one", description=None, expected_outcome=None,
        acceptance_criteria=None, source_reference=None, department_id=None,
        primary_responsible_id=employee.id, priority=Priority.LOW,
        deadline=dt.date.today() + dt.timedelta(days=1),
    )
    # Force the deadline into the past directly (service layer rejects past deadlines on create).
    overdue_task.deadline = dt.date.today() - dt.timedelta(days=2)
    await session.flush()

    blocked_task = await task_service.create_task(
        session, actor=await _actor(manager), title="Blocked one", description=None, expected_outcome=None,
        acceptance_criteria=None, source_reference=None, department_id=None,
        primary_responsible_id=employee.id, priority=Priority.LOW,
        deadline=dt.date.today() + dt.timedelta(days=1),
    )
    blocked_task.deadline = dt.date.today() - dt.timedelta(days=2)
    await session.flush()
    emp_actor = await _actor(employee)
    await task_service.acknowledge_task(session, actor=emp_actor, task_id=blocked_task.id)
    await task_service.block_task(session, actor=emp_actor, task_id=blocked_task.id, reason="Blocked reason")

    completed_task = await task_service.create_task(
        session, actor=await _actor(manager), title="Completed one", description=None, expected_outcome=None,
        acceptance_criteria=None, source_reference=None, department_id=None,
        primary_responsible_id=employee.id, priority=Priority.LOW,
        deadline=dt.date.today() + dt.timedelta(days=1),
    )
    completed_task.deadline = dt.date.today() - dt.timedelta(days=2)
    await session.flush()
    await task_service.update_progress(session, actor=emp_actor, task_id=completed_task.id, progress_percent=100)
    await task_service.submit_for_review(session, actor=emp_actor, task_id=completed_task.id)
    await task_service.approve_task(session, actor=await _actor(manager), task_id=completed_task.id)

    flagged = await task_service.sweep_overdue_tasks(session)
    flagged_ids = {t.id for t in flagged}

    assert overdue_task.id in flagged_ids
    assert blocked_task.id not in flagged_ids
    assert completed_task.id not in flagged_ids

    refreshed_overdue = await task_service.get_task(session, overdue_task.id)
    assert refreshed_overdue.status == TaskStatus.OVERDUE
    refreshed_completed = await task_service.get_task(session, completed_task.id)
    assert refreshed_completed.status == TaskStatus.COMPLETED  # never flipped to overdue

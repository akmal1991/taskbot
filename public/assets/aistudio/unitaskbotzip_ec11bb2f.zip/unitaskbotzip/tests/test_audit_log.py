"""Direct assertions on AuditLog rows, against the real database.

The lifecycle tests already exercise the service functions that call
log_action(); this file is the dedicated check that the audit trail itself
— the row content, not just the side effect of the call succeeding — is
correct. This is explicit acceptance criterion #12 from the spec
("the system maintains an audit log of important actions").
"""
from __future__ import annotations

import datetime as dt

import pytest
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.audit import AuditLog
from app.models.enums import Priority, UserRole
from app.services import departments as dept_service
from app.services import tasks as task_service
from app.services import users as user_service
from app.services.permissions import Actor
from tests.factories import make_department, make_user


async def _actor(user) -> Actor:
    return Actor.from_user(user)


async def _audit_rows(session: AsyncSession, *, entity_type: str, entity_id: int) -> list[AuditLog]:
    result = await session.execute(
        select(AuditLog)
        .where(AuditLog.entity_type == entity_type, AuditLog.entity_id == entity_id)
        .order_by(AuditLog.id)
    )
    return list(result.scalars().all())


@pytest.mark.asyncio
async def test_task_lifecycle_actions_are_each_recorded_in_audit_log(session: AsyncSession):
    manager = await make_user(session, role=UserRole.RECTOR)
    employee = await make_user(session, role=UserRole.EMPLOYEE)
    await session.commit()

    task = await task_service.create_task(
        session, actor=await _actor(manager), title="Audited task", description=None,
        expected_outcome=None, acceptance_criteria=None, source_reference=None, department_id=None,
        primary_responsible_id=employee.id, priority=Priority.MEDIUM,
        deadline=dt.date.today() + dt.timedelta(days=10),
    )
    await task_service.acknowledge_task(session, actor=await _actor(employee), task_id=task.id)
    await task_service.update_progress(
        session, actor=await _actor(employee), task_id=task.id, progress_percent=50, comment=None
    )
    await task_service.submit_for_review(session, actor=await _actor(employee), task_id=task.id, comment=None)
    await task_service.approve_task(session, actor=await _actor(manager), task_id=task.id)
    await session.commit()

    rows = await _audit_rows(session, entity_type="task", entity_id=task.id)
    actions = [r.action for r in rows]

    # The exact set of lifecycle actions must all be present, each as its
    # own immutable row — not merged, not overwritten.
    assert "task.created" in actions
    assert "task.acknowledged" in actions
    assert "task.progress_updated" in actions
    assert "task.submitted_for_review" in actions
    assert "task.approved" in actions

    # Every row records who did it.
    for row in rows:
        assert row.actor_user_id in {manager.id, employee.id}
        assert row.created_at is not None

    # The approval row in particular must be attributed to the manager who
    # approved it, not the employee who did the work.
    approved_row = next(r for r in rows if r.action == "task.approved")
    assert approved_row.actor_user_id == manager.id


@pytest.mark.asyncio
async def test_blocking_a_task_records_the_reason_in_audit_details(session: AsyncSession):
    manager = await make_user(session, role=UserRole.RECTOR)
    employee = await make_user(session, role=UserRole.EMPLOYEE)
    await session.commit()

    task = await task_service.create_task(
        session, actor=await _actor(manager), title="Blocked task", description=None,
        expected_outcome=None, acceptance_criteria=None, source_reference=None, department_id=None,
        primary_responsible_id=employee.id, priority=Priority.HIGH,
        deadline=dt.date.today() + dt.timedelta(days=5),
    )
    await task_service.acknowledge_task(session, actor=await _actor(employee), task_id=task.id)
    await task_service.block_task(
        session, actor=await _actor(employee), task_id=task.id, reason="Waiting on vendor response"
    )
    await session.commit()

    rows = await _audit_rows(session, entity_type="task", entity_id=task.id)
    blocked_row = next(r for r in rows if r.action == "task.blocked")
    assert blocked_row.actor_user_id == employee.id
    assert "Waiting on vendor response" in str(blocked_row.details)


@pytest.mark.asyncio
async def test_user_management_actions_are_recorded_in_audit_log(session: AsyncSession):
    admin = await make_user(session, role=UserRole.SUPER_ADMIN)
    dept = await make_department(session, name="Audit Test Dept")
    await session.commit()

    actor = await _actor(admin)
    reg = await user_service.submit_registration_request(
        session, telegram_id=555_555, username="newbie", full_name="New Person",
        phone=None, requested_role=UserRole.EMPLOYEE, requested_department_id=dept.id,
    )
    await session.commit()

    new_user = await user_service.approve_registration(session, actor=actor, request_id=reg.id)
    await session.commit()

    user_rows = await _audit_rows(session, entity_type="user", entity_id=new_user.id)
    assert any(r.action == "user.registration_approved" or "approved" in r.action for r in user_rows)
    for row in user_rows:
        assert row.actor_user_id == admin.id

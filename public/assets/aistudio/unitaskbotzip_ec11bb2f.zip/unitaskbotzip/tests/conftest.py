from __future__ import annotations

import os
import uuid

import pytest
import pytest_asyncio
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

os.environ.setdefault(
    "DATABASE_URL", "postgresql+asyncpg://postgres:postgres@localhost:5432/uni_task_bot_test"
)

from app.core import db as db_module  # noqa: E402
from app.core.config import get_settings  # noqa: E402
from app.core.db import Base  # noqa: E402
from app.models import *  # noqa: E402,F401,F403  (populate Base.metadata)

@pytest.fixture(autouse=True)
def test_signing_key(monkeypatch):
    # Isolate test authentication from deployment credentials. This value is
    # deliberately test-only and is never written to application settings.
    monkeypatch.setenv("WEB_SECRET_KEY", "test-only-cookie-signing-key-not-for-deployment-123456")
    monkeypatch.setenv("SCHEDULER_TIMEZONE", "UTC")
    get_settings.cache_clear()
    yield
    get_settings.cache_clear()


@pytest_asyncio.fixture
async def engine(monkeypatch):
    """Each DB test owns a fresh schema; public/application data is untouched.

    search_path contains ONLY that schema, so an absent test table cannot
    accidentally resolve to a real application's table in public.
    """
    schema = f"test_{uuid.uuid4().hex}"
    eng = create_async_engine(
        get_settings().database_url,
        connect_args={"server_settings": {"search_path": schema}},
    )
    try:
        async with eng.begin() as conn:
            await conn.exec_driver_sql(f'CREATE SCHEMA "{schema}"')
            await conn.run_sync(Base.metadata.create_all)
        monkeypatch.setattr(db_module, "_engine", eng)
        monkeypatch.setattr(
            db_module, "_session_factory", async_sessionmaker(eng, expire_on_commit=False)
        )
        yield eng
    finally:
        # The identifier is generated above, never user input.
        async with eng.begin() as conn:
            await conn.exec_driver_sql(f'DROP SCHEMA IF EXISTS "{schema}" CASCADE')
        await eng.dispose()


@pytest_asyncio.fixture
async def session(engine) -> AsyncSession:
    factory = async_sessionmaker(bind=engine, expire_on_commit=False)
    async with factory() as s:
        yield s

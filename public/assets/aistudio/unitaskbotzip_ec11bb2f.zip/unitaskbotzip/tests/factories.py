from __future__ import annotations

import itertools

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.department import Department
from app.models.enums import Language, UserRole
from app.models.user import User

_telegram_id_counter = itertools.count(1_000_000)


async def make_department(session: AsyncSession, name: str = "Test Department", **kwargs) -> Department:
    dept = Department(name=name, **kwargs)
    session.add(dept)
    await session.flush()
    return dept


async def make_user(session: AsyncSession, *, role: UserRole, full_name: str = "Test User",
                     department_id: int | None = None, is_active: bool = True) -> User:
    user = User(
        telegram_id=next(_telegram_id_counter),
        full_name=full_name,
        role=role,
        department_id=department_id,
        language=Language.UZ_CYRL,
        is_active=is_active,
    )
    session.add(user)
    await session.flush()
    return user

from __future__ import annotations

from aiogram import Bot
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger

from app.core.config import get_settings
from app.scheduler.jobs import job_flush_notifications, job_send_overdue_reminders, job_send_reminders, job_sweep_and_escalate


def build_scheduler(bot: Bot) -> AsyncIOScheduler:
    settings = get_settings()
    scheduler = AsyncIOScheduler(timezone=settings.scheduler_timezone)

    # Overdue detection + manager escalation: several times a day is enough
    # (deadlines are whole days, not minutes), but frequent enough that a
    # task doesn't sit undetected for 24h after midnight.
    scheduler.add_job(
        job_sweep_and_escalate, trigger=IntervalTrigger(hours=1), id="sweep_and_escalate",
        max_instances=1, coalesce=True, misfire_grace_time=600,
    )

    # Reminders (7/3/1-day-before, due-today, daily-overdue, missing-progress):
    # once a day, in the morning, matches how people expect a "daily digest"
    # style reminder to behave rather than being pinged all day.
    scheduler.add_job(
        job_send_reminders, trigger=CronTrigger(hour=8, minute=0, timezone=settings.scheduler_timezone), id="send_reminders",
        max_instances=1, coalesce=True, misfire_grace_time=3600,
    )
    scheduler.add_job(
        job_send_overdue_reminders,
        trigger=IntervalTrigger(hours=settings.overdue_reminder_interval_hours),
        id="send_overdue_reminders", max_instances=1, coalesce=True, misfire_grace_time=3600,
    )

    # Actual Telegram delivery of whatever is now due in the queue: frequent,
    # so a reminder enqueued at 08:00 reaches the person within a couple of
    # minutes rather than waiting for the next daily tick.
    scheduler.add_job(
        job_flush_notifications, trigger=IntervalTrigger(minutes=2), id="flush_notifications",
        max_instances=1, coalesce=True, misfire_grace_time=120, kwargs={"bot": bot},
    )

    return scheduler

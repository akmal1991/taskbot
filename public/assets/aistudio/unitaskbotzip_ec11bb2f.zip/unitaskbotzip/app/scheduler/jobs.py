"""The actual scheduled work. Each function opens its own DB session (via
session_scope) and is safe to call repeatedly — every write underneath goes
through dedup_key-guarded enqueue() or the once-per-(task,level) escalation
events table, so re-running a job tick never double-notifies anyone."""
from __future__ import annotations

import logging

from aiogram import Bot

from app.core.db import session_scope
from app.core.config import get_settings
from app.services import escalation as escalation_service
from app.services import reminders as reminder_service
from app.services import tasks as task_service
from app.bot.notifier import flush_notification_queue

logger = logging.getLogger(__name__)


async def job_sweep_and_escalate() -> None:
    async with session_scope() as session:
        newly_overdue = await task_service.sweep_overdue_tasks(session)
        logger.info("Overdue sweep flagged %d task(s)", len(newly_overdue))

        overdue_tasks = await task_service.list_overdue_tasks(session)
        total_events = 0
        for task in overdue_tasks:
            events = await escalation_service.run_escalations_for_task(session, task)
            total_events += len(events)
        logger.info("Escalation pass created %d new escalation event(s)", total_events)


async def job_send_reminders() -> None:
    async with session_scope() as session:
        due_soon = await task_service.list_tasks_due_within(session, max([0, *get_settings().reminder_days_before]))
        n1 = await reminder_service.send_pre_deadline_reminders(session, due_soon)
        n2 = await reminder_service.send_due_today_reminders(session, due_soon)

        all_tasks = await task_service.list_all_tasks(session, limit=100000)
        n4 = await reminder_service.send_missing_progress_reminders(session, all_tasks)
        logger.info(
            "Reminders queued: pre-deadline=%d due-today=%d missing-progress=%d",
            n1, n2, n4,
        )


async def job_send_overdue_reminders() -> None:
    async with session_scope() as session:
        overdue = await task_service.list_overdue_tasks(session)
        count = await reminder_service.send_daily_overdue_reminders(session, overdue)
        logger.info("Overdue reminders queued: %d", count)


async def job_flush_notifications(bot: Bot) -> None:
    sent, failed = await flush_notification_queue(bot)
    if sent or failed:
        logger.info("Notification flush: sent=%d failed=%d", sent, failed)

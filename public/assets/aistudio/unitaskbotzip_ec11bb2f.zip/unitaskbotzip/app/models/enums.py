from __future__ import annotations

import enum


class UserRole(str, enum.Enum):
    SUPER_ADMIN = "super_admin"
    RECTOR = "rector"
    VICE_RECTOR = "vice_rector"
    DEPARTMENT_HEAD = "department_head"
    EMPLOYEE = "employee"
    OBSERVER = "observer"


class Language(str, enum.Enum):
    UZ_CYRL = "uz_cyrl"
    UZ_LATN = "uz_latn"
    RU = "ru"


class Priority(str, enum.Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class TaskStatus(str, enum.Enum):
    CREATED = "created"
    ASSIGNED = "assigned"
    ACKNOWLEDGED = "acknowledged"
    IN_PROGRESS = "in_progress"
    PENDING_BLOCKED = "pending_blocked"
    SUBMITTED_FOR_REVIEW = "submitted_for_review"
    RETURNED_FOR_REVISION = "returned_for_revision"
    COMPLETED = "completed"
    OVERDUE = "overdue"
    CANCELLED = "cancelled"


# Statuses that are considered "closed" / no longer actionable for escalation
TERMINAL_STATUSES = {TaskStatus.COMPLETED, TaskStatus.CANCELLED}

# Allowed manual transitions: {from_status: {to_status, ...}}
# (OVERDUE is applied automatically by the scheduler on top of any non-terminal
#  status and is cleared automatically once the task moves again / deadline is
#  extended — it is not a dead-end state a human must transition out of.)
ALLOWED_TRANSITIONS: dict[TaskStatus, set[TaskStatus]] = {
    TaskStatus.CREATED: {TaskStatus.ASSIGNED, TaskStatus.CANCELLED},
    # IN_PROGRESS is reachable directly from ASSIGNED too: an employee who
    # logs progress without first tapping "confirm receipt" implicitly
    # acknowledges the task by the act of starting work on it.
    TaskStatus.ASSIGNED: {TaskStatus.ACKNOWLEDGED, TaskStatus.IN_PROGRESS, TaskStatus.CANCELLED},
    TaskStatus.ACKNOWLEDGED: {TaskStatus.IN_PROGRESS, TaskStatus.PENDING_BLOCKED, TaskStatus.CANCELLED},
    TaskStatus.IN_PROGRESS: {
        TaskStatus.PENDING_BLOCKED,
        TaskStatus.SUBMITTED_FOR_REVIEW,
        TaskStatus.CANCELLED,
    },
    TaskStatus.PENDING_BLOCKED: {TaskStatus.IN_PROGRESS, TaskStatus.CANCELLED},
    TaskStatus.SUBMITTED_FOR_REVIEW: {
        TaskStatus.COMPLETED,
        TaskStatus.RETURNED_FOR_REVISION,
    },
    TaskStatus.RETURNED_FOR_REVISION: {TaskStatus.IN_PROGRESS, TaskStatus.CANCELLED},
    TaskStatus.COMPLETED: set(),
    TaskStatus.CANCELLED: set(),
    # OVERDUE is a flag state layered on top; from it, normal progress continues:
    TaskStatus.OVERDUE: {
        TaskStatus.IN_PROGRESS,
        TaskStatus.PENDING_BLOCKED,
        TaskStatus.SUBMITTED_FOR_REVIEW,
        TaskStatus.CANCELLED,
    },
}


class EscalationLevel(str, enum.Enum):
    EMPLOYEE = "employee"
    DEPARTMENT_HEAD = "department_head"
    VICE_RECTOR = "vice_rector"
    RECTOR = "rector"


class NotificationType(str, enum.Enum):
    NEW_ASSIGNMENT = "new_assignment"
    RECEIPT_CONFIRMATION = "receipt_confirmation"
    DEADLINE_REMINDER = "deadline_reminder"
    MISSING_PROGRESS = "missing_progress"
    OVERDUE = "overdue"
    BLOCKED = "blocked"
    EXTENSION_REQUEST = "extension_request"
    SUBMITTED_FOR_REVIEW = "submitted_for_review"
    APPROVED = "approved"
    RETURNED = "returned"
    REASSIGNED = "reassigned"
    DEADLINE_CHANGED = "deadline_changed"
    ESCALATION = "escalation"


class ExtensionRequestStatus(str, enum.Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


class RegistrationStatus(str, enum.Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"

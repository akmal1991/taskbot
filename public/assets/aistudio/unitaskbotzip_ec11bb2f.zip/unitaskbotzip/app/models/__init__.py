"""Import every model module so Base.metadata is fully populated for Alembic
autogenerate and for create_all() in tests."""
from app.core.db import Base  # noqa: F401
from app.models.audit import AuditLog  # noqa: F401
from app.models.department import Department  # noqa: F401
from app.models.enums import (  # noqa: F401
    EscalationLevel,
    ExtensionRequestStatus,
    Language,
    NotificationType,
    Priority,
    RegistrationStatus,
    TaskStatus,
    UserRole,
)
from app.models.notification import EscalationEvent, Notification  # noqa: F401
from app.models.task import (  # noqa: F401
    DeadlineExtensionRequest,
    Task,
    TaskAssignee,
    TaskAttachment,
    TaskComment,
    TaskHistory,
)
from app.models.user import RegistrationRequest, User  # noqa: F401
from app.models.web_auth import WebLoginToken  # noqa: F401

__all__ = [
    "Base",
    "AuditLog",
    "Department",
    "EscalationLevel",
    "ExtensionRequestStatus",
    "Language",
    "NotificationType",
    "Priority",
    "RegistrationStatus",
    "TaskStatus",
    "UserRole",
    "EscalationEvent",
    "Notification",
    "DeadlineExtensionRequest",
    "Task",
    "TaskAssignee",
    "TaskAttachment",
    "TaskComment",
    "TaskHistory",
    "RegistrationRequest",
    "User",
    "WebLoginToken",
]

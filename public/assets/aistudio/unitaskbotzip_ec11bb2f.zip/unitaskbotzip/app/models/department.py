from __future__ import annotations

from sqlalchemy import ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.db import Base


class Department(Base):
    __tablename__ = "departments"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    code: Mapped[str | None] = mapped_column(String(32), unique=True, nullable=True)
    parent_department_id: Mapped[int | None] = mapped_column(ForeignKey("departments.id"), nullable=True)
    head_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    is_active: Mapped[bool] = mapped_column(default=True)

    parent: Mapped["Department | None"] = relationship(remote_side="Department.id", back_populates="children")
    children: Mapped[list["Department"]] = relationship(back_populates="parent")

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Department {self.id} {self.name!r}>"

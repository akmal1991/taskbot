from __future__ import annotations

import datetime as dt

from sqlalchemy import DateTime, Enum, ForeignKey, String, Text, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.db import Base
from app.models.enums import EscalationLevel, NotificationType


class Notification(Base):
    """A single outbound (or attempted) Telegram notification.

    dedup_key enforces "never send the same logical notification twice" at
    the database level (e.g. "deadline_reminder:task=42:days_before=3").
    """

    __tablename__ = "notifications"
    __table_args__ = (UniqueConstraint("dedup_key", name="uq_notification_dedup_key"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    task_id: Mapped[int | None] = mapped_column(ForeignKey("tasks.id"), nullable=True)
    recipient_user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    notif_type: Mapped[NotificationType] = mapped_column(Enum(NotificationType, name="notification_type"))
    dedup_key: Mapped[str] = mapped_column(String(255), nullable=False)
    text_rendered: Mapped[str] = mapped_column(Text, nullable=False)
    scheduled_for: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    sent_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    failed_reason: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class EscalationEvent(Base):
    __tablename__ = "escalation_events"
    __table_args__ = (UniqueConstraint("task_id", "level", name="uq_escalation_task_level"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    task_id: Mapped[int] = mapped_column(ForeignKey("tasks.id"), nullable=False)
    level: Mapped[EscalationLevel] = mapped_column(Enum(EscalationLevel, name="escalation_level"))
    notified_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    triggered_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

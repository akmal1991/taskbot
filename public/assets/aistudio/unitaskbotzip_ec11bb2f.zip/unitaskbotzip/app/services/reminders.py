"""Deadline reminders aimed at the responsible employee (as opposed to
app/services/escalation.py, which notifies managers up the chain once a
task is overdue)."""
from __future__ import annotations

import datetime as dt

from app.core.config import get_settings
from app.core.clock import today as local_today
from app.models.enums import NotificationType, TaskStatus
from app.models.task import Task
from app.services.notifications import enqueue
from sqlalchemy.ext.asyncio import AsyncSession


async def send_pre_deadline_reminders(session: AsyncSession, tasks: list[Task]) -> int:
    """7/3/1-day-before reminders, per app.core.config.reminder_days_before."""
    settings = get_settings()
    today = local_today()
    count = 0
    for task in tasks:
        if task.deadline is None or task.primary_responsible_id is None:
            continue
        if task.status in (TaskStatus.COMPLETED, TaskStatus.CANCELLED):
            continue
        days_left = (task.deadline - today).days
        if days_left in settings.reminder_days_before:
            created = await enqueue(
                session,
                task_id=task.id,
                recipient_user_id=task.primary_responsible_id,
                notif_type=NotificationType.DEADLINE_REMINDER,
                dedup_key=f"reminder:{task.id}:{task.primary_responsible_id}:{task.deadline}:days_before:{days_left}",
                text_rendered=(
                    f"Reminder: task {task.public_code} \"{task.title}\" is due in {days_left} day(s) "
                    f"({task.deadline})."
                ),
            )
            if created:
                count += 1
    return count


async def send_due_today_reminders(session: AsyncSession, tasks: list[Task]) -> int:
    today = local_today()
    count = 0
    for task in tasks:
        if task.deadline != today or task.primary_responsible_id is None:
            continue
        if task.status in (TaskStatus.COMPLETED, TaskStatus.CANCELLED):
            continue
        created = await enqueue(
            session,
            task_id=task.id,
            recipient_user_id=task.primary_responsible_id,
            notif_type=NotificationType.DEADLINE_REMINDER,
            dedup_key=f"reminder:{task.id}:{task.primary_responsible_id}:due_today:{today.isoformat()}",
            text_rendered=f"Today is the deadline for task {task.public_code} \"{task.title}\".",
        )
        if created:
            count += 1
    return count


async def send_daily_overdue_reminders(session: AsyncSession, overdue_tasks: list[Task]) -> int:
    """Repeats daily (configurable interval) until the task is resolved,
    per the acceptance criteria — distinct from the one-shot escalation
    notices sent to managers."""
    interval_hours = get_settings().overdue_reminder_interval_hours
    bucket = int(dt.datetime.now(dt.timezone.utc).timestamp()) // (interval_hours * 3600)
    count = 0
    for task in overdue_tasks:
        if task.primary_responsible_id is None:
            continue
        created = await enqueue(
            session,
            task_id=task.id,
            recipient_user_id=task.primary_responsible_id,
            notif_type=NotificationType.OVERDUE,
            dedup_key=f"overdue_daily:{task.id}:{task.primary_responsible_id}:{bucket}",
            text_rendered=f"OVERDUE: task {task.public_code} \"{task.title}\" was due {task.deadline}.",
        )
        if created:
            count += 1
    return count


async def send_missing_progress_reminders(session: AsyncSession, tasks: list[Task], *, stale_days: int = 5) -> int:
    """Nudges a responsible employee whose task has had 0% progress for
    `stale_days` since it was assigned, well before the deadline pressure
    kicks in."""
    today = local_today()
    count = 0
    for task in tasks:
        if task.primary_responsible_id is None or task.assigned_date is None:
            continue
        if task.status not in (TaskStatus.ASSIGNED, TaskStatus.ACKNOWLEDGED):
            continue
        if task.progress_percent > 0:
            continue
        if (today - task.assigned_date).days < stale_days:
            continue
        created = await enqueue(
            session,
            task_id=task.id,
            recipient_user_id=task.primary_responsible_id,
            notif_type=NotificationType.MISSING_PROGRESS,
            dedup_key=f"missing_progress:{task.id}:{today.isoformat()}",
            text_rendered=(
                f"No progress recorded yet on task {task.public_code} \"{task.title}\" "
                f"({(today - task.assigned_date).days} days since assignment)."
            ),
        )
        if created:
            count += 1
    return count

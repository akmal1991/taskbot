"""Role-based access control.

Every permission check here is a pure function of (role / user, resource) —
no database I/O — so it is trivially unit-testable and is the single place
the rest of the codebase asks "is this allowed?" before mutating anything.
"""
from __future__ import annotations

from dataclasses import dataclass

from app.models.enums import UserRole
from app.models.task import Task
from app.models.user import User
from app.services.exceptions import ServiceError

# Higher number = more senior. Used for "can X manage/view someone at or
# below their own level" checks (e.g. a vice-rector may act on a department
# head's tasks, a department head may not act on a vice-rector's).
ROLE_RANK: dict[UserRole, int] = {
    UserRole.OBSERVER: 0,
    UserRole.EMPLOYEE: 1,
    UserRole.DEPARTMENT_HEAD: 2,
    UserRole.VICE_RECTOR: 3,
    UserRole.RECTOR: 4,
    UserRole.SUPER_ADMIN: 5,
}

ROLES_THAT_CAN_CREATE_TASKS = {
    UserRole.SUPER_ADMIN,
    UserRole.RECTOR,
    UserRole.VICE_RECTOR,
    UserRole.DEPARTMENT_HEAD,
}

ROLES_WITH_FULL_VISIBILITY = {UserRole.SUPER_ADMIN, UserRole.RECTOR, UserRole.OBSERVER}


class PermissionDenied(ServiceError):
    """Raised by a service function when an actor may not perform an action.

    Carries a short machine-readable `code` (for i18n lookup in the bot
    layer) plus a human-readable default message.
    """

    def __init__(self, code: str, message: str):
        super().__init__(code, message)


@dataclass(frozen=True)
class Actor:
    """Minimal view of the acting user needed for a permission check."""

    id: int
    role: UserRole
    department_id: int | None
    is_active: bool = True

    @classmethod
    def from_user(cls, user: User) -> "Actor":
        return cls(id=user.id, role=user.role, department_id=user.department_id, is_active=user.is_active)


def require_active(actor: Actor) -> None:
    if not actor.is_active:
        raise PermissionDenied("account_inactive", "This account has been deactivated.")


def can_manage_users(actor: Actor) -> bool:
    return actor.is_active and actor.role == UserRole.SUPER_ADMIN


def can_manage_departments(actor: Actor) -> bool:
    return can_manage_users(actor)


def can_create_task(actor: Actor) -> bool:
    return actor.is_active and actor.role in ROLES_THAT_CAN_CREATE_TASKS


def can_view_dashboard(actor: Actor) -> bool:
    """Who may see the cross-department executive dashboard / full register
    export (Telegram report and the web dashboard both use this)."""
    return actor.is_active and (actor.role in ROLES_WITH_FULL_VISIBILITY or actor.role in (
        UserRole.VICE_RECTOR,
        UserRole.DEPARTMENT_HEAD,
    ))


def can_view_all_tasks(actor: Actor) -> bool:
    return actor.is_active and actor.role in ROLES_WITH_FULL_VISIBILITY


def is_task_participant(actor: Actor, task: Task) -> bool:
    """True if the actor is directly involved in the task (owner, creator,
    approver, or a supporting assignee)."""
    if actor.id in {task.primary_responsible_id, task.created_by_id, task.approver_id}:
        return True
    return any(a.user_id == actor.id for a in task.assignees)


def can_view_task(actor: Actor, task: Task) -> bool:
    if not actor.is_active:
        return False
    if can_view_all_tasks(actor):
        return True
    if is_task_participant(actor, task):
        return True
    if actor.role == UserRole.DEPARTMENT_HEAD and actor.department_id is not None:
        if task.department_id == actor.department_id:
            return True
        if any(a.department_id == actor.department_id for a in task.assignees):
            return True
    if actor.role == UserRole.VICE_RECTOR:
        # Vice-rectors see everything they or their chain assigned; combined
        # with can_view_all_tasks this is already broad, kept explicit for clarity.
        return True
    return False


def can_update_progress(actor: Actor, task: Task) -> bool:
    """Only the primary responsible person or a supporting assignee may log
    progress — not just anyone who can merely *view* the task."""
    if not actor.is_active or actor.role == UserRole.OBSERVER:
        return False
    if actor.id == task.primary_responsible_id:
        return True
    return any(a.user_id == actor.id for a in task.assignees)


def can_request_extension(actor: Actor, task: Task) -> bool:
    return can_update_progress(actor, task)


def can_approve_or_return(actor: Actor, task: Task) -> bool:
    """Completion sign-off. The university's chosen policy: the person who
    assigned the task (task.approver_id, defaulting to its creator) is the
    sole approver. An employee may never approve their own task, even if a
    data error made them both the assigner and the assignee."""
    if not actor.is_active or actor.role == UserRole.OBSERVER or actor.id == task.primary_responsible_id:
        return False
    return actor.id == task.approver_id or actor.role == UserRole.SUPER_ADMIN


def can_reassign_or_change_deadline(actor: Actor, task: Task) -> bool:
    if not actor.is_active or actor.role == UserRole.OBSERVER:
        return False
    if actor.role == UserRole.SUPER_ADMIN:
        return True
    return actor.id in {task.created_by_id, task.approver_id}


def can_cancel_task(actor: Actor, task: Task) -> bool:
    return can_reassign_or_change_deadline(actor, task)


def can_delegate_subtask(actor: Actor) -> bool:
    """Department heads (and anyone above) may split a task into subtasks
    and hand pieces to specific employees in their department."""
    return actor.is_active and ROLE_RANK[actor.role] >= ROLE_RANK[UserRole.DEPARTMENT_HEAD]


def can_approve_registration(actor: Actor) -> bool:
    return can_manage_users(actor)

from __future__ import annotations

import datetime as dt
import secrets

from sqlalchemy import update
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.user import User
from app.models.web_auth import WebLoginToken

TOKEN_TTL_MINUTES = 10


async def issue_login_token(session: AsyncSession, *, user_id: int) -> str:
    token = secrets.token_urlsafe(32)
    expires_at = dt.datetime.now(dt.timezone.utc) + dt.timedelta(minutes=TOKEN_TTL_MINUTES)
    session.add(WebLoginToken(token=token, user_id=user_id, expires_at=expires_at))
    await session.flush()
    return token


async def redeem_login_token(session: AsyncSession, *, token: str) -> User | None:
    # Claim atomically: concurrent requests cannot both redeem a single link.
    result = await session.execute(
        update(WebLoginToken)
        .where(
            WebLoginToken.token == token,
            WebLoginToken.used.is_(False),
            WebLoginToken.expires_at > dt.datetime.now(dt.timezone.utc),
        )
        .values(used=True)
        .returning(WebLoginToken.user_id)
    )
    user_id = result.scalar_one_or_none()
    if user_id is None:
        return None
    user = await session.get(User, user_id)
    return user if user is not None and user.is_active else None

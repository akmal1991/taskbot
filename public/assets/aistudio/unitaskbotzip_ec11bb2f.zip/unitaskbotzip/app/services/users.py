"""User onboarding and management.

Identity rule: a Telegram user ID alone is never sufficient authorization.
Every new Telegram account must go through RegistrationRequest, reviewed and
approved by a Super Administrator, before a usable `User` row is created.
"""
from __future__ import annotations

import datetime as dt

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.enums import Language, RegistrationStatus, UserRole
from app.models.user import RegistrationRequest, User
from app.services.audit import log_action
from app.services.exceptions import DuplicateError, NotFoundError, ValidationError
from app.services.permissions import Actor, can_approve_registration, can_manage_users


async def get_user_by_telegram_id(session: AsyncSession, telegram_id: int) -> User | None:
    result = await session.execute(select(User).where(User.telegram_id == telegram_id))
    return result.scalar_one_or_none()


async def submit_registration_request(
    session: AsyncSession,
    *,
    telegram_id: int,
    username: str | None,
    full_name: str,
    phone: str | None,
    requested_role: UserRole,
    requested_department_id: int | None,
) -> RegistrationRequest:
    if not full_name or not full_name.strip() or len(full_name.strip()) > 255:
        raise ValidationError("invalid_name", "Enter a name between 1 and 255 characters.")
    if phone and len(phone) > 32:
        raise ValidationError("invalid_phone", "Phone number must not exceed 32 characters.")
    existing_user = await get_user_by_telegram_id(session, telegram_id)
    if existing_user is not None:
        raise DuplicateError("already_registered", "This Telegram account is already registered.")

    result = await session.execute(
        select(RegistrationRequest).where(
            RegistrationRequest.telegram_id == telegram_id,
        ).with_for_update()
    )
    req = result.scalar_one_or_none()
    if req is not None and req.status == RegistrationStatus.PENDING:
        raise DuplicateError("already_pending", "A registration request is already pending for this account.")

    if req is None:
        req = RegistrationRequest(telegram_id=telegram_id)
        session.add(req)
    req.username = username
    req.full_name = full_name.strip()
    req.phone = phone
    req.requested_role = requested_role
    req.requested_department_id = requested_department_id
    req.status = RegistrationStatus.PENDING
    req.reviewed_by_id = None
    req.reviewed_at = None
    req.rejection_reason = None
    await session.flush()
    await log_action(
        session,
        actor_user_id=None,
        action="registration.submitted",
        entity_type="registration_request",
        entity_id=req.id,
        details={"telegram_id": telegram_id, "requested_role": requested_role.value},
    )
    return req


async def list_pending_registrations(session: AsyncSession) -> list[RegistrationRequest]:
    result = await session.execute(
        select(RegistrationRequest)
        .where(RegistrationRequest.status == RegistrationStatus.PENDING)
        .order_by(RegistrationRequest.created_at)
    )
    return list(result.scalars().all())


async def approve_registration(
    session: AsyncSession, *, actor: Actor, request_id: int, language: Language = Language.UZ_CYRL
) -> User:
    if not can_approve_registration(actor):
        raise ValidationError("forbidden", "Only a Super Administrator may approve registrations.")

    req = await session.get(RegistrationRequest, request_id, with_for_update=True)
    if req is None:
        raise NotFoundError("not_found", "Registration request not found.")
    if req.status != RegistrationStatus.PENDING:
        raise ValidationError("not_pending", "This request has already been reviewed.")

    user = User(
        telegram_id=req.telegram_id,
        username=req.username,
        full_name=req.full_name,
        phone=req.phone,
        role=req.requested_role,
        department_id=req.requested_department_id,
        language=language,
        is_active=True,
        approved_by_id=actor.id,
        approved_at=dt.datetime.now(dt.timezone.utc),
    )
    session.add(user)
    req.status = RegistrationStatus.APPROVED
    req.reviewed_by_id = actor.id
    req.reviewed_at = dt.datetime.now(dt.timezone.utc)
    await session.flush()

    await log_action(
        session,
        actor_user_id=actor.id,
        action="registration.approved",
        entity_type="user",
        entity_id=user.id,
        details={"telegram_id": user.telegram_id, "role": user.role.value},
    )
    return user


async def reject_registration(session: AsyncSession, *, actor: Actor, request_id: int, reason: str) -> RegistrationRequest:
    if not can_approve_registration(actor):
        raise ValidationError("forbidden", "Only a Super Administrator may reject registrations.")
    req = await session.get(RegistrationRequest, request_id, with_for_update=True)
    if req is None:
        raise NotFoundError("not_found", "Registration request not found.")
    if req.status != RegistrationStatus.PENDING:
        raise ValidationError("not_pending", "This request has already been reviewed.")

    req.status = RegistrationStatus.REJECTED
    req.reviewed_by_id = actor.id
    req.reviewed_at = dt.datetime.now(dt.timezone.utc)
    req.rejection_reason = reason
    await session.flush()
    await log_action(
        session,
        actor_user_id=actor.id,
        action="registration.rejected",
        entity_type="registration_request",
        entity_id=req.id,
        details={"reason": reason},
    )
    return req


async def set_user_role(session: AsyncSession, *, actor: Actor, user_id: int, new_role: UserRole) -> User:
    if not can_manage_users(actor):
        raise ValidationError("forbidden", "Only a Super Administrator may change roles.")
    await _lock_admin_changes(session, actor)
    user = await session.get(User, user_id)
    if user is None:
        raise NotFoundError("not_found", "User not found.")
    if user.role == UserRole.SUPER_ADMIN and user.is_active and new_role != UserRole.SUPER_ADMIN:
        await _require_other_admin(session, user.id)
    old_role = user.role
    user.role = new_role
    await session.flush()
    await log_action(
        session,
        actor_user_id=actor.id,
        action="user.role_changed",
        entity_type="user",
        entity_id=user.id,
        details={"from": old_role.value, "to": new_role.value},
    )
    return user


async def set_user_active(session: AsyncSession, *, actor: Actor, user_id: int, is_active: bool) -> User:
    if not can_manage_users(actor):
        raise ValidationError("forbidden", "Only a Super Administrator may activate/deactivate accounts.")
    await _lock_admin_changes(session, actor)
    user = await session.get(User, user_id)
    if user is None:
        raise NotFoundError("not_found", "User not found.")
    if user.role == UserRole.SUPER_ADMIN and user.is_active and not is_active:
        await _require_other_admin(session, user.id)
    user.is_active = is_active
    await session.flush()
    await log_action(
        session,
        actor_user_id=actor.id,
        action="user.active_changed",
        entity_type="user",
        entity_id=user.id,
        details={"is_active": is_active},
    )
    return user


async def _require_other_admin(session: AsyncSession, user_id: int) -> None:
    count = await session.scalar(
        select(func.count()).select_from(User)
        .where(User.role == UserRole.SUPER_ADMIN, User.is_active.is_(True), User.id != user_id)
    )
    if not count:
        raise ValidationError("last_admin", "The last active Super Administrator cannot be removed.")


async def _lock_admin_changes(session: AsyncSession, actor: Actor) -> None:
    # Two administrators changing accounts concurrently must not both remove
    # the last usable administrator. Refresh the caller after taking the lock.
    await session.execute(select(func.pg_advisory_xact_lock(796179, 0)))
    current = await session.get(User, actor.id, populate_existing=True)
    if current is None or not current.is_active or current.role != UserRole.SUPER_ADMIN:
        raise ValidationError("forbidden", "Only an active Super Administrator may change accounts.")

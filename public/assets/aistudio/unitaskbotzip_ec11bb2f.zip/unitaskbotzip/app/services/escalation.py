"""Escalation chain: who gets notified, and when, as a task stays overdue.

Policy selected for this deployment (configurable in app/core/config.py):
  - Day 1 overdue  -> the responsible employee's department head
  - Day 3 overdue  -> the supervising vice-rector(s)
  - Day 7 overdue  -> the rector / executive director

Each level fires exactly once per task (enforced by the unique
(task_id, level) constraint on EscalationEvent, checked before insert here),
regardless of how many times the sweep job runs.
"""
from __future__ import annotations

import datetime as dt

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.clock import today as local_today
from app.models.department import Department
from app.models.enums import EscalationLevel, NotificationType, TaskStatus, UserRole
from app.models.notification import EscalationEvent
from app.models.task import Task
from app.models.user import User
from app.services.notifications import enqueue


async def _already_escalated(session: AsyncSession, task_id: int, level: EscalationLevel) -> bool:
    result = await session.execute(
        select(EscalationEvent).where(EscalationEvent.task_id == task_id, EscalationEvent.level == level)
    )
    return result.scalar_one_or_none() is not None


async def _recipients_for_level(session: AsyncSession, task: Task, level: EscalationLevel) -> list[User]:
    if level == EscalationLevel.DEPARTMENT_HEAD:
        if task.department_id is None:
            return []
        dept = await session.get(Department, task.department_id)
        if dept is None or dept.head_user_id is None:
            return []
        head = await session.get(User, dept.head_user_id)
        return [head] if head and head.is_active else []

    if level == EscalationLevel.VICE_RECTOR:
        result = await session.execute(select(User).where(User.role == UserRole.VICE_RECTOR, User.is_active.is_(True)))
        return list(result.scalars().all())

    if level == EscalationLevel.RECTOR:
        result = await session.execute(select(User).where(User.role == UserRole.RECTOR, User.is_active.is_(True)))
        return list(result.scalars().all())

    return []


def _days_overdue(task: Task, today: dt.date) -> int:
    if task.deadline is None:
        return 0
    return (today - task.deadline).days


async def run_escalations_for_task(session: AsyncSession, task: Task) -> list[EscalationEvent]:
    """Called once per overdue task per sweep. Fires every escalation level
    whose threshold has been crossed and that has not already fired."""
    if task.status != TaskStatus.OVERDUE:
        return []

    settings = get_settings()
    today = local_today()
    days = _days_overdue(task, today)

    thresholds = [
        (settings.escalation_dept_head_days, EscalationLevel.DEPARTMENT_HEAD),
        (settings.escalation_vice_rector_days, EscalationLevel.VICE_RECTOR),
        (settings.escalation_rector_days, EscalationLevel.RECTOR),
    ]

    created: list[EscalationEvent] = []
    for threshold_days, level in thresholds:
        if days < threshold_days:
            continue
        if await _already_escalated(session, task.id, level):
            continue
        recipients = await _recipients_for_level(session, task, level)
        if not recipients:
            continue  # Retry after a department head/manager is configured.
        event = EscalationEvent(task_id=task.id, level=level, notified_user_id=recipients[0].id if recipients else None)
        session.add(event)
        await session.flush()
        created.append(event)

        for recipient in recipients:
            await enqueue(
                session,
                task_id=task.id,
                recipient_user_id=recipient.id,
                notif_type=NotificationType.ESCALATION,
                dedup_key=f"escalation:{task.id}:{level.value}:{recipient.id}",
                text_rendered=(
                    f"ESCALATION ({level.value}): task {task.public_code} \"{task.title}\" is "
                    f"{days} day(s) overdue (deadline {task.deadline})."
                ),
            )
    return created

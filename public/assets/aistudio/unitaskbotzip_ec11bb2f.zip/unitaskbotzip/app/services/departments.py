from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.department import Department
from app.services.audit import log_action
from app.services.exceptions import DuplicateError, NotFoundError, ValidationError
from app.services.permissions import Actor, can_manage_departments


async def list_departments(session: AsyncSession, *, active_only: bool = True) -> list[Department]:
    stmt = select(Department)
    if active_only:
        stmt = stmt.where(Department.is_active.is_(True))
    result = await session.execute(stmt.order_by(Department.name))
    return list(result.scalars().all())


async def create_department(
    session: AsyncSession, *, actor: Actor, name: str, code: str | None = None, parent_department_id: int | None = None
) -> Department:
    if not can_manage_departments(actor):
        raise ValidationError("forbidden", "Only a Super Administrator may manage departments.")
    name = name.strip()
    if not name or len(name) > 255 or (code and len(code) > 32):
        raise ValidationError("invalid_department", "Enter a department name (1–255 characters) and code up to 32 characters.")
    existing = await session.execute(select(Department).where(Department.name == name))
    if existing.scalar_one_or_none() is not None:
        raise DuplicateError("duplicate_department", f"Department '{name}' already exists.")
    dept = Department(name=name.strip(), code=code, parent_department_id=parent_department_id)
    session.add(dept)
    await session.flush()
    await log_action(session, actor_user_id=actor.id, action="department.created", entity_type="department",
                      entity_id=dept.id, details={"name": name})
    return dept


async def set_department_head(session: AsyncSession, *, actor: Actor, department_id: int, head_user_id: int | None) -> Department:
    if not can_manage_departments(actor):
        raise ValidationError("forbidden", "Only a Super Administrator may manage departments.")
    dept = await session.get(Department, department_id)
    if dept is None:
        raise NotFoundError("not_found", "Department not found.")
    dept.head_user_id = head_user_id
    await session.flush()
    await log_action(session, actor_user_id=actor.id, action="department.head_changed", entity_type="department",
                      entity_id=dept.id, details={"head_user_id": head_user_id})
    return dept

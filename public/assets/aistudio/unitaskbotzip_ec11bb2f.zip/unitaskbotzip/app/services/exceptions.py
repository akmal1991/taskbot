class ServiceError(Exception):
    """Base class for service-layer errors the bot/web layer should present
    to the user as a friendly message rather than a stack trace."""

    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(message)


class NotFoundError(ServiceError):
    pass


class ValidationError(ServiceError):
    pass


class InvalidTransitionError(ServiceError):
    pass


class DuplicateError(ServiceError):
    pass

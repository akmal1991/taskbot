"""Task lifecycle service — the single place that may change a Task's
status. Every transition is validated against ALLOWED_TRANSITIONS and the
relevant permission check, and every change is written to TaskHistory and
AuditLog so the full story of a task can always be reconstructed.
"""
from __future__ import annotations

import datetime as dt

from sqlalchemy import Numeric, cast, func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload
from app.core.clock import today as current_date

from app.models.department import Department
from app.models.enums import ALLOWED_TRANSITIONS, TERMINAL_STATUSES, NotificationType, Priority, TaskStatus, UserRole
from app.models.user import User
from app.models.task import DeadlineExtensionRequest, Task, TaskAssignee, TaskAttachment, TaskComment, TaskHistory
from app.services.audit import log_action
from app.services.notifications import enqueue
from app.services.exceptions import InvalidTransitionError, NotFoundError, ValidationError
from app.services.permissions import (
    Actor,
    can_approve_or_return,
    can_cancel_task,
    can_create_task,
    can_reassign_or_change_deadline,
    can_request_extension,
    can_update_progress,
    can_view_task,
    require_active,
)


def _task_query():
    return select(Task).options(
        selectinload(Task.assignees),
        selectinload(Task.history),
        selectinload(Task.comments),
        selectinload(Task.attachments),
    )


async def get_task(session: AsyncSession, task_id: int, *, lock: bool = False) -> Task:
    query = _task_query().where(Task.id == task_id)
    if lock:
        query = query.with_for_update().execution_options(populate_existing=True)
    result = await session.execute(query)
    task = result.scalar_one_or_none()
    if task is None:
        raise NotFoundError("task_not_found", f"Task #{task_id} not found.")
    return task


async def get_task_for_viewer(session: AsyncSession, actor: Actor, task_id: int) -> Task:
    task = await get_task(session, task_id)
    if not can_view_task(actor, task):
        raise ValidationError("forbidden", "You do not have access to this task.")
    return task


async def _next_public_code(session: AsyncSession) -> str:
    year = current_date().year
    prefix = f"T-{year}-"
    # Serialize code allocation for this year until the caller commits.
    # Counting rows reused codes after deletions and raced concurrent creators.
    await session.execute(select(func.pg_advisory_xact_lock(796178, year)))
    result = await session.execute(
        select(func.max(cast(func.substring(Task.public_code, r"[0-9]+$"), Numeric)))
        .where(Task.public_code.op("~")(rf"^{prefix}[0-9]+$"))
    )
    n = int(result.scalar_one() or 0) + 1
    code = f"{prefix}{n:04d}"
    if len(code) > 32:
        raise ValidationError("code_exhausted", "The public-code sequence exceeds its allowed length.")
    return code


async def _validate_assignee(session: AsyncSession, user_id: int) -> None:
    user = await session.get(User, user_id)
    if user is None or not user.is_active:
        raise ValidationError("invalid_user", "The selected user does not exist or is inactive.")


async def _validate_department(session: AsyncSession, department_id: int) -> None:
    dept = await session.get(Department, department_id)
    if dept is None or not dept.is_active:
        raise ValidationError("invalid_department", "The selected department does not exist or is inactive.")

async def _notify_task(
    session: AsyncSession, task: Task, recipient_id: int | None, kind: NotificationType, text: str
) -> None:
    if recipient_id is not None:
        await enqueue(
            session, task_id=task.id, recipient_user_id=recipient_id, notif_type=kind,
            dedup_key=f"task_event:{task.id}:{kind.value}:{recipient_id}:{len(task.history)}",
            text_rendered=f"{task.public_code} — {task.title}\n{text}",
        )


async def _transition(
    session: AsyncSession,
    task: Task,
    new_status: TaskStatus,
    *,
    actor_id: int | None,
    comment: str | None = None,
    allow_from_overdue: bool = True,
) -> None:
    allowed = ALLOWED_TRANSITIONS.get(task.status, set())
    if new_status not in allowed:
        raise InvalidTransitionError(
            "invalid_transition",
            f"Cannot move task from {task.status.value} to {new_status.value}.",
        )
    old_status = task.status
    task.status = new_status
    # Appended to the relationship (not session.add(TaskHistory(task_id=...)))
    # so the in-memory task.history collection stays consistent without
    # needing a reload — important under AsyncSession, where a later lazy
    # load from sync-style code would raise MissingGreenlet.
    task.history.append(
        TaskHistory(from_status=old_status, to_status=new_status, changed_by_id=actor_id, comment=comment)
    )


async def create_task(
    session: AsyncSession,
    *,
    actor: Actor,
    title: str,
    description: str | None,
    expected_outcome: str | None,
    acceptance_criteria: str | None,
    source_reference: str | None,
    department_id: int | None,
    primary_responsible_id: int | None,
    priority: Priority,
    deadline: dt.date | None,
    approver_id: int | None = None,
    supporting_user_ids: list[int] | None = None,
    supporting_department_ids: list[int] | None = None,
) -> Task:
    if not can_create_task(actor):
        raise ValidationError("forbidden", "Your role may not create tasks.")
    if not title or not title.strip():
        raise ValidationError("title_required", "Task title is required.")
    if len(title.strip()) > 500 or (source_reference and len(source_reference) > 500):
        raise ValidationError("text_too_long", "Task title and source reference must not exceed 500 characters.")
    if deadline is not None and deadline < current_date():
        raise ValidationError("deadline_in_past", "Deadline cannot be in the past.")
    for uid in {u for u in [primary_responsible_id, approver_id, *(supporting_user_ids or [])] if u is not None}:
        await _validate_assignee(session, uid)
    for did in {d for d in [department_id, *(supporting_department_ids or [])] if d is not None}:
        await _validate_department(session, did)

    public_code = await _next_public_code(session)
    task = Task(
        public_code=public_code,
        title=title.strip(),
        description=description,
        expected_outcome=expected_outcome,
        acceptance_criteria=acceptance_criteria,
        source_reference=source_reference,
        department_id=department_id,
        primary_responsible_id=primary_responsible_id,
        created_by_id=actor.id,
        approver_id=approver_id or actor.id,
        priority=priority,
        status=TaskStatus.CREATED,
        assigned_date=current_date() if primary_responsible_id else None,
        deadline=deadline,
        progress_percent=0,
    )
    # Populate the relationship collections BEFORE the first flush, while the
    # object is still transient/pending. Appending here (rather than after a
    # flush) is what marks each collection as "loaded" on this object; doing
    # it only after a flush would make the next plain attribute access try an
    # implicit lazy load, which fails under AsyncSession (MissingGreenlet).
    task.history.append(TaskHistory(from_status=None, to_status=TaskStatus.CREATED, changed_by_id=actor.id))
    for uid in set(supporting_user_ids or []):
        task.assignees.append(TaskAssignee(user_id=uid, is_supporting=True))
    for did in set(supporting_department_ids or []):
        task.assignees.append(TaskAssignee(department_id=did, is_supporting=True))
    # Touching these (even just reading) while still transient marks them
    # loaded too, so later code in the same request may safely read
    # task.comments / task.attachments on the object this function returns.
    _ = task.comments, task.attachments

    session.add(task)
    await session.flush()

    # A task with a named responsible person is, by definition, already
    # assigned — CREATED is a transient state for tasks still being drafted.
    if primary_responsible_id is not None:
        await _transition(session, task, TaskStatus.ASSIGNED, actor_id=actor.id, comment="Auto-assigned at creation")
        await _notify_task(session, task, primary_responsible_id, NotificationType.NEW_ASSIGNMENT, "Sizga yangi vazifa topshirildi.")

    await session.flush()
    await log_action(
        session, actor_user_id=actor.id, action="task.created", entity_type="task", entity_id=task.id,
        details={"public_code": public_code, "primary_responsible_id": primary_responsible_id},
    )
    return task


async def acknowledge_task(session: AsyncSession, *, actor: Actor, task_id: int) -> Task:
    require_active(actor)
    task = await get_task(session, task_id, lock=True)
    if actor.id != task.primary_responsible_id or not can_update_progress(actor, task):
        raise ValidationError("forbidden", "Only the responsible employee may acknowledge this task.")
    await _transition(session, task, TaskStatus.ACKNOWLEDGED, actor_id=actor.id, comment="Receipt confirmed")
    await session.flush()
    await log_action(session, actor_user_id=actor.id, action="task.acknowledged", entity_type="task", entity_id=task.id)
    return task


async def start_progress(session: AsyncSession, *, actor: Actor, task_id: int) -> Task:
    task = await get_task(session, task_id, lock=True)
    if not can_update_progress(actor, task):
        raise ValidationError("forbidden", "You are not assigned to this task.")
    target = TaskStatus.IN_PROGRESS
    await _transition(session, task, target, actor_id=actor.id)
    await session.flush()
    return task


async def update_progress(
    session: AsyncSession, *, actor: Actor, task_id: int, progress_percent: int, comment: str | None = None
) -> Task:
    task = await get_task(session, task_id, lock=True)
    if not can_update_progress(actor, task):
        raise ValidationError("forbidden", "You are not assigned to this task.")
    if not (0 <= progress_percent <= 100):
        raise ValidationError("bad_progress", "Progress must be between 0 and 100.")
    if task.status in TERMINAL_STATUSES:
        raise InvalidTransitionError("task_closed", "This task is already closed.")
    # Progress alone never completes a task (acceptance criterion): 100% only
    # means "ready to submit for review", not "Completed".
    task.progress_percent = progress_percent
    if comment:
        task.comments.append(TaskComment(author_id=actor.id, comment_text=comment))
    if task.status in (TaskStatus.ASSIGNED, TaskStatus.ACKNOWLEDGED, TaskStatus.OVERDUE) and progress_percent > 0:
        await _transition(session, task, TaskStatus.IN_PROGRESS, actor_id=actor.id, comment="Progress updated")
    await session.flush()
    await log_action(session, actor_user_id=actor.id, action="task.progress_updated", entity_type="task",
                      entity_id=task.id, details={"progress_percent": progress_percent})
    return task


async def block_task(session: AsyncSession, *, actor: Actor, task_id: int, reason: str) -> Task:
    task = await get_task(session, task_id, lock=True)
    if not can_update_progress(actor, task):
        raise ValidationError("forbidden", "You are not assigned to this task.")
    if not reason or not reason.strip():
        raise ValidationError("reason_required", "A reason is required to mark a task as blocked.")
    await _transition(session, task, TaskStatus.PENDING_BLOCKED, actor_id=actor.id, comment=reason)
    task.comments.append(TaskComment(author_id=actor.id, comment_text=reason, is_obstacle=True))
    await session.flush()
    await log_action(session, actor_user_id=actor.id, action="task.blocked", entity_type="task", entity_id=task.id,
                      details={"reason": reason})
    return task


async def unblock_task(session: AsyncSession, *, actor: Actor, task_id: int) -> Task:
    task = await get_task(session, task_id, lock=True)
    if not can_update_progress(actor, task):
        raise ValidationError("forbidden", "You are not assigned to this task.")
    await _transition(session, task, TaskStatus.IN_PROGRESS, actor_id=actor.id, comment="Unblocked")
    await session.flush()
    return task


async def submit_for_review(session: AsyncSession, *, actor: Actor, task_id: int, comment: str | None = None) -> Task:
    task = await get_task(session, task_id, lock=True)
    if not can_update_progress(actor, task):
        raise ValidationError("forbidden", "You are not assigned to this task.")
    await _transition(session, task, TaskStatus.SUBMITTED_FOR_REVIEW, actor_id=actor.id, comment=comment)
    await _notify_task(session, task, task.approver_id, NotificationType.SUBMITTED_FOR_REVIEW, "Vazifa ko'rikka topshirildi. Tasdiqlash kutilmoqda.")
    await session.flush()
    await log_action(session, actor_user_id=actor.id, action="task.submitted_for_review", entity_type="task",
                      entity_id=task.id)
    return task


async def approve_task(session: AsyncSession, *, actor: Actor, task_id: int, comment: str | None = None) -> Task:
    task = await get_task(session, task_id, lock=True)
    if not can_approve_or_return(actor, task):
        raise ValidationError("forbidden", "Only the assigning manager may approve this task.")
    await _transition(session, task, TaskStatus.COMPLETED, actor_id=actor.id, comment=comment)
    task.progress_percent = 100
    task.actual_completion_date = current_date()
    await _notify_task(session, task, task.primary_responsible_id, NotificationType.APPROVED, "Vazifa bajarilgani tasdiqlandi.")
    await session.flush()
    await log_action(session, actor_user_id=actor.id, action="task.approved", entity_type="task", entity_id=task.id)
    return task


async def return_for_revision(session: AsyncSession, *, actor: Actor, task_id: int, comment: str) -> Task:
    task = await get_task(session, task_id, lock=True)
    if not can_approve_or_return(actor, task):
        raise ValidationError("forbidden", "Only the assigning manager may return this task.")
    if not comment or not comment.strip():
        raise ValidationError("reason_required", "Explain what needs to be revised.")
    await _transition(session, task, TaskStatus.RETURNED_FOR_REVISION, actor_id=actor.id, comment=comment)
    await _notify_task(session, task, task.primary_responsible_id, NotificationType.RETURNED, f"Vazifa qayta ishlash uchun qaytarildi: {comment}")
    await session.flush()
    await log_action(session, actor_user_id=actor.id, action="task.returned", entity_type="task", entity_id=task.id,
                      details={"comment": comment})
    return task


async def resume_after_revision(session: AsyncSession, *, actor: Actor, task_id: int) -> Task:
    task = await get_task(session, task_id, lock=True)
    if not can_update_progress(actor, task):
        raise ValidationError("forbidden", "You are not assigned to this task.")
    await _transition(session, task, TaskStatus.IN_PROGRESS, actor_id=actor.id, comment="Resumed after revision")
    await session.flush()
    return task


async def cancel_task(session: AsyncSession, *, actor: Actor, task_id: int, reason: str) -> Task:
    task = await get_task(session, task_id, lock=True)
    if not can_cancel_task(actor, task):
        raise ValidationError("forbidden", "You may not cancel this task.")
    if not reason or not reason.strip():
        raise ValidationError("reason_required", "A cancellation reason is required.")
    if len(reason) > 500:
        raise ValidationError("text_too_long", "The cancellation reason must not exceed 500 characters.")
    await _transition(session, task, TaskStatus.CANCELLED, actor_id=actor.id, comment=reason)
    task.is_cancelled_reason = reason
    await session.flush()
    await log_action(session, actor_user_id=actor.id, action="task.cancelled", entity_type="task", entity_id=task.id,
                      details={"reason": reason})
    return task


async def reassign_task(session: AsyncSession, *, actor: Actor, task_id: int, new_primary_responsible_id: int) -> Task:
    task = await get_task(session, task_id, lock=True)
    if not can_reassign_or_change_deadline(actor, task):
        raise ValidationError("forbidden", "You may not reassign this task.")
    if task.status in TERMINAL_STATUSES:
        raise InvalidTransitionError("task_closed", "This task is already closed.")
    await _validate_assignee(session, new_primary_responsible_id)
    old_owner = task.primary_responsible_id
    task.primary_responsible_id = new_primary_responsible_id
    task.assigned_date = current_date()
    if task.status == TaskStatus.CREATED:
        await _transition(session, task, TaskStatus.ASSIGNED, actor_id=actor.id, comment="Assigned")
    else:
        # Reassignment restarts the acknowledgement step for the new owner.
        task.history.append(TaskHistory(from_status=task.status, to_status=TaskStatus.ASSIGNED,
                                         changed_by_id=actor.id, comment=f"Reassigned from user#{old_owner}"))
        task.status = TaskStatus.ASSIGNED
    await _notify_task(session, task, new_primary_responsible_id, NotificationType.REASSIGNED, "Vazifa sizga qayta biriktirildi.")
    await session.flush()
    await log_action(session, actor_user_id=actor.id, action="task.reassigned", entity_type="task", entity_id=task.id,
                      details={"from_user_id": old_owner, "to_user_id": new_primary_responsible_id})
    return task


async def change_deadline(session: AsyncSession, *, actor: Actor, task_id: int, new_deadline: dt.date, reason: str | None = None) -> Task:
    task = await get_task(session, task_id, lock=True)
    if not can_reassign_or_change_deadline(actor, task):
        raise ValidationError("forbidden", "You may not change this task's deadline.")
    if task.status in TERMINAL_STATUSES:
        raise InvalidTransitionError("task_closed", "This task is already closed.")
    if new_deadline < current_date():
        raise ValidationError("deadline_in_past", "The new deadline cannot be in the past.")
    old_deadline = task.deadline
    task.deadline = new_deadline
    if task.status == TaskStatus.OVERDUE and new_deadline >= current_date():
        await _transition(session, task, TaskStatus.IN_PROGRESS, actor_id=actor.id,
                           comment=f"Deadline extended to {new_deadline.isoformat()}")
    await session.flush()
    await log_action(session, actor_user_id=actor.id, action="task.deadline_changed", entity_type="task",
                      entity_id=task.id, details={"from": str(old_deadline), "to": str(new_deadline), "reason": reason})
    return task


async def request_extension(
    session: AsyncSession, *, actor: Actor, task_id: int, requested_deadline: dt.date, justification: str
) -> DeadlineExtensionRequest:
    task = await get_task(session, task_id, lock=True)
    if not can_request_extension(actor, task):
        raise ValidationError("forbidden", "You are not assigned to this task.")
    if task.status in TERMINAL_STATUSES:
        raise InvalidTransitionError("task_closed", "This task is already closed.")
    if requested_deadline < current_date() or (task.deadline and requested_deadline <= task.deadline):
        raise ValidationError("invalid_deadline", "An extension must move the deadline forward.")
    if not justification or not justification.strip():
        raise ValidationError("justification_required", "Please justify the extension request.")
    req = DeadlineExtensionRequest(
        task_id=task.id, requested_by_id=actor.id, current_deadline=task.deadline,
        requested_deadline=requested_deadline, justification=justification, status="pending",
    )
    session.add(req)
    await session.flush()
    await log_action(session, actor_user_id=actor.id, action="task.extension_requested", entity_type="task",
                      entity_id=task.id, details={"requested_deadline": str(requested_deadline)})
    return req


async def review_extension(
    session: AsyncSession, *, actor: Actor, extension_request_id: int, approve: bool, comment: str | None = None
) -> DeadlineExtensionRequest:
    req = await session.get(DeadlineExtensionRequest, extension_request_id, with_for_update=True)
    if req is None:
        raise NotFoundError("not_found", "Extension request not found.")
    task = await get_task(session, req.task_id, lock=True)
    if not can_reassign_or_change_deadline(actor, task):
        raise ValidationError("forbidden", "You may not review this extension request.")
    if req.status != "pending":
        raise ValidationError("not_pending", "This request has already been reviewed.")

    if approve:
        await change_deadline(session, actor=actor, task_id=task.id, new_deadline=req.requested_deadline,
                               reason=f"Extension approved: {comment or ''}".strip())
    req.status = "approved" if approve else "rejected"
    req.reviewed_by_id = actor.id
    req.reviewed_at = dt.datetime.now(dt.timezone.utc)
    await session.flush()
    await log_action(session, actor_user_id=actor.id, action="task.extension_reviewed", entity_type="task",
                      entity_id=task.id, details={"approved": approve})
    return req


async def add_comment(session: AsyncSession, *, actor: Actor, task_id: int, text: str, is_obstacle: bool = False) -> TaskComment:
    task = await get_task(session, task_id, lock=True)
    if not can_view_task(actor, task) or actor.role == UserRole.OBSERVER:
        raise ValidationError("forbidden", "You do not have access to this task.")
    if not text or not text.strip():
        raise ValidationError("comment_required", "Comment text is required.")
    comment = TaskComment(author_id=actor.id, comment_text=text, is_obstacle=is_obstacle)
    task.comments.append(comment)
    await session.flush()
    return comment


async def add_attachment(
    session: AsyncSession, *, actor: Actor, task_id: int, telegram_file_id: str, file_type: str,
    caption: str | None = None, is_completion_evidence: bool = False,
) -> TaskAttachment:
    task = await get_task(session, task_id, lock=True)
    if not can_view_task(actor, task) or actor.role == UserRole.OBSERVER:
        raise ValidationError("forbidden", "You do not have access to this task.")
    if not telegram_file_id or len(telegram_file_id) > 300 or (caption and len(caption) > 500):
        raise ValidationError("invalid_attachment", "The attachment or caption exceeds its allowed length.")
    att = TaskAttachment(
        uploaded_by_id=actor.id, telegram_file_id=telegram_file_id, file_type=file_type,
        caption=caption, is_completion_evidence=is_completion_evidence,
    )
    task.attachments.append(att)
    await session.flush()
    return att


# --------------------------------------------------------------------------
# System sweep: run by the scheduler, not by a human actor. Flags any task
# whose deadline has passed as OVERDUE, unless it is already finished,
# cancelled, or explicitly blocked (a blocked task is already flagged as
# needing attention — it does not additionally need to read "overdue").
# --------------------------------------------------------------------------
async def sweep_overdue_tasks(session: AsyncSession) -> list[Task]:
    today = current_date()
    result = await session.execute(
        _task_query().where(
            Task.deadline.is_not(None),
            Task.deadline < today,
            Task.status.not_in(TERMINAL_STATUSES | {TaskStatus.PENDING_BLOCKED, TaskStatus.OVERDUE}),
        ).with_for_update(skip_locked=True)
    )
    tasks = list(result.scalars().unique().all())
    for task in tasks:
        task.history.append(TaskHistory(from_status=task.status, to_status=TaskStatus.OVERDUE,
                                         changed_by_id=None, comment="Auto-flagged overdue by scheduler"))
        task.status = TaskStatus.OVERDUE
    if tasks:
        await session.flush()
    return tasks


async def list_tasks_due_within(session: AsyncSession, days: int) -> list[Task]:
    today = current_date()
    until = today + dt.timedelta(days=days)
    result = await session.execute(
        _task_query().where(
            Task.deadline.is_not(None),
            Task.deadline >= today,
            Task.deadline <= until,
            Task.status.not_in(TERMINAL_STATUSES),
        )
    )
    return list(result.scalars().unique().all())


async def list_overdue_tasks(session: AsyncSession) -> list[Task]:
    result = await session.execute(_task_query().where(Task.status == TaskStatus.OVERDUE))
    return list(result.scalars().unique().all())


async def list_blocked_tasks(session: AsyncSession) -> list[Task]:
    result = await session.execute(_task_query().where(Task.status == TaskStatus.PENDING_BLOCKED))
    return list(result.scalars().unique().all())


async def list_tasks_for_user(session: AsyncSession, user_id: int, *, include_supporting: bool = True) -> list[Task]:
    stmt = _task_query().where(Task.primary_responsible_id == user_id)
    result = await session.execute(stmt)
    tasks = {t.id: t for t in result.scalars().unique().all()}
    if include_supporting:
        stmt2 = _task_query().join(TaskAssignee, TaskAssignee.task_id == Task.id).where(TaskAssignee.user_id == user_id)
        result2 = await session.execute(stmt2)
        for t in result2.scalars().unique().all():
            tasks[t.id] = t
    return list(tasks.values())


async def list_tasks_created_by(session: AsyncSession, user_id: int) -> list[Task]:
    result = await session.execute(_task_query().where(Task.created_by_id == user_id))
    return list(result.scalars().unique().all())


async def list_pending_approvals(session: AsyncSession, approver_id: int) -> list[Task]:
    result = await session.execute(
        _task_query().where(Task.approver_id == approver_id, Task.status == TaskStatus.SUBMITTED_FOR_REVIEW)
    )
    return list(result.scalars().unique().all())


async def list_tasks_by_department(session: AsyncSession, department_id: int) -> list[Task]:
    result = await session.execute(_task_query().where(Task.department_id == department_id))
    return list(result.scalars().unique().all())


async def list_all_tasks(session: AsyncSession, *, limit: int = 500) -> list[Task]:
    result = await session.execute(_task_query().order_by(Task.created_at.desc()).limit(limit))
    return list(result.scalars().unique().all())

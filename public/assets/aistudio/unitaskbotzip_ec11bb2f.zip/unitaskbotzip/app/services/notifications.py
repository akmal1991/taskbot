"""Notification creation with built-in deduplication.

This module only *records* that a notification should be sent (so the
scheduler and the bot's send-worker have a durable, query-able queue); it
never calls the Telegram API itself — see app/scheduler/jobs.py and
app/bot/notifier.py for the actual delivery.
"""
from __future__ import annotations

import datetime as dt

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.notification import Notification
from app.models.enums import NotificationType


async def enqueue(
    session: AsyncSession,
    *,
    task_id: int | None,
    recipient_user_id: int,
    notif_type: NotificationType,
    dedup_key: str,
    text_rendered: str,
    scheduled_for: dt.datetime | None = None,
) -> Notification | None:
    """Insert a notification unless one with the same dedup_key already
    exists. Returns None (and does nothing) on a duplicate — this is the
    single mechanism that prevents double reminders / double escalations."""
    result = await session.execute(
        insert(Notification)
        .values(
            task_id=task_id,
            recipient_user_id=recipient_user_id,
            notif_type=notif_type,
            dedup_key=dedup_key,
            # Full task/comments remain in the register; Telegram messages
            # have a hard 4096-character limit.
            text_rendered=text_rendered[:4096],
            scheduled_for=scheduled_for or dt.datetime.now(dt.timezone.utc),
        )
        .on_conflict_do_nothing(constraint="uq_notification_dedup_key")
        .returning(Notification)
    )
    return result.scalar_one_or_none()


async def list_due(session: AsyncSession, *, as_of: dt.datetime | None = None, limit: int = 200) -> list[Notification]:
    as_of = as_of or dt.datetime.now(dt.timezone.utc)
    result = await session.execute(
        select(Notification)
        .where(
            Notification.sent_at.is_(None),
            Notification.failed_reason.is_(None),
            Notification.scheduled_for <= as_of,
        )
        .order_by(Notification.scheduled_for)
        .limit(limit)
        .with_for_update(skip_locked=True)
    )
    return list(result.scalars().all())


async def mark_sent(session: AsyncSession, notification_id: int) -> None:
    notif = await session.get(Notification, notification_id)
    if notif is not None:
        notif.sent_at = dt.datetime.now(dt.timezone.utc)
        await session.flush()


async def mark_failed(session: AsyncSession, notification_id: int, reason: str) -> None:
    notif = await session.get(Notification, notification_id)
    if notif is not None:
        notif.failed_reason = reason[:500]
        await session.flush()

from __future__ import annotations

import datetime as dt

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo
from sqlalchemy.ext.asyncio import AsyncSession

from sqlalchemy import select

from app.excel_io.columns import COLUMNS
from app.models.department import Department
from app.models.enums import TaskStatus
from app.models.task import Task
from app.models.user import User
from app.core.clock import today
from app.services.tasks import list_all_tasks

ARIAL = "Arial"
HDR_FILL = PatternFill("solid", fgColor="1F4E78")
HDR_FONT = Font(name=ARIAL, size=10, bold=True, color="FFFFFF")

def _write_cell(ws, row: int, column: int, value):
    cell = ws.cell(row=row, column=column, value=value)
    if isinstance(value, str):
        # Explicit string cells preserve user text without executing formulas
        # when the workbook is opened in Excel or imported again.
        cell.data_type = "s"
    return cell


def _days_remaining(task: Task) -> str | int:
    if task.deadline is None:
        return "-"
    if task.status == TaskStatus.COMPLETED:
        return "Bajarildi"
    return (task.deadline - today()).days


async def build_register_workbook(session: AsyncSession, *, title: str = "Vazifalar reestri") -> Workbook:
    tasks = await list_all_tasks(session, limit=100000)
    tasks.sort(key=lambda t: t.id)

    wb = Workbook()
    ws = wb.active
    ws.title = title[:31]

    for i, name in enumerate(COLUMNS, start=1):
        c = ws.cell(row=1, column=i, value=name)
        c.font = HDR_FONT
        c.fill = HDR_FILL
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[1].height = 30
    ws.freeze_panes = "A2"

    dept_ids = {t.department_id for t in tasks}
    dept_ids.discard(None)
    dept_names: dict[int, str] = {}
    if dept_ids:
        result = await session.execute(select(Department).where(Department.id.in_(dept_ids)))
        for d in result.scalars().all():
            dept_names[d.id] = d.name

    for idx, task in enumerate(tasks, start=2):
        dept_name = dept_names.get(task.department_id, "")
        # primary/creator/approver are User ids; resolved via a dict for speed
        row = [
            task.id,
            task.public_code,
            task.title,
            task.description or "",
            task.expected_outcome or "",
            task.source_reference or "",
            dept_name,
            "",  # filled below once we know names (kept here for column order)
            task.priority.value,
            task.status.value,
            task.assigned_date,
            task.deadline,
            task.progress_percent,
            task.actual_completion_date,
            _days_remaining(task),
            "",
            "",
        ]
        for col_i, value in enumerate(row, start=1):
            _write_cell(ws, idx, col_i, value)
        ws.cell(row=idx, column=11).number_format = "dd.mm.yyyy"
        ws.cell(row=idx, column=12).number_format = "dd.mm.yyyy"
        ws.cell(row=idx, column=14).number_format = "dd.mm.yyyy"

    # Resolve user names in a second pass (one query instead of N+1).
    user_ids = {t.primary_responsible_id for t in tasks} | {t.created_by_id for t in tasks} | {t.approver_id for t in tasks}
    user_ids.discard(None)
    names: dict[int, str] = {}
    if user_ids:
        result = await session.execute(select(User).where(User.id.in_(user_ids)))
        for u in result.scalars().all():
            names[u.id] = u.full_name

    for idx, task in enumerate(tasks, start=2):
        _write_cell(ws, idx, 8, names.get(task.primary_responsible_id, ""))
        _write_cell(ws, idx, 16, names.get(task.created_by_id, ""))
        _write_cell(ws, idx, 17, names.get(task.approver_id, ""))

    widths = [6, 14, 32, 40, 30, 24, 22, 22, 10, 18, 13, 13, 10, 15, 16, 22, 22]
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w

    last_row = max(len(tasks) + 1, 2)
    tbl = Table(displayName="TaskRegisterExport", ref=f"A1:{get_column_letter(len(COLUMNS))}{last_row}")
    tbl.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showRowStripes=True)
    if len(tasks) > 0:
        ws.add_table(tbl)

    wb.properties.title = "University Task Register Export"
    wb.properties.creator = "University Task Management Bot"
    return wb

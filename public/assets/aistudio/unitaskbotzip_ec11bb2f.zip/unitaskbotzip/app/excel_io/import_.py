"""Excel import for the task register.

Expects the column layout in app/excel_io/columns.py (the same layout the
export produces, so export -> edit -> re-import round-trips cleanly). Also
tolerates a looser subset: only "Title" is strictly required, everything
else has a sensible fallback, so a hand-made spreadsheet (like the
university's original work-plan register) can be imported too once its
columns are renamed/reordered to match.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from zipfile import ZipFile

import openpyxl
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.excel_io.columns import COL
from app.models.department import Department
from app.models.enums import Priority, TaskStatus
from app.models.task import Task, TaskHistory
from app.models.user import User
from app.services.audit import log_action
from app.services.exceptions import ServiceError, ValidationError
from app.services.permissions import Actor, can_manage_users
from app.services.tasks import _next_public_code


@dataclass
class ImportReport:
    created: int = 0
    updated: int = 0
    skipped: int = 0
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


def _norm(s: object) -> str:
    return str(s).strip() if s not in (None, "") else ""


def _parse_date(value) -> dt.date | None:
    if value in (None, "", "-"):
        return None
    if isinstance(value, dt.datetime):
        return value.date()
    if isinstance(value, dt.date):
        return value
    if isinstance(value, str):
        for fmt in ("%d.%m.%Y", "%Y-%m-%d"):
            try:
                return dt.datetime.strptime(value.strip(), fmt).date()
            except ValueError:
                continue
    raise ValidationError("invalid_date", f"Invalid date: {value!s}. Use DD.MM.YYYY or YYYY-MM-DD.")


def _parse_priority(value) -> Priority:
    s = _norm(value).lower()
    for p in Priority:
        if s == p.value.lower():
            return p
    mapping = {"критик": Priority.CRITICAL, "высокий": Priority.HIGH, "юқори": Priority.HIGH,
               "средний": Priority.MEDIUM, "ўрта": Priority.MEDIUM, "низкий": Priority.LOW, "паст": Priority.LOW}
    return mapping.get(s, Priority.MEDIUM)


def _parse_status(value) -> TaskStatus:
    s = _norm(value).lower().replace(" ", "_")
    for st in TaskStatus:
        if s == st.value:
            return st
    return TaskStatus.CREATED


async def _get_or_create_department(session: AsyncSession, cache: dict[str, Department], name: str) -> Department | None:
    name = _norm(name)
    if not name:
        return None
    key = name.lower()
    if key in cache:
        return cache[key]
    result = await session.execute(select(Department).where(Department.name == name))
    dept = result.scalar_one_or_none()
    if dept is None:
        dept = Department(name=name)
        session.add(dept)
        await session.flush()
    cache[key] = dept
    return dept


async def _find_user_by_name(session: AsyncSession, cache: dict[str, list[User]], full_name: str) -> User | None:
    full_name = _norm(full_name)
    if not full_name:
        return None
    key = full_name.lower()
    if key not in cache:
        result = await session.execute(
            select(User).where(func.lower(User.full_name) == key, User.is_active.is_(True))
        )
        cache[key] = list(result.scalars().all())
    matches = cache[key]
    if len(matches) == 1:
        return matches[0]
    return None


async def import_register(
    session: AsyncSession, *, actor: Actor, file_path: str, update_existing: bool = True
) -> ImportReport:
    if not can_manage_users(actor):
        raise ValidationError("forbidden", "Only an active Super Administrator may import the register.")
    with ZipFile(file_path) as archive:
        if sum(item.file_size for item in archive.infolist()) > 64 * 1024 * 1024:
            raise ValidationError("file_too_large", "The expanded workbook exceeds 64 MB.")
    report = ImportReport()
    wb = openpyxl.load_workbook(file_path, data_only=True)
    ws = wb.active

    header_row = [c.value for c in ws[1]]
    # Build a column-index map tolerant of the exact export header names.
    idx_by_name = {str(h).strip(): i + 1 for i, h in enumerate(header_row) if h}
    if "Title" not in idx_by_name:
        wb.close()
        raise ValidationError("missing_title", "The workbook must contain a Title column.")
    if ws.max_row > 50001:
        wb.close()
        raise ValidationError("too_many_rows", "Import at most 50,000 tasks per workbook.")

    def cell(row, name, default_idx=None):
        # Missing headers must not read unrelated positional columns in
        # hand-made workbooks containing only a subset of exported columns.
        i = idx_by_name.get(name)
        if i is None:
            return None
        return ws.cell(row=row, column=i).value

    dept_cache: dict[str, Department] = {}
    user_name_cache: dict[str, list[User]] = {}

    for row in range(2, ws.max_row + 1):
        title = _norm(cell(row, "Title", COL.get("Title")))
        if not title:
            continue  # blank row

        public_code = _norm(cell(row, "Public Code", COL.get("Public Code")))
        existing: Task | None = None
        if public_code:
            result = await session.execute(
                select(Task).options(selectinload(Task.history))
                .where(Task.public_code == public_code).with_for_update()
            )
            existing = result.scalar_one_or_none()

        if existing is None:
            dept_name = _norm(cell(row, "Department", COL.get("Department")))
            dup_check = await session.execute(
                select(Task).where(Task.title == title)
            )
            possible_dups = [t for t in dup_check.scalars().all()]
            if possible_dups and not public_code:
                report.warnings.append(f"Row {row}: possible duplicate of existing task(s) with the same title ('{title}') — imported anyway as a new task since no Public Code was given to match against.")

        # Each row runs inside its own SAVEPOINT: if it fails, only that
        # row's partial writes are rolled back — not every row already
        # successfully imported earlier in this same call.
        savepoint = await session.begin_nested()
        try:
            if len(title) > 500 or len(public_code) > 32:
                raise ValidationError("text_too_long", "Title or Public Code exceeds its allowed length.")
            department = await _get_or_create_department(session, dept_cache, cell(row, "Department", COL.get("Department")))
            responsible = await _find_user_by_name(session, user_name_cache, cell(row, "Primary Responsible (full name)", COL.get("Primary Responsible (full name)")))
            if cell(row, "Primary Responsible (full name)") and responsible is None:
                report.warnings.append(f"Row {row}: responsible person name '{cell(row, 'Primary Responsible (full name)')}' not found or ambiguous — left unassigned.")

            priority = _parse_priority(cell(row, "Priority", COL.get("Priority")))
            status = _parse_status(cell(row, "Status", COL.get("Status")))
            if existing is not None:
                if "Status" not in idx_by_name:
                    status = existing.status
                if "Priority" not in idx_by_name:
                    priority = existing.priority
            deadline = _parse_date(cell(row, "Deadline", COL.get("Deadline")))
            assigned_date = _parse_date(cell(row, "Assigned Date", COL.get("Assigned Date")))
            actual_completion = _parse_date(cell(row, "Actual Completion Date", COL.get("Actual Completion Date")))
            progress_raw = cell(row, "Progress %", COL.get("Progress %"))
            try:
                progress = max(0, min(100, int(progress_raw))) if progress_raw not in (None, "") else 0
            except (TypeError, ValueError):
                progress = 0
                report.warnings.append(f"Row {row}: invalid Progress % value, defaulted to 0.")
            if existing is not None and "Progress %" not in idx_by_name:
                progress = existing.progress_percent
            if status == TaskStatus.COMPLETED:
                progress = 100

            if existing is not None:
                if not update_existing:
                    report.skipped += 1
                    await savepoint.rollback()
                    continue
                existing.title = title
                for header, attribute in (
                    ("Description", "description"), ("Expected Outcome", "expected_outcome"),
                    ("Source Reference", "source_reference"),
                ):
                    if header in idx_by_name:
                        setattr(existing, attribute, _norm(cell(row, header)) or None)
                if "Department" in idx_by_name:
                    existing.department_id = department.id if department else None
                if responsible is not None:
                    existing.primary_responsible_id = responsible.id
                existing.priority = priority
                if "Assigned Date" in idx_by_name:
                    existing.assigned_date = assigned_date
                if "Deadline" in idx_by_name:
                    existing.deadline = deadline
                existing.progress_percent = progress
                if "Actual Completion Date" in idx_by_name:
                    existing.actual_completion_date = actual_completion
                if existing.status != status:
                    existing.history.append(TaskHistory(from_status=existing.status, to_status=status,
                                                          changed_by_id=actor.id, comment="Updated via Excel import"))
                    existing.status = status
            else:
                new_code = public_code or None
                if new_code:
                    dupe = await session.execute(select(Task).where(Task.public_code == new_code))
                    if dupe.scalar_one_or_none() is not None:
                        report.warnings.append(f"Row {row}: Public Code '{new_code}' already used by another task — generated a new code instead.")
                        new_code = None
                if not new_code:
                    new_code = await _next_public_code(session)

                task = Task(
                    public_code=new_code,
                    title=title,
                    description=_norm(cell(row, "Description", COL.get("Description"))) or None,
                    expected_outcome=_norm(cell(row, "Expected Outcome", COL.get("Expected Outcome"))) or None,
                    source_reference=_norm(cell(row, "Source Reference", COL.get("Source Reference"))) or None,
                    department_id=department.id if department else None,
                    primary_responsible_id=responsible.id if responsible else None,
                    created_by_id=actor.id,
                    approver_id=actor.id,
                    priority=priority,
                    status=status,
                    assigned_date=assigned_date,
                    deadline=deadline,
                    progress_percent=progress,
                    actual_completion_date=actual_completion,
                )
                task.history.append(TaskHistory(from_status=None, to_status=status, changed_by_id=actor.id,
                                                 comment="Imported from Excel"))
                session.add(task)

            await session.flush()
            imported_task = existing if existing is not None else task
            await log_action(
                session, actor_user_id=actor.id, action="task.excel_imported",
                entity_type="task", entity_id=imported_task.id,
                details={"updated": existing is not None},
            )
            await savepoint.commit()
            if existing is not None:
                report.updated += 1
            else:
                report.created += 1
        except Exception as exc:  # noqa: BLE001 — one bad row must not abort the whole import
            await savepoint.rollback()
            dept_cache.clear()
            user_name_cache.clear()
            reason = str(exc) if isinstance(exc, ServiceError) else f"Invalid row data ({type(exc).__name__})"
            report.errors.append(f"Row {row}: {reason}")

    wb.close()
    return report

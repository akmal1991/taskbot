"""Column layout shared by export and import, so a file exported from the
system can be edited and re-imported without renumbering tasks."""
from __future__ import annotations

COLUMNS = [
    "ID",
    "Public Code",
    "Title",
    "Description",
    "Expected Outcome",
    "Source Reference",
    "Department",
    "Primary Responsible (full name)",
    "Priority",
    "Status",
    "Assigned Date",
    "Deadline",
    "Progress %",
    "Actual Completion Date",
    "Days Remaining/Overdue",
    "Created By (full name)",
    "Approver (full name)",
]

# 1-indexed column numbers, derived from COLUMNS for readability at call sites.
COL = {name: i + 1 for i, name in enumerate(COLUMNS)}

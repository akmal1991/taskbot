"""Minimal, extensible i18n layer.

STRINGS[key][language] -> text. A language falls back to Uzbek Cyrillic
(the configured default) for any key it doesn't yet have a translation for,
so partial translation work never breaks the bot — it just shows Uzbek
Cyrillic for the untranslated strings until someone fills them in.
"""
from __future__ import annotations

from app.models.enums import Language

DEFAULT_LANG = Language.UZ_CYRL

STRINGS: dict[str, dict[Language, str]] = {
    "welcome": {
        Language.UZ_CYRL: "Хуш келибсиз! Бу — университет вазифаларини бошқариш боти.",
        Language.UZ_LATN: "Xush kelibsiz! Bu — universitet vazifalarini boshqarish boti.",
        Language.RU: "Добро пожаловать! Это бот управления задачами университета.",
    },
    "not_registered": {
        Language.UZ_CYRL: "Сиз ҳали рўйхатдан ўтмагансиз. Рўйхатдан ўтиш учун исм-шарифингизни юборинг.",
        Language.UZ_LATN: "Siz hali ro'yxatdan o'tmagansiz. Ro'yxatdan o'tish uchun ism-sharifingizni yuboring.",
        Language.RU: "Вы ещё не зарегистрированы. Отправьте своё полное имя для регистрации.",
    },
    "registration_pending": {
        Language.UZ_CYRL: "Сўровингиз администратор тасдиғини кутмоқда. Тез орада хабар берамиз.",
        Language.UZ_LATN: "So'rovingiz administrator tasdig'ini kutmoqda. Tez orada xabar beramiz.",
        Language.RU: "Ваша заявка ожидает подтверждения администратора. Мы сообщим вам в ближайшее время.",
    },
    "account_inactive": {
        Language.UZ_CYRL: "Ҳисобингиз фаол эмас. Администратор билан боғланинг.",
        Language.UZ_LATN: "Hisobingiz faol emas. Administrator bilan bog'laning.",
        Language.RU: "Ваш аккаунт деактивирован. Свяжитесь с администратором.",
    },
    "main_menu": {
        Language.UZ_CYRL: "Асосий меню:",
        Language.UZ_LATN: "Asosiy menyu:",
        Language.RU: "Главное меню:",
    },
    "btn_my_tasks": {Language.UZ_CYRL: "📋 Менинг вазифаларим", Language.UZ_LATN: "📋 Mening vazifalarim", Language.RU: "📋 Мои задачи"},
    "btn_assigned_by_me": {Language.UZ_CYRL: "📤 Мен берган вазифалар", Language.UZ_LATN: "📤 Men bergan vazifalar", Language.RU: "📤 Поручения от меня"},
    "btn_department_tasks": {Language.UZ_CYRL: "🏢 Бўлим вазифалари", Language.UZ_LATN: "🏢 Bo'lim vazifalari", Language.RU: "🏢 Задачи отдела"},
    "btn_create_task": {Language.UZ_CYRL: "➕ Янги вазифа", Language.UZ_LATN: "➕ Yangi vazifa", Language.RU: "➕ Новая задача"},
    "btn_update_progress": {Language.UZ_CYRL: "✏️ Жараённи янгилаш", Language.UZ_LATN: "✏️ Jarayonni yangilash", Language.RU: "✏️ Обновить прогресс"},
    "btn_submit_report": {Language.UZ_CYRL: "✅ Ҳисобот топшириш", Language.UZ_LATN: "✅ Hisobot topshirish", Language.RU: "✅ Сдать отчёт"},
    "btn_overdue": {Language.UZ_CYRL: "⚠️ Муддати ўтганлар", Language.UZ_LATN: "⚠️ Muddati o'tganlar", Language.RU: "⚠️ Просроченные"},
    "btn_pending_approvals": {Language.UZ_CYRL: "🕓 Тасдиқлашни кутаётганлар", Language.UZ_LATN: "🕓 Tasdiqlashni kutayotganlar", Language.RU: "🕓 Ожидают утверждения"},
    "btn_reports": {Language.UZ_CYRL: "📊 Ҳисобот ва таҳлил", Language.UZ_LATN: "📊 Hisobot va tahlil", Language.RU: "📊 Отчёты и аналитика"},
    "btn_user_management": {Language.UZ_CYRL: "👥 Фойдаланувчилар", Language.UZ_LATN: "👥 Foydalanuvchilar", Language.RU: "👥 Пользователи"},
    "btn_settings": {Language.UZ_CYRL: "⚙️ Созламалар", Language.UZ_LATN: "⚙️ Sozlamalar", Language.RU: "⚙️ Настройки"},
    "btn_back": {Language.UZ_CYRL: "⬅️ Орқага", Language.UZ_LATN: "⬅️ Orqaga", Language.RU: "⬅️ Назад"},
    "btn_cancel": {Language.UZ_CYRL: "❌ Бекор қилиш", Language.UZ_LATN: "❌ Bekor qilish", Language.RU: "❌ Отмена"},
    "btn_confirm": {Language.UZ_CYRL: "✅ Тасдиқлаш", Language.UZ_LATN: "✅ Tasdiqlash", Language.RU: "✅ Подтвердить"},
    "no_tasks": {Language.UZ_CYRL: "Ҳозирча вазифалар йўқ.", Language.UZ_LATN: "Hozircha vazifalar yo'q.", Language.RU: "Пока нет задач."},
    "forbidden": {Language.UZ_CYRL: "Бу амал учун сизда рухсат йўқ.", Language.UZ_LATN: "Bu amal uchun sizda ruxsat yo'q.", Language.RU: "У вас нет прав на это действие."},
    "task_created": {Language.UZ_CYRL: "Вазифа яратилди: {code}", Language.UZ_LATN: "Vazifa yaratildi: {code}", Language.RU: "Задача создана: {code}"},
    "enter_title": {Language.UZ_CYRL: "Вазифа номини киритинг:", Language.UZ_LATN: "Vazifa nomini kiriting:", Language.RU: "Введите название задачи:"},
    "enter_description": {Language.UZ_CYRL: "Тавсифини киритинг (ёки '-' деб ўтказиб юборинг):", Language.UZ_LATN: "Tavsifini kiriting (yoki '-' deb o'tkazib yuboring):", Language.RU: "Введите описание (или '-' чтобы пропустить):"},
    "choose_department": {Language.UZ_CYRL: "Жавобгар бўлимни танланг:", Language.UZ_LATN: "Javobgar bo'limni tanlang:", Language.RU: "Выберите ответственный отдел:"},
    "choose_responsible": {Language.UZ_CYRL: "Асосий масъул шахсни танланг:", Language.UZ_LATN: "Asosiy mas'ul shaxsni tanlang:", Language.RU: "Выберите ответственного сотрудника:"},
    "choose_priority": {Language.UZ_CYRL: "Муҳимлик даражасини танланг:", Language.UZ_LATN: "Muhimlik darajasini tanlang:", Language.RU: "Выберите приоритет:"},
    "enter_deadline": {Language.UZ_CYRL: "Муддатни киритинг (КК.ОО.ЙЙЙЙ) ёки '-' агар муддатсиз:", Language.UZ_LATN: "Muddatni kiriting (KK.OO.YYYY) yoki '-' agar muddatsiz:", Language.RU: "Введите срок (ДД.ММ.ГГГГ) или '-' без срока:"},
    "invalid_date": {Language.UZ_CYRL: "Сана нотўғри форматда. Мисол: 25.12.2026", Language.UZ_LATN: "Sana noto'g'ri formatda. Misol: 25.12.2026", Language.RU: "Неверный формат даты. Пример: 25.12.2026"},
    "progress_saved": {Language.UZ_CYRL: "Жараён сақланди: {percent}%", Language.UZ_LATN: "Jarayon saqlandi: {percent}%", Language.RU: "Прогресс сохранён: {percent}%"},
    "enter_progress": {Language.UZ_CYRL: "Бажарилиш фоизини киритинг (0–100):", Language.UZ_LATN: "Bajarilish foizini kiriting (0–100):", Language.RU: "Введите процент выполнения (0–100):"},
    "task_approved": {Language.UZ_CYRL: "Вазифа тасдиқланди ва якунланди.", Language.UZ_LATN: "Vazifa tasdiqlandi va yakunlandi.", Language.RU: "Задача утверждена и завершена."},
    "task_returned": {Language.UZ_CYRL: "Вазифа қайта ишлашга қайтарилди.", Language.UZ_LATN: "Vazifa qayta ishlashga qaytarildi.", Language.RU: "Задача возвращена на доработку."},
    "ask_block_reason": {Language.UZ_CYRL: "Тўхташ сабабини ёзинг:", Language.UZ_LATN: "To'xtash sababini yozing:", Language.RU: "Укажите причину блокировки:"},
    "ask_return_comment": {Language.UZ_CYRL: "Қайтариш сабабини ёзинг:", Language.UZ_LATN: "Qaytarish sababini yozing:", Language.RU: "Укажите причину возврата:"},
    "ask_cancel_reason": {Language.UZ_CYRL: "Бекор қилиш сабабини ёзинг:", Language.UZ_LATN: "Bekor qilish sababini yozing:", Language.RU: "Укажите причину отмены:"},
}


def t(key: str, lang: Language = DEFAULT_LANG, **kwargs) -> str:
    entry = STRINGS.get(key)
    if entry is None:
        return key
    text = entry.get(lang) or entry.get(DEFAULT_LANG) or key
    return text.format(**kwargs) if kwargs else text


def all_variants(key: str) -> set[str]:
    """Every language's rendering of a button label — used to match a reply
    keyboard button regardless of which language the sender's client shows."""
    entry = STRINGS.get(key, {})
    return set(entry.values())

from __future__ import annotations

from aiogram.fsm.state import State, StatesGroup


class AttachEvidence(StatesGroup):
    file = State()


class Registration(StatesGroup):
    full_name = State()
    phone = State()
    department = State()
    role = State()


class CreateTask(StatesGroup):
    title = State()
    description = State()
    expected_outcome = State()
    source_reference = State()
    department = State()
    responsible = State()
    priority = State()
    deadline = State()
    confirm = State()


class UpdateProgress(StatesGroup):
    choose_task = State()
    percent = State()
    comment = State()


class SubmitReview(StatesGroup):
    choose_task = State()
    comment = State()


class BlockTask(StatesGroup):
    choose_task = State()
    reason = State()


class ReturnTask(StatesGroup):
    comment = State()


class CancelTask(StatesGroup):
    reason = State()


class ExtensionRequest(StatesGroup):
    choose_task = State()
    new_date = State()
    justification = State()

"""Resolves the Telegram update's sender to an app User (by telegram_id,
never by @username) and injects `user` + `actor` into handler data.

Unregistered / unapproved / deactivated senders are *not* blocked here —
start.py's /start and registration handlers must still run for them. Instead
this middleware just makes `user` None/inactive so individual handlers (via
the `require_active_user` helper) can decide what to show.
"""
from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, Update

from app.services.permissions import Actor
from app.services.users import get_user_by_telegram_id
from app.bot.states.forms import AttachEvidence


class AuthMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        telegram_id = None
        if isinstance(event, Update):
            if event.message is not None and event.message.from_user is not None:
                if event.message.chat.type != "private":
                    await event.message.answer("Bu botdan faqat shaxsiy chatda foydalaning.")
                    return None
                if data.get("raw_state") and data["raw_state"] != AttachEvidence.file.state and event.message.text is None:
                    await event.message.answer("Davom etish uchun matn yuboring yoki /cancel buyrug'ini ishlating.")
                    return None
                telegram_id = event.message.from_user.id
            elif event.callback_query is not None:
                message = event.callback_query.message
                if message is None or message.chat.type != "private":
                    await event.callback_query.answer("Botni shaxsiy chatda oching.", show_alert=True)
                    return None
                parts = (event.callback_query.data or "").split(":")
                if parts[0] in {"task", "admin", "up", "sub", "ct"}:
                    numeric_action = parts[0] != "ct" or (len(parts) > 1 and parts[1] in {"dept", "resp"})
                    if numeric_action and (
                        not parts[-1].isdigit() or len(parts[-1]) > 10 or int(parts[-1]) > 2147483647
                    ):
                        await event.callback_query.answer("Tugma ma'lumoti noto'g'ri.", show_alert=True)
                        return None
                telegram_id = event.callback_query.from_user.id

        data["user"] = None
        data["actor"] = None
        if telegram_id is not None:
            session = data.get("session")
            if session is not None:
                user = await get_user_by_telegram_id(session, telegram_id)
                data["user"] = user
                if user is not None:
                    data["actor"] = Actor.from_user(user)
        return await handler(event, data)

"""Bot process entrypoint: `python -m app.bot.main`.

Runs aiogram long polling plus the APScheduler-driven background jobs
(reminders, escalation sweeps, notification delivery) in the same asyncio
event loop, so one process is enough for a small-to-medium deployment.
"""
from __future__ import annotations

import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.fsm.storage.base import BaseStorage
from aiogram.fsm.storage.memory import MemoryStorage

from app.bot.handlers import admin, create_task, reports, settings, start, task_detail, tasks_list, update_progress
from app.bot.middlewares.auth import AuthMiddleware
from app.bot.middlewares.db import DbSessionMiddleware
from app.core.config import get_settings
from app.scheduler.runner import build_scheduler


def _build_fsm_storage(redis_url: str) -> BaseStorage:
    """Redis is optional. When REDIS_URL is set, FSM state (in-progress
    registration/task wizards) survives a process restart; on a host with
    no Redis available (e.g. Replit, a minimal VPS), fall back to an
    in-memory store — wizards simply reset on restart rather than the bot
    failing to start at all."""
    if not redis_url:
        logging.getLogger(__name__).info("REDIS_URL not set — using in-memory FSM storage.")
        return MemoryStorage()
    from aiogram.fsm.storage.redis import RedisStorage

    return RedisStorage.from_url(redis_url)


def build_dispatcher() -> Dispatcher:
    settings_ = get_settings()
    storage = _build_fsm_storage(settings_.redis_url)
    dp = Dispatcher(storage=storage)

    dp.update.outer_middleware(DbSessionMiddleware())
    dp.update.outer_middleware(AuthMiddleware())

    # start MUST be included first: it is the only router that still works
    # for a sender with no User row yet (everything else is gated by
    # app.bot.filters.require_active_user).
    dp.include_router(start.router)
    dp.include_router(task_detail.router)
    dp.include_router(create_task.router)
    dp.include_router(update_progress.router)
    dp.include_router(tasks_list.router)
    dp.include_router(admin.router)
    dp.include_router(reports.router)
    dp.include_router(settings.router)
    return dp


async def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    settings_ = get_settings()

    bot = Bot(token=settings_.bot_token, default=DefaultBotProperties(parse_mode=settings_.bot_parse_mode))
    dp = build_dispatcher()

    scheduler = build_scheduler(bot)
    scheduler.start()
    logging.getLogger(__name__).info("Scheduler started with jobs: %s", [j.id for j in scheduler.get_jobs()])

    try:
        await dp.start_polling(bot)
    finally:
        scheduler.shutdown(wait=False)
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())

"""Shared router-level filters.

Applied as `router.message.filter(require_active_user)` /
`router.callback_query.filter(require_active_user)` on every content router
(everything except app.bot.handlers.start, which must keep working for
people who are not registered yet). This is what stops an unregistered or
deactivated Telegram user from reaching any task/report/admin handler --
even if their free-text input happens to collide with a menu button's label
while they're mid-registration.
"""
from __future__ import annotations

from app.models.user import User


async def require_active_user(event, user: User | None = None, **kwargs) -> bool:
    return user is not None and user.is_active

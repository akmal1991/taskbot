"""Shared text rendering for task cards / lists."""
from __future__ import annotations

from html import escape

from app.models.enums import Language, TaskStatus
from app.models.task import Task

STATUS_LABEL = {
    TaskStatus.CREATED: "🆕 Яратилган",
    TaskStatus.ASSIGNED: "📌 Топширилган",
    TaskStatus.ACKNOWLEDGED: "👀 Қабул қилинган",
    TaskStatus.IN_PROGRESS: "🔧 Жараёнда",
    TaskStatus.PENDING_BLOCKED: "⛔ Тўхтатилган",
    TaskStatus.SUBMITTED_FOR_REVIEW: "📥 Кўрикка топширилган",
    TaskStatus.RETURNED_FOR_REVISION: "↩️ Қайтарилган",
    TaskStatus.COMPLETED: "✅ Бажарилди",
    TaskStatus.OVERDUE: "⚠️ Муддати ўтган",
    TaskStatus.CANCELLED: "🚫 Бекор қилинган",
}


def task_card(task: Task, lang: Language = Language.UZ_CYRL) -> str:
    lines = [
        f"<b>{escape(task.public_code)}</b> — {escape(task.title)}",
        f"Ҳолат: {STATUS_LABEL.get(task.status, task.status.value)}",
        f"Муҳимлик: {task.priority.value}",
        f"Бажарилиш: {task.progress_percent}%",
    ]
    if task.deadline:
        lines.append(f"Муддат: {task.deadline.strftime('%d.%m.%Y')}")
    if task.description:
        # Leave room for the card header within Telegram's 4096-char limit.
        lines.append(f"\n{escape(task.description[:2500])}")
    return "\n".join(lines)


def task_list_line(task: Task) -> str:
    deadline = task.deadline.strftime("%d.%m.%Y") if task.deadline else "—"
    return f"{task.public_code} | {task.title[:40]} | {STATUS_LABEL.get(task.status, task.status.value)} | {deadline}"

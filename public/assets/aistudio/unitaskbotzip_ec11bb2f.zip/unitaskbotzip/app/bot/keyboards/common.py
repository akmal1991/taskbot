from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton

from app.bot.i18n.strings import t
from app.models.enums import Language, UserRole
from app.services.permissions import ROLES_THAT_CAN_CREATE_TASKS


def main_menu_keyboard(role: UserRole, lang: Language) -> ReplyKeyboardMarkup:
    rows: list[list[KeyboardButton]] = [
        [KeyboardButton(text=t("btn_my_tasks", lang))],
        [KeyboardButton(text=t("btn_update_progress", lang)), KeyboardButton(text=t("btn_submit_report", lang))],
    ]
    if role in ROLES_THAT_CAN_CREATE_TASKS:
        rows.append([KeyboardButton(text=t("btn_create_task", lang)), KeyboardButton(text=t("btn_assigned_by_me", lang))])
    if role in (UserRole.DEPARTMENT_HEAD, UserRole.VICE_RECTOR, UserRole.RECTOR, UserRole.SUPER_ADMIN):
        rows.append([KeyboardButton(text=t("btn_department_tasks", lang)), KeyboardButton(text=t("btn_pending_approvals", lang))])
    rows.append([KeyboardButton(text=t("btn_overdue", lang)), KeyboardButton(text=t("btn_reports", lang))])
    if role == UserRole.SUPER_ADMIN:
        rows.append([KeyboardButton(text=t("btn_user_management", lang))])
    rows.append([KeyboardButton(text=t("btn_settings", lang))])
    return ReplyKeyboardMarkup(keyboard=rows, resize_keyboard=True)


def cancel_inline_keyboard(lang: Language) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=t("btn_cancel", lang), callback_data="wizard:cancel")]])


def confirm_cancel_keyboard(lang: Language, confirm_cb: str, cancel_cb: str = "wizard:cancel") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text=t("btn_confirm", lang), callback_data=confirm_cb),
        InlineKeyboardButton(text=t("btn_cancel", lang), callback_data=cancel_cb),
    ]])


def paginated_keyboard(items: list[tuple[str, str]], page: int, page_size: int, prefix: str) -> InlineKeyboardMarkup:
    """items: list of (label, callback_data). Adds Prev/Next controls."""
    start = page * page_size
    chunk = items[start:start + page_size]
    rows = [[InlineKeyboardButton(text=label, callback_data=cb)] for label, cb in chunk]
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️", callback_data=f"{prefix}:page:{page - 1}"))
    if start + page_size < len(items):
        nav.append(InlineKeyboardButton(text="➡️", callback_data=f"{prefix}:page:{page + 1}"))
    if nav:
        rows.append(nav)
    return InlineKeyboardMarkup(inline_keyboard=rows)

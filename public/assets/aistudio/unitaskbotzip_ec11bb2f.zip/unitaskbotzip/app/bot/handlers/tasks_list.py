from __future__ import annotations

from aiogram import F, Router
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.bot.filters import require_active_user
from app.bot.i18n.strings import all_variants, t
from app.bot.keyboards.common import paginated_keyboard
from app.bot.render import task_list_line
from app.models.enums import UserRole
from app.models.task import Task
from app.models.user import User
from app.services import tasks as task_service
from app.services.permissions import Actor, ROLES_WITH_FULL_VISIBILITY, can_view_task

router = Router(name="tasks_list")
router.message.filter(require_active_user)
router.callback_query.filter(require_active_user)

PAGE_SIZE = 8


async def _send_task_list(message: Message, tasks: list[Task], *, kind: str = "mine", page: int = 0, edit: bool = False) -> None:
    if not tasks:
        await message.answer(t("no_tasks"))
        return
    tasks = sorted(tasks, key=lambda task: task.id, reverse=True)
    page = min(max(page, 0), (len(tasks) - 1) // PAGE_SIZE)
    kb = paginated_keyboard(
        [(task_list_line(task), f"task:view:{task.id}") for task in tasks],
        page, PAGE_SIZE, f"tasks:{kind}",
    )
    text = f"Topilgan vazifalar: {len(tasks)}\nSahifa: {page + 1} / {(len(tasks) - 1) // PAGE_SIZE + 1}"
    if edit:
        await message.edit_text(text, reply_markup=kb)
    else:
        await message.answer(text, reply_markup=kb)


@router.message(F.text.in_(all_variants("btn_my_tasks")))
async def my_tasks(message: Message, session: AsyncSession, actor: Actor, user: User) -> None:
    tasks = await task_service.list_tasks_for_user(session, user.id)
    await _send_task_list(message, tasks, kind="mine")


@router.message(F.text.in_(all_variants("btn_assigned_by_me")))
async def assigned_by_me(message: Message, session: AsyncSession, actor: Actor, user: User) -> None:
    tasks = await task_service.list_tasks_created_by(session, user.id)
    await _send_task_list(message, tasks, kind="created")


@router.message(F.text.in_(all_variants("btn_department_tasks")))
async def department_tasks(message: Message, session: AsyncSession, actor: Actor, user: User) -> None:
    if actor.role not in {UserRole.SUPER_ADMIN, UserRole.RECTOR, UserRole.VICE_RECTOR, UserRole.DEPARTMENT_HEAD}:
        await message.answer("Bo'lim vazifalari faqat rahbarlar uchun.")
        return
    if user.department_id is None and actor.role not in ROLES_WITH_FULL_VISIBILITY:
        await message.answer("Sizga bo'lim biriktirilmagan.")
        return
    if actor.role in ROLES_WITH_FULL_VISIBILITY and user.department_id is None:
        tasks = await task_service.list_all_tasks(session)
    else:
        tasks = await task_service.list_tasks_by_department(session, user.department_id)
    await _send_task_list(message, tasks, kind="department")


@router.message(F.text.in_(all_variants("btn_overdue")))
async def overdue_tasks(message: Message, session: AsyncSession, actor: Actor, user: User) -> None:
    tasks = await task_service.list_overdue_tasks(session)
    tasks = [tk for tk in tasks if can_view_task(actor, tk)]
    await _send_task_list(message, tasks, kind="overdue")


@router.message(F.text.in_(all_variants("btn_pending_approvals")))
async def pending_approvals(message: Message, session: AsyncSession, actor: Actor, user: User) -> None:
    tasks = await task_service.list_pending_approvals(session, user.id)
    await _send_task_list(message, tasks, kind="approvals")


@router.callback_query(F.data.startswith("tasks:"))
async def task_list_page(cq: CallbackQuery, session: AsyncSession, actor: Actor, user: User) -> None:
    parts = (cq.data or "").split(":")
    if len(parts) != 4 or parts[2] != "page" or not parts[3].isdigit():
        await cq.answer("Sahifa noto'g'ri.", show_alert=True)
        return
    kind, page = parts[1], int(parts[3])
    if kind == "mine":
        tasks = await task_service.list_tasks_for_user(session, user.id)
    elif kind == "created":
        tasks = await task_service.list_tasks_created_by(session, user.id)
    elif kind == "overdue":
        tasks = [task for task in await task_service.list_overdue_tasks(session) if can_view_task(actor, task)]
    elif kind == "approvals":
        tasks = await task_service.list_pending_approvals(session, user.id)
    elif kind == "department":
        if actor.role not in {UserRole.SUPER_ADMIN, UserRole.RECTOR, UserRole.VICE_RECTOR, UserRole.DEPARTMENT_HEAD}:
            await cq.answer("Ruxsat yo'q.", show_alert=True)
            return
        if user.department_id is not None:
            tasks = await task_service.list_tasks_by_department(session, user.department_id)
        elif actor.role in ROLES_WITH_FULL_VISIBILITY:
            tasks = await task_service.list_all_tasks(session)
        else:
            await cq.answer("Sizga bo'lim biriktirilmagan.", show_alert=True)
            return
    else:
        await cq.answer("Sahifa topilmadi.", show_alert=True)
        return
    await _send_task_list(cq.message, tasks, kind=kind, page=page, edit=True)
    await cq.answer()

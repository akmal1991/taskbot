from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.bot.i18n.strings import t
from app.bot.keyboards.common import main_menu_keyboard
from app.bot.states.forms import Registration
from app.core.config import get_settings
from app.models.enums import Language, UserRole
from app.models.user import User
from app.services.departments import list_departments
from app.services.exceptions import ServiceError
from app.services.users import submit_registration_request

router = Router(name="start")


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext, session: AsyncSession, user: User | None) -> None:
    await state.clear()
    if user is not None:
        if not user.is_active:
            await message.answer("Hisobingiz o'chirilgan. Administrator bilan bog'laning.")
            return
        await message.answer(t("main_menu", user.language), reply_markup=main_menu_keyboard(user.role, user.language))
        return

    settings = get_settings()
    # First-ever user, configured via BOOTSTRAP_SUPER_ADMIN_TELEGRAM_ID, is
    # auto-approved as Super Administrator so there is always someone able to
    # approve everyone else — otherwise registration would deadlock.
    if settings.bootstrap_super_admin_telegram_id and message.from_user.id == settings.bootstrap_super_admin_telegram_id:
        from app.services.users import get_user_by_telegram_id
        import datetime as dt

        existing = await get_user_by_telegram_id(session, message.from_user.id)
        if existing is None:
            bootstrap = User(
                telegram_id=message.from_user.id,
                username=message.from_user.username,
                full_name=settings.bootstrap_super_admin_name,
                role=UserRole.SUPER_ADMIN,
                language=settings.default_language,
                is_active=True,
                approved_at=dt.datetime.now(dt.timezone.utc),
            )
            session.add(bootstrap)
            await session.flush()
            await message.answer(
                "Siz tizimning birinchi Super Administratori sifatida avtomatik tasdiqlandingiz.",
                reply_markup=main_menu_keyboard(UserRole.SUPER_ADMIN, settings.default_language),
            )
            return

    await message.answer(t("welcome", Language.UZ_CYRL) + "\n\n" + t("not_registered", Language.UZ_CYRL))
    await state.set_state(Registration.full_name)

@router.message(Command("cancel"))
async def cancel_wizard(message: Message, state: FSMContext, user: User | None) -> None:
    await state.clear()
    keyboard = main_menu_keyboard(user.role, user.language) if user is not None and user.is_active else None
    await message.answer("Amal bekor qilindi. Qayta boshlash uchun /start yuboring.", reply_markup=keyboard)

@router.message(Command("myid"))
async def show_telegram_id(message: Message) -> None:
    await message.answer(f"Telegram ID: {message.from_user.id}", parse_mode=None)


@router.callback_query(F.data == "wizard:cancel")
async def cancel_wizard_button(cq: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await cq.answer("Bekor qilindi")


@router.message(Registration.full_name)
async def reg_full_name(message: Message, state: FSMContext) -> None:
    await state.update_data(full_name=message.text.strip())
    await state.set_state(Registration.phone)
    await message.answer("Телефон рақамингизни юборинг (ёки '-' деб ўтказиб юборинг):")


@router.message(Registration.phone)
async def reg_phone(message: Message, state: FSMContext, session: AsyncSession) -> None:
    phone = None if message.text.strip() == "-" else message.text.strip()
    await state.update_data(phone=phone)
    depts = await list_departments(session)
    data = await state.get_data()
    lines = ["Бўлимингизни рақами билан танланг:"]
    for i, d in enumerate(depts, start=1):
        lines.append(f"{i}. {d.name}")
    await state.update_data(dept_choices=[d.id for d in depts])
    await state.set_state(Registration.department)
    await message.answer("\n".join(lines) if depts else "Ҳозирча бўлимлар рўйхати бўш — рақам ўрнига '-' юборинг.")


@router.message(Registration.department)
async def reg_department(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    choices = data.get("dept_choices", [])
    dept_id = None
    text = message.text.strip()
    if text != "-" and text.isdigit() and 1 <= int(text) <= len(choices):
        dept_id = choices[int(text) - 1]
    elif text != "-":
        await message.answer("Ro'yxatdagi raqamni yoki '-' yuboring.")
        return
    await state.update_data(department_id=dept_id)
    await state.set_state(Registration.role)
    role_list = "\n".join(f"{i+1}. {r.value}" for i, r in enumerate(UserRole))
    await message.answer(
        "Қайси лавозим учун сўров юбормоқчисиз? (Супер администратор буни кейин тасдиқлайди)\n" + role_list
    )


@router.message(Registration.role)
async def reg_role(message: Message, state: FSMContext, session: AsyncSession) -> None:
    text = message.text.strip()
    roles = list(UserRole)
    role = None
    if text.isdigit() and 1 <= int(text) <= len(roles):
        role = roles[int(text) - 1]
    if role is None:
        await message.answer("Илтимос, рўйхатдаги рақамлардан бирини танланг.")
        return

    data = await state.get_data()
    try:
        await submit_registration_request(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            full_name=data["full_name"],
            phone=data.get("phone"),
            requested_role=role,
            requested_department_id=data.get("department_id"),
        )
    except ServiceError as exc:
        await message.answer(str(exc))
        await state.clear()
        return

    await state.clear()
    await message.answer(t("registration_pending", Language.UZ_CYRL))

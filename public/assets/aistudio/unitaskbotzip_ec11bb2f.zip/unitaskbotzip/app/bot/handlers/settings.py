from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.bot.filters import require_active_user
from app.bot.i18n.strings import all_variants
from app.bot.keyboards.common import main_menu_keyboard
from app.core.config import get_settings
from app.models.enums import Language
from app.models.user import User
from app.services.permissions import Actor, can_view_dashboard
from app.services.web_auth import issue_login_token

router = Router(name="settings")
router.message.filter(require_active_user)
router.callback_query.filter(require_active_user)

LANG_LABELS = {Language.UZ_CYRL: "Ўзбекча (кирилл)", Language.UZ_LATN: "O'zbekcha (lotin)", Language.RU: "Русский"}


@router.message(F.text.in_(all_variants("btn_settings")))
async def open_settings(message: Message) -> None:
    rows = [[InlineKeyboardButton(text=label, callback_data=f"lang:{lang.value}")] for lang, label in LANG_LABELS.items()]
    await message.answer("Interfeys tilini tanlang:", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.startswith("lang:"))
async def set_language(cq: CallbackQuery, session: AsyncSession, user: User) -> None:
    value = cq.data.split(":", 1)[1]
    user.language = Language(value)
    await session.flush()
    await cq.message.answer("✅ Til yangilandi.", reply_markup=main_menu_keyboard(user.role, user.language))
    await cq.answer()


@router.message(Command("weblogin"))
async def weblogin(message: Message, session: AsyncSession, user: User, actor: Actor) -> None:
    """Issues a one-time, 10-minute login link for the web dashboard. The
    link itself is the credential — no separate username/password exists —
    and it is only ever delivered to the Telegram account it was issued for."""
    if message.chat.type != "private":
        await message.answer("Kirish havolasini olish uchun botga shaxsiy chatda /weblogin yuboring.")
        return
    if not can_view_dashboard(actor):
        await message.answer("Sizda veb-boshqaruv panelidan foydalanish huquqi yo'q.")
        return
    token = await issue_login_token(session, user_id=user.id)
    settings = get_settings()
    link = f"{settings.web_base_url}/login?token={token}"
    await message.answer(
        "🔐 Boshqaruv panyeli uchun bir martalik havola (10 daqiqa amal qiladi):\n" + link
    )

from __future__ import annotations

import io

from aiogram import F, Router
from aiogram.types import BufferedInputFile, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.bot.filters import require_active_user
from app.bot.i18n.strings import all_variants
from app.excel_io.export import build_register_workbook
from app.models.enums import TaskStatus
from app.services import tasks as task_service
from app.services.permissions import Actor, can_view_dashboard

router = Router(name="reports")
router.message.filter(require_active_user)


@router.message(F.text.in_(all_variants("btn_reports")))
async def reports_summary(message: Message, session: AsyncSession, actor: Actor) -> None:
    all_tasks = await task_service.list_all_tasks(session, limit=100000)
    total = len(all_tasks)
    by_status = {s: 0 for s in TaskStatus}
    for tk in all_tasks:
        by_status[tk.status] += 1
    completed = by_status[TaskStatus.COMPLETED]
    rate = (completed / total * 100) if total else 0.0
    due_soon = await task_service.list_tasks_due_within(session, 7)

    lines = [
        "📊 <b>Umumiy hisobot</b>",
        f"Jami vazifalar: {total}",
        f"✅ Bajarilgan: {by_status[TaskStatus.COMPLETED]}",
        f"🔧 Jarayonda: {by_status[TaskStatus.IN_PROGRESS]}",
        f"🆕/📌 Boshlanmagan: {by_status[TaskStatus.CREATED] + by_status[TaskStatus.ASSIGNED]}",
        f"⚠️ Muddati o'tgan: {by_status[TaskStatus.OVERDUE]}",
        f"⛔ To'xtatilgan: {by_status[TaskStatus.PENDING_BLOCKED]}",
        f"📥 Ko'rikda: {by_status[TaskStatus.SUBMITTED_FOR_REVIEW]}",
        f"Umumiy bajarilish darajasi: {rate:.1f}%",
        f"7 kun ichida muddati tugaydigan: {len(due_soon)}",
    ]
    await message.answer("\n".join(lines), parse_mode="HTML")

    if can_view_dashboard(actor):
        wb = await build_register_workbook(session)
        buf = io.BytesIO()
        wb.save(buf)
        buf.seek(0)
        await message.answer_document(
            BufferedInputFile(buf.read(), filename="task_register_export.xlsx"),
            caption="To'liq reestr (Excel)",
        )

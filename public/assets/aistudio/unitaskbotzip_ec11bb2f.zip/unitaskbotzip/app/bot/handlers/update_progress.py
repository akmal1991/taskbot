from __future__ import annotations

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.bot.filters import require_active_user
from app.bot.i18n.strings import all_variants
from app.bot.render import task_list_line
from app.bot.states.forms import AttachEvidence, SubmitReview, UpdateProgress
from app.models.enums import TaskStatus
from app.models.user import User
from app.services import tasks as task_service
from app.services.exceptions import ServiceError
from app.services.permissions import Actor

router = Router(name="update_progress")
router.message.filter(require_active_user)
router.callback_query.filter(require_active_user)


def _actionable_tasks(tasks):
    return [t for t in tasks if t.status not in (TaskStatus.COMPLETED, TaskStatus.CANCELLED)]


@router.message(F.text.in_(all_variants("btn_update_progress")))
async def start_update(message: Message, state: FSMContext, session: AsyncSession, user: User) -> None:
    tasks = _actionable_tasks(await task_service.list_tasks_for_user(session, user.id))
    if not tasks:
        await message.answer("Yangilash uchun faol vazifalar yo'q.")
        return
    rows = [[InlineKeyboardButton(text=task_list_line(tk), callback_data=f"up:pick:{tk.id}")] for tk in tasks[:15]]
    await state.set_state(UpdateProgress.choose_task)
    await message.answer("Qaysi vazifa jarayonini yangilaysiz?", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(UpdateProgress.choose_task, F.data.startswith("up:pick:"))
async def pick_task(cq: CallbackQuery, state: FSMContext) -> None:
    task_id = int(cq.data.split(":")[-1])
    await state.update_data(task_id=task_id)
    await state.set_state(UpdateProgress.percent)
    await cq.message.answer("Bajarilish foizini kiriting (0–100):")
    await cq.answer()


@router.message(UpdateProgress.percent)
async def set_percent(message: Message, state: FSMContext, session: AsyncSession, actor: Actor) -> None:
    text = message.text.strip().rstrip("%")
    if not text.isdigit():
        await message.answer("Raqam kiriting, masalan: 45")
        return
    percent = int(text)
    data = await state.get_data()
    try:
        await task_service.update_progress(session, actor=actor, task_id=data["task_id"], progress_percent=percent)
    except ServiceError as exc:
        await message.answer(str(exc))
        return
    await state.clear()
    await message.answer(f"✅ Jarayon saqlandi: {percent}%")


@router.message(F.text.in_(all_variants("btn_submit_report")))
async def start_submit(message: Message, state: FSMContext, session: AsyncSession, user: User) -> None:
    tasks = [t for t in _actionable_tasks(await task_service.list_tasks_for_user(session, user.id))
             if t.status in (TaskStatus.IN_PROGRESS, TaskStatus.OVERDUE)]
    if not tasks:
        await message.answer("Ko'rikka topshirish mumkin bo'lgan vazifalar yo'q (avval 'Jarayonda' holatiga o'tkazing).")
        return
    rows = [[InlineKeyboardButton(text=task_list_line(tk), callback_data=f"sub:pick:{tk.id}")] for tk in tasks[:15]]
    await state.set_state(SubmitReview.choose_task)
    await message.answer("Qaysi vazifani ko'rikka topshirasiz?", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(SubmitReview.choose_task, F.data.startswith("sub:pick:"))
async def submit_pick(cq: CallbackQuery, state: FSMContext) -> None:
    task_id = int(cq.data.split(":")[-1])
    await state.update_data(task_id=task_id)
    await state.set_state(SubmitReview.comment)
    await cq.message.answer("Izoh qoldiring (yoki '-'), so'ngra dalil (rasm/hujjat) alohida yuborishingiz mumkin:")
    await cq.answer()


@router.message(SubmitReview.comment)
async def submit_comment(message: Message, state: FSMContext, session: AsyncSession, actor: Actor) -> None:
    comment = None if message.text.strip() == "-" else message.text.strip()
    data = await state.get_data()
    try:
        await task_service.submit_for_review(session, actor=actor, task_id=data["task_id"], comment=comment)
    except ServiceError as exc:
        await message.answer(str(exc))
        return
    await state.clear()
    await message.answer("✅ Vazifa ko'rikka topshirildi. Masul rahbar tasdiqlashini kuting.")


@router.message(F.photo | F.document | F.video)
async def receive_attachment(message: Message, session: AsyncSession, actor: Actor | None, state: FSMContext) -> None:
    """Any photo/document/video sent to the bot outside a wizard is treated
    as completion evidence for the sender's most recently submitted task, if
    unambiguous — otherwise they're asked to use the task card instead."""
    if actor is None:
        return
    state_data = await state.get_data()
    if await state.get_state() == AttachEvidence.file.state and state_data.get("task_id"):
        candidates = [await task_service.get_task_for_viewer(session, actor, state_data["task_id"])]
    else:
        tasks = await task_service.list_tasks_for_user(session, actor.id)
        candidates = [t for t in tasks if t.status in (TaskStatus.SUBMITTED_FOR_REVIEW, TaskStatus.IN_PROGRESS)]
    if len(candidates) != 1:
        await message.answer(
            "Qaysi vazifaga tegishli ekanini aniqlay olmadim. Avval vazifa kartasini oching va u yerdan yuboring."
        )
        return
    task = candidates[0]
    file_id, file_type = None, None
    if message.photo:
        file_id, file_type = message.photo[-1].file_id, "photo"
    elif message.document:
        file_id, file_type = message.document.file_id, "document"
    elif message.video:
        file_id, file_type = message.video.file_id, "video"
    try:
        await task_service.add_attachment(
            session, actor=actor, task_id=task.id, telegram_file_id=file_id, file_type=file_type,
            caption=message.caption, is_completion_evidence=task.status == TaskStatus.SUBMITTED_FOR_REVIEW,
        )
    except ServiceError as exc:
        await message.answer(str(exc), parse_mode=None)
        return
    await state.clear()
    await message.answer(f"📎 Fayl {task.public_code} vazifasiga biriktirildi.", parse_mode=None)

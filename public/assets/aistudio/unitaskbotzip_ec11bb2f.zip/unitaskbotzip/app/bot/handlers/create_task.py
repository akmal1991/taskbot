from __future__ import annotations

import datetime as dt

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.bot.filters import require_active_user
from app.bot.i18n.strings import all_variants
from app.bot.states.forms import CreateTask
from app.models.enums import Priority, UserRole
from app.models.user import User
from app.services import tasks as task_service
from app.services.departments import list_departments
from app.services.exceptions import ServiceError
from app.services.permissions import Actor
from sqlalchemy import select

router = Router(name="create_task")
router.message.filter(require_active_user)
router.callback_query.filter(require_active_user)


@router.message(F.text.in_(all_variants("btn_create_task")))
async def start_create(message: Message, state: FSMContext, actor: Actor) -> None:
    if actor.role not in (UserRole.SUPER_ADMIN, UserRole.RECTOR, UserRole.VICE_RECTOR, UserRole.DEPARTMENT_HEAD):
        await message.answer("Sizning rolingiz vazifa yaratishga ruxsat bermaydi.")
        return
    await state.set_state(CreateTask.title)
    await message.answer("Vazifa nomini kiriting:")


@router.message(CreateTask.title)
async def ct_title(message: Message, state: FSMContext) -> None:
    await state.update_data(title=message.text.strip())
    await state.set_state(CreateTask.description)
    await message.answer("Tavsifini kiriting (yoki '-' deb o'tkazib yuboring):")


@router.message(CreateTask.description)
async def ct_description(message: Message, state: FSMContext) -> None:
    val = None if message.text.strip() == "-" else message.text.strip()
    await state.update_data(description=val)
    await state.set_state(CreateTask.expected_outcome)
    await message.answer("Kutilayotgan natijani kiriting (yoki '-'):")


@router.message(CreateTask.expected_outcome)
async def ct_expected(message: Message, state: FSMContext) -> None:
    val = None if message.text.strip() == "-" else message.text.strip()
    await state.update_data(expected_outcome=val)
    await state.set_state(CreateTask.source_reference)
    await message.answer("Topshiriq manbasi (rektor buyrug'i, yig'ilish qarori va h.k.) yoki '-':")


@router.message(CreateTask.source_reference)
async def ct_source(message: Message, state: FSMContext, session: AsyncSession) -> None:
    val = None if message.text.strip() == "-" else message.text.strip()
    await state.update_data(source_reference=val)
    depts = await list_departments(session)
    await state.update_data(dept_choices=[d.id for d in depts])
    rows = [[InlineKeyboardButton(text=d.name, callback_data=f"ct:dept:{d.id}")] for d in depts]
    rows.append([InlineKeyboardButton(text="— (belgilanmagan) —", callback_data="ct:dept:0")])
    await state.set_state(CreateTask.department)
    await message.answer("Javobgar bo'limni tanlang:", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(CreateTask.department, F.data.startswith("ct:dept:"))
async def ct_department(cq: CallbackQuery, state: FSMContext, session: AsyncSession) -> None:
    dept_id = int(cq.data.split(":")[-1]) or None
    await state.update_data(department_id=dept_id)

    stmt = select(User).where(User.is_active.is_(True))
    if dept_id is not None:
        stmt = stmt.where(User.department_id == dept_id)
    result = await session.execute(stmt.limit(30))
    users = list(result.scalars().all())
    if not users:
        await cq.message.answer("Faol foydalanuvchi topilmadi. Boshqa bo'limni tanlang yoki /cancel yuboring.")
        await cq.answer()
        return
    rows = [[InlineKeyboardButton(text=f"{u.full_name} ({u.role.value})", callback_data=f"ct:resp:{u.id}")] for u in users]
    await state.set_state(CreateTask.responsible)
    await cq.message.answer("Asosiy mas'ul shaxsni tanlang:", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await cq.answer()


@router.callback_query(CreateTask.responsible, F.data.startswith("ct:resp:"))
async def ct_responsible(cq: CallbackQuery, state: FSMContext) -> None:
    user_id = int(cq.data.split(":")[-1])
    await state.update_data(primary_responsible_id=user_id)
    rows = [[InlineKeyboardButton(text=p.value, callback_data=f"ct:prio:{p.value}")] for p in Priority]
    await state.set_state(CreateTask.priority)
    await cq.message.answer("Muhimlik darajasini tanlang:", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await cq.answer()


@router.callback_query(CreateTask.priority, F.data.startswith("ct:prio:"))
async def ct_priority(cq: CallbackQuery, state: FSMContext) -> None:
    value = cq.data.split(":")[-1]
    await state.update_data(priority=value)
    await state.set_state(CreateTask.deadline)
    await cq.message.answer("Muddatni kiriting (KK.OO.YYYY) yoki '-' agar muddatsiz:")
    await cq.answer()


@router.message(CreateTask.deadline)
async def ct_deadline(message: Message, state: FSMContext, session: AsyncSession, actor: Actor) -> None:
    text = message.text.strip()
    deadline = None
    if text != "-":
        try:
            deadline = dt.datetime.strptime(text, "%d.%m.%Y").date()
        except ValueError:
            await message.answer("Sana noto'g'ri formatda. Misol: 25.12.2026")
            return

    data = await state.get_data()
    try:
        task = await task_service.create_task(
            session,
            actor=actor,
            title=data["title"],
            description=data.get("description"),
            expected_outcome=data.get("expected_outcome"),
            acceptance_criteria=None,
            source_reference=data.get("source_reference"),
            department_id=data.get("department_id"),
            primary_responsible_id=data.get("primary_responsible_id"),
            priority=Priority(data["priority"]),
            deadline=deadline,
        )
    except ServiceError as exc:
        await message.answer(str(exc))
        return

    await state.clear()
    await message.answer(f"✅ Vazifa yaratildi: {task.public_code} — {task.title}", parse_mode=None)

from __future__ import annotations

from aiogram import F, Router
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.bot.filters import require_active_user
from app.bot.i18n.strings import all_variants
from app.models.enums import UserRole
from app.services.exceptions import ServiceError
from app.services.permissions import Actor
from app.services.users import approve_registration, list_pending_registrations, reject_registration

router = Router(name="admin")
router.message.filter(require_active_user)
router.callback_query.filter(require_active_user)


@router.message(F.text.in_(all_variants("btn_user_management")))
async def user_management(message: Message, session: AsyncSession, actor: Actor) -> None:
    if actor.role != UserRole.SUPER_ADMIN:
        await message.answer("Faqat Super Administrator uchun.")
        return
    pending = await list_pending_registrations(session)
    if not pending:
        await message.answer("Yangi ro'yxatdan o'tish so'rovlari yo'q.")
        return
    for req in pending[:10]:
        text = (
            f"👤 {req.full_name}\nTelegram ID: {req.telegram_id}\n"
            f"So'ralgan rol: {req.requested_role.value}\nTelefon: {req.phone or '-'}"
        )
        kb = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="✅ Tasdiqlash", callback_data=f"admin:approve:{req.id}"),
            InlineKeyboardButton(text="❌ Rad etish", callback_data=f"admin:reject:{req.id}"),
        ]])
        await message.answer(text, reply_markup=kb, parse_mode=None)


@router.callback_query(F.data.startswith("admin:approve:"))
async def do_approve(cq: CallbackQuery, session: AsyncSession, actor: Actor) -> None:
    request_id = int(cq.data.split(":")[-1])
    try:
        user = await approve_registration(session, actor=actor, request_id=request_id)
    except ServiceError as exc:
        await cq.answer(str(exc), show_alert=True)
        return
    await cq.message.edit_text(cq.message.text + f"\n\n✅ Tasdiqlandi ({user.role.value})", parse_mode=None)
    await cq.answer()


@router.callback_query(F.data.startswith("admin:reject:"))
async def do_reject(cq: CallbackQuery, session: AsyncSession, actor: Actor) -> None:
    request_id = int(cq.data.split(":")[-1])
    try:
        await reject_registration(session, actor=actor, request_id=request_id, reason="Rad etildi (admin)")
    except ServiceError as exc:
        await cq.answer(str(exc), show_alert=True)
        return
    await cq.message.edit_text(cq.message.text + "\n\n❌ Rad etildi", parse_mode=None)
    await cq.answer()

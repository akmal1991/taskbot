from __future__ import annotations

from aiogram import Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.bot.filters import require_active_user
from app.bot.render import task_card
from app.bot.states.forms import AttachEvidence, BlockTask, CancelTask, ReturnTask, UpdateProgress
from app.models.enums import ALLOWED_TRANSITIONS, TaskStatus
from app.models.user import User
from app.services import tasks as task_service
from app.services.exceptions import ServiceError
from app.services.permissions import (
    Actor,
    can_approve_or_return,
    can_cancel_task,
    can_update_progress,
)

router = Router(name="task_detail")
router.message.filter(require_active_user)
router.callback_query.filter(require_active_user)


def _action_keyboard(task, actor: Actor) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    tid = task.id

    if task.status == TaskStatus.ASSIGNED and actor.id == task.primary_responsible_id:
        rows.append([InlineKeyboardButton(text="👀 Қабул қилдим", callback_data=f"task:ack:{tid}")])

    if can_update_progress(actor, task) and task.status not in (TaskStatus.COMPLETED, TaskStatus.CANCELLED):
        rows.append([
            InlineKeyboardButton(text="📊 Jarayonni yangilash", callback_data=f"task:progress:{tid}"),
            InlineKeyboardButton(text="📎 Dalil biriktirish", callback_data=f"task:attach:{tid}"),
        ])
        if task.status in (TaskStatus.ASSIGNED, TaskStatus.ACKNOWLEDGED, TaskStatus.OVERDUE):
            rows.append([InlineKeyboardButton(text="▶️ Boshlash", callback_data=f"task:resume:{tid}")])
        if task.status == TaskStatus.PENDING_BLOCKED:
            rows.append([InlineKeyboardButton(text="▶️ Тўхтатишни бекор қилиш", callback_data=f"task:unblock:{tid}")])
        elif TaskStatus.PENDING_BLOCKED in ALLOWED_TRANSITIONS.get(task.status, set()):
            rows.append([InlineKeyboardButton(text="⛔ Тўхтатиш (блок)", callback_data=f"task:block:{tid}")])
        if task.status in (TaskStatus.IN_PROGRESS, TaskStatus.OVERDUE):
            rows.append([InlineKeyboardButton(text="📥 Кўрикка топшириш", callback_data=f"task:submit:{tid}")])
        if task.status == TaskStatus.RETURNED_FOR_REVISION:
            rows.append([InlineKeyboardButton(text="🔁 Қайта бошлаш", callback_data=f"task:resume:{tid}")])

    if can_approve_or_return(actor, task) and task.status == TaskStatus.SUBMITTED_FOR_REVIEW:
        rows.append([
            InlineKeyboardButton(text="✅ Тасдиқлаш", callback_data=f"task:approve:{tid}"),
            InlineKeyboardButton(text="↩️ Қайтариш", callback_data=f"task:return:{tid}"),
        ])

    if can_cancel_task(actor, task) and TaskStatus.CANCELLED in ALLOWED_TRANSITIONS.get(task.status, set()):
        rows.append([InlineKeyboardButton(text="🚫 Бекор қилиш", callback_data=f"task:cancel:{tid}")])

    return InlineKeyboardMarkup(inline_keyboard=rows)


@router.callback_query(lambda c: c.data and c.data.startswith(("task:progress:", "task:attach:")))
async def cb_task_input(cq: CallbackQuery, state: FSMContext, session: AsyncSession, actor: Actor) -> None:
    try:
        task_id = int(cq.data.split(":")[-1])
        task = await task_service.get_task_for_viewer(session, actor, task_id)
        if not can_update_progress(actor, task) or task.status in (TaskStatus.COMPLETED, TaskStatus.CANCELLED):
            await cq.answer("Bu amal uchun ruxsat yo'q.", show_alert=True)
            return
    except (ServiceError, ValueError) as exc:
        await cq.answer(str(exc), show_alert=True)
        return
    await state.update_data(task_id=task.id)
    if cq.data.startswith("task:attach:"):
        await state.set_state(AttachEvidence.file)
        await cq.message.answer("Ushbu vazifa uchun rasm, hujjat yoki video yuboring (yoki /cancel).")
    else:
        await state.set_state(UpdateProgress.percent)
        await cq.message.answer("Bajarilish foizini kiriting (0–100):")
    await cq.answer()


async def render_task(message_or_cb, session: AsyncSession, actor: Actor, task_id: int, *, edit: bool = False) -> None:
    task = await task_service.get_task_for_viewer(session, actor, task_id)
    text = task_card(task)
    kb = _action_keyboard(task, actor)
    if edit and isinstance(message_or_cb, CallbackQuery):
        await message_or_cb.message.edit_text(text, reply_markup=kb, parse_mode="HTML")
    elif isinstance(message_or_cb, CallbackQuery):
        await message_or_cb.message.answer(text, reply_markup=kb, parse_mode="HTML")
    else:
        await message_or_cb.answer(text, reply_markup=kb, parse_mode="HTML")


@router.callback_query(lambda c: c.data and c.data.startswith("task:view:"))
async def cb_view(cq: CallbackQuery, session: AsyncSession, actor: Actor | None) -> None:
    if actor is None:
        await cq.answer("Avval ro'yxatdan o'ting.", show_alert=True)
        return
    task_id = int(cq.data.split(":")[-1])
    try:
        await render_task(cq, session, actor, task_id, edit=True)
    except ServiceError as exc:
        await cq.answer(str(exc), show_alert=True)
        return
    await cq.answer()


@router.callback_query(lambda c: c.data and c.data.startswith("task:ack:"))
async def cb_ack(cq: CallbackQuery, session: AsyncSession, actor: Actor) -> None:
    task_id = int(cq.data.split(":")[-1])
    try:
        await task_service.acknowledge_task(session, actor=actor, task_id=task_id)
    except ServiceError as exc:
        await cq.answer(str(exc), show_alert=True)
        return
    await render_task(cq, session, actor, task_id, edit=True)
    await cq.answer("Qabul qilindi")


@router.callback_query(lambda c: c.data and c.data.startswith("task:unblock:"))
async def cb_unblock(cq: CallbackQuery, session: AsyncSession, actor: Actor) -> None:
    task_id = int(cq.data.split(":")[-1])
    try:
        await task_service.unblock_task(session, actor=actor, task_id=task_id)
    except ServiceError as exc:
        await cq.answer(str(exc), show_alert=True)
        return
    await render_task(cq, session, actor, task_id, edit=True)
    await cq.answer()


@router.callback_query(lambda c: c.data and c.data.startswith("task:resume:"))
async def cb_resume(cq: CallbackQuery, session: AsyncSession, actor: Actor) -> None:
    task_id = int(cq.data.split(":")[-1])
    try:
        await task_service.resume_after_revision(session, actor=actor, task_id=task_id)
    except ServiceError as exc:
        await cq.answer(str(exc), show_alert=True)
        return
    await render_task(cq, session, actor, task_id, edit=True)
    await cq.answer()


@router.callback_query(lambda c: c.data and c.data.startswith("task:submit:"))
async def cb_submit(cq: CallbackQuery, session: AsyncSession, actor: Actor) -> None:
    task_id = int(cq.data.split(":")[-1])
    try:
        await task_service.submit_for_review(session, actor=actor, task_id=task_id)
    except ServiceError as exc:
        await cq.answer(str(exc), show_alert=True)
        return
    await render_task(cq, session, actor, task_id, edit=True)
    await cq.answer("Ko'rikka topshirildi")


@router.callback_query(lambda c: c.data and c.data.startswith("task:approve:"))
async def cb_approve(cq: CallbackQuery, session: AsyncSession, actor: Actor) -> None:
    task_id = int(cq.data.split(":")[-1])
    try:
        await task_service.approve_task(session, actor=actor, task_id=task_id)
    except ServiceError as exc:
        await cq.answer(str(exc), show_alert=True)
        return
    await render_task(cq, session, actor, task_id, edit=True)
    await cq.answer("Tasdiqlandi")


@router.callback_query(lambda c: c.data and c.data.startswith("task:return:"))
async def cb_return_start(cq: CallbackQuery, state: FSMContext) -> None:
    task_id = int(cq.data.split(":")[-1])
    await state.set_state(ReturnTask.comment)
    await state.update_data(task_id=task_id)
    await cq.message.answer("Qaytarish sababini yozing:")
    await cq.answer()


@router.message(ReturnTask.comment)
async def return_comment(message: Message, state: FSMContext, session: AsyncSession, actor: Actor) -> None:
    data = await state.get_data()
    try:
        await task_service.return_for_revision(session, actor=actor, task_id=data["task_id"], comment=message.text)
    except ServiceError as exc:
        await message.answer(str(exc))
        return
    await state.clear()
    await render_task(message, session, actor, data["task_id"])


@router.callback_query(lambda c: c.data and c.data.startswith("task:block:"))
async def cb_block_start(cq: CallbackQuery, state: FSMContext) -> None:
    task_id = int(cq.data.split(":")[-1])
    await state.set_state(BlockTask.reason)
    await state.update_data(task_id=task_id)
    await cq.message.answer("To'xtash sababini yozing:")
    await cq.answer()


@router.message(BlockTask.reason)
async def block_reason(message: Message, state: FSMContext, session: AsyncSession, actor: Actor) -> None:
    data = await state.get_data()
    try:
        await task_service.block_task(session, actor=actor, task_id=data["task_id"], reason=message.text)
    except ServiceError as exc:
        await message.answer(str(exc))
        return
    await state.clear()
    await render_task(message, session, actor, data["task_id"])


@router.callback_query(lambda c: c.data and c.data.startswith("task:cancel:"))
async def cb_cancel_start(cq: CallbackQuery, state: FSMContext) -> None:
    task_id = int(cq.data.split(":")[-1])
    await state.set_state(CancelTask.reason)
    await state.update_data(task_id=task_id)
    await cq.message.answer("Bekor qilish sababini yozing:")
    await cq.answer()


@router.message(CancelTask.reason)
async def cancel_reason(message: Message, state: FSMContext, session: AsyncSession, actor: Actor) -> None:
    data = await state.get_data()
    try:
        await task_service.cancel_task(session, actor=actor, task_id=data["task_id"], reason=message.text)
    except ServiceError as exc:
        await message.answer(str(exc))
        return
    await state.clear()
    await render_task(message, session, actor, data["task_id"])

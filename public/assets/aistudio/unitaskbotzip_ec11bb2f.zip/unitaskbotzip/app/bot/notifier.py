"""Drains the Notification queue (app.services.notifications) and actually
sends each one through the Telegram Bot API. Called periodically by the
scheduler (app/scheduler/jobs.py), not by request/response bot handlers."""
from __future__ import annotations

import datetime as dt
import logging

from aiogram import Bot
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError, TelegramRetryAfter

from app.core.db import session_scope
from app.models.user import User
from app.services import notifications as notif_service

logger = logging.getLogger(__name__)


async def flush_notification_queue(bot: Bot, *, batch_size: int = 200) -> tuple[int, int]:
    sent, failed = 0, 0
    async with session_scope() as session:
        due = await notif_service.list_due(session, limit=batch_size)
        for notif in due:
            recipient = await session.get(User, notif.recipient_user_id)
            if recipient is None or not recipient.is_active:
                await notif_service.mark_failed(session, notif.id, "recipient inactive or missing")
                failed += 1
                continue
            try:
                await bot.send_message(chat_id=recipient.telegram_id, text=notif.text_rendered, parse_mode=None)
                await notif_service.mark_sent(session, notif.id)
                sent += 1
            except TelegramRetryAfter as exc:
                # Honor Telegram's retry deadline and stop this batch.
                logger.warning("Rate limited sending notification %s, retry after %ss", notif.id, exc.retry_after)
                notif.scheduled_for = dt.datetime.now(dt.timezone.utc) + dt.timedelta(seconds=exc.retry_after)
                break
            except TelegramForbiddenError:
                # User blocked the bot — stop trying to reach them for this one.
                await notif_service.mark_failed(session, notif.id, "blocked the bot")
                failed += 1
            except TelegramBadRequest:
                await notif_service.mark_failed(session, notif.id, "Telegram rejected the message")
                failed += 1
            except Exception as exc:  # noqa: BLE001 — one bad send must not stop the batch
                logger.warning("Notification %s failed (%s); retrying later", notif.id, type(exc).__name__)
                notif.scheduled_for = dt.datetime.now(dt.timezone.utc) + dt.timedelta(minutes=5)
                failed += 1
    return sent, failed

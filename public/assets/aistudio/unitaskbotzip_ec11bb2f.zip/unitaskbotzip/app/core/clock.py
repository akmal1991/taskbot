"""One calendar for whole-day deadlines, independent of the host timezone."""
import datetime as dt
from zoneinfo import ZoneInfo

from app.core.config import get_settings


def today() -> dt.date:
    return dt.datetime.now(ZoneInfo(get_settings().scheduler_timezone)).date()

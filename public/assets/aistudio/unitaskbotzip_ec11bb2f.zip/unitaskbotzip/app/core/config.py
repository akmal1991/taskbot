"""Centralized application settings, loaded from environment variables.

All secrets (bot token, DB password, etc.) come from the environment, never
from source. See .env.example for the full list of variables.
"""
from __future__ import annotations

import os
import logging
import re
from functools import lru_cache
from typing import Literal

from pydantic import AliasChoices, Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict
from sqlalchemy.engine import make_url


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env", env_file_encoding="utf-8", extra="ignore", hide_input_in_errors=True
    )

    # --- Telegram ---
    bot_token: str = Field(default="", repr=False, description="Token issued by @BotFather")
    bot_parse_mode: str = "HTML"

    # --- Database ---
    database_url: str = Field(
        default="postgresql+asyncpg://postgres:postgres@localhost:5432/uni_task_bot",
        description="SQLAlchemy async URL, e.g. postgresql+asyncpg://user:pass@host:5432/dbname",
        repr=False,
    )
    db_echo: bool = False

    # --- Redis (FSM storage). Optional: many lightweight hosts (Replit, a
    # small VPS without Redis installed) don't have Redis available. Leave
    # this blank/unset and the bot falls back to aiogram's in-memory FSM
    # storage automatically (see app/bot/main.py) — registration/task
    # wizards still work fine; they just reset if the process restarts
    # mid-wizard, which is a minor inconvenience, not a data-loss risk
    # (nothing is written to Postgres until a wizard actually completes).
    redis_url: str = ""

    # --- Scheduler ---
    scheduler_timezone: str = "Asia/Tashkent"
    reminder_days_before: list[int] = Field(default_factory=lambda: [7, 3, 1])
    overdue_reminder_interval_hours: int = Field(default=24, ge=1)
    escalation_dept_head_days: int = 1
    escalation_vice_rector_days: int = 3
    escalation_rector_days: int = 7

    # --- Web dashboard ---
    web_host: str = "0.0.0.0"
    web_port: int = Field(default=8080, ge=1, le=65535)
    web_secret_key: str = Field(
        default="CHANGE_ME_DEV_ONLY",
        validation_alias=AliasChoices("web_secret_key", "SESSION_SECRET"),
        description="Session signing key (WEB_SECRET_KEY or Replit SESSION_SECRET)",
        repr=False,
    )
    web_base_url: str = Field(
        default_factory=lambda: (
            f"https://{os.environ['REPLIT_DEV_DOMAIN']}"
            if os.environ.get("REPLIT_DEV_DOMAIN")
            else "http://localhost:8080"
        ),
        description="Public base URL used to build /weblogin links sent to users via Telegram",
    )

    # --- App behaviour ---
    default_language: Literal["uz_cyrl", "uz_latn", "ru"] = "uz_cyrl"
    environment: Literal["development", "production", "test"] = "development"
    log_level: str = "INFO"

    # --- Bootstrap super-admin (first run only) ---
    bootstrap_super_admin_telegram_id: int | None = Field(default=None, gt=0)
    bootstrap_super_admin_name: str = "Super Administrator"

    @field_validator("bot_token")
    @classmethod
    def _trim_bot_token(cls, value: str) -> str:
        # Clipboard newlines around a credential are not part of the token.
        value = value.strip()
        # A secure input sometimes contains BotFather's whole response.
        # Accept that known format only when the credential is unambiguous;
        # never guess at arbitrary text or concatenate whitespace in a token.
        if "Use this token to access the HTTP API:" in value:
            candidates = re.findall(r"(?<![\w:])\d{5,}:[A-Za-z0-9_-]{20,}(?![\w-])", value)
            if len(candidates) == 1:
                logging.getLogger(__name__).warning(
                    "BOT_TOKEN contains a BotFather reply; using its single token without displaying it."
                )
                return candidates[0]
        return value

    @field_validator("bootstrap_super_admin_telegram_id", mode="before")
    @classmethod
    def _blank_bootstrap_id(cls, value):
        if isinstance(value, str):
            value = value.strip().removeprefix("Telegram ID:").strip()
        return None if value == "" else value

    @field_validator("database_url")
    @classmethod
    def _normalize_database_url(cls, value: str) -> str:
        """Hosted Postgres providers (Replit's built-in database, Neon,
        Supabase, Heroku-style hosts) hand out a plain `postgres://` or
        `postgresql://` connection string for the sync psycopg2 driver.
        This app uses SQLAlchemy's async engine, which needs the asyncpg
        driver spelled out (`postgresql+asyncpg://`) — rewrite it
        automatically rather than making every deployment target edit the
        URL by hand.
        """
        if value.startswith("postgres://"):
            value = "postgresql+asyncpg://" + value[len("postgres://"):]
        if value.startswith("postgresql://"):
            value = "postgresql+asyncpg://" + value[len("postgresql://"):]
        if value.startswith("postgresql+asyncpg://"):
            url = make_url(value)
            if "sslmode" in url.query:
                # asyncpg accepts the same mode names under `ssl`, not
                # libpq's `sslmode`. Preserve the requested TLS policy.
                query = dict(url.query)
                query.setdefault("ssl", query.pop("sslmode"))
                value = url.set(query=query).render_as_string(hide_password=False)
        return value


@lru_cache
def get_settings() -> Settings:
    return Settings()

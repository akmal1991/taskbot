"""Session-cookie auth for the dashboard, built on the Telegram-issued
WebLoginToken (see app/services/web_auth.py) rather than a username/password
system — the login link itself is the only credential, and it is sent to the
user's own Telegram account."""
from __future__ import annotations

from fastapi import Depends, HTTPException, Request, status
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.db import get_session_factory
from app.models.user import User

SESSION_COOKIE_NAME = "session"
SESSION_MAX_AGE_SECONDS = 60 * 60 * 12  # 12h — a dashboard session, not a long-lived login


def _serializer() -> URLSafeTimedSerializer:
    settings = get_settings()
    if len(settings.web_secret_key) < 32 or settings.web_secret_key.startswith("CHANGE_ME"):
        raise RuntimeError("Set WEB_SECRET_KEY or SESSION_SECRET to a strong secret of at least 32 characters.")
    return URLSafeTimedSerializer(settings.web_secret_key, salt="uni-task-bot-web-session")


def make_session_cookie(user_id: int) -> str:
    return _serializer().dumps({"user_id": user_id})


def read_session_cookie(cookie_value: str) -> int | None:
    try:
        data = _serializer().loads(cookie_value, max_age=SESSION_MAX_AGE_SECONDS)
    except (BadSignature, SignatureExpired):
        return None
    if not isinstance(data, dict):
        return None
    user_id = data.get("user_id")
    return user_id if type(user_id) is int and user_id > 0 else None


async def get_db_session() -> AsyncSession:
    factory = get_session_factory()
    async with factory() as session:
        yield session


async def get_current_user(
    request: Request, session: AsyncSession = Depends(get_db_session)
) -> User:
    cookie_value = request.cookies.get(SESSION_COOKIE_NAME)
    user_id = read_session_cookie(cookie_value) if cookie_value else None
    if user_id is None:
        raise HTTPException(status_code=status.HTTP_303_SEE_OTHER, headers={"Location": "/login"})
    user = await session.get(User, user_id)
    if user is None or not user.is_active:
        raise HTTPException(status_code=status.HTTP_303_SEE_OTHER, headers={"Location": "/login"})
    return user

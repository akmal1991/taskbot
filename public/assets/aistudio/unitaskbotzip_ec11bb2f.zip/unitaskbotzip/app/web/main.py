"""Read-only executive dashboard.

Auth is Telegram-token based (see app/services/web_auth.py and the bot's
/weblogin command) — there is no username/password system. A dashboard
session is a signed cookie (app/web/auth.py), valid for 12 hours.

Visibility mirrors `can_view_dashboard`: Super Admin, Rector, Observer see
everything; Vice-Rector and Department Head see their own scope today and
get full visibility once department-scoped filtering is requested (not yet
asked for by the university, so this view currently shows the same
cross-department register to every role that passes the gate — see
README/docs for the explicit decision log).
"""
from __future__ import annotations

import datetime as dt
import io
from typing import Annotated

from fastapi import Depends, FastAPI, Request
from fastapi.responses import HTMLResponse, RedirectResponse, Response, StreamingResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BeforeValidator

from app.excel_io.export import build_register_workbook
from app.models.department import Department
from app.models.enums import Priority, TaskStatus
from app.models.user import User
from app.core.config import get_settings
from app.services import tasks as task_service
from app.services.permissions import Actor, can_view_dashboard
from app.services.web_auth import redeem_login_token
from app.web.auth import SESSION_COOKIE_NAME, get_current_user, get_db_session, make_session_cookie

app = FastAPI(title="Uni Task Bot Dashboard")
templates = Jinja2Templates(directory="app/web/templates")

@app.get("/favicon.ico", include_in_schema=False)
async def favicon():
    return Response(status_code=204)

@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["Cache-Control"] = "no-store"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["X-Content-Type-Options"] = "nosniff"
    return response


@app.get("/login", response_class=HTMLResponse)
async def login(request: Request, token: str | None = None, session: AsyncSession = Depends(get_db_session)):
    if not token:
        return templates.TemplateResponse(request, "login.html", {})

    user = await redeem_login_token(session, token=token)
    await session.commit()
    if user is None:
        return templates.TemplateResponse(
            request, "login.html", {"error": "Havola yaroqsiz yoki muddati tugagan."}, status_code=400
        )

    response = RedirectResponse(url="/dashboard", status_code=302)
    response.set_cookie(
        SESSION_COOKIE_NAME, make_session_cookie(user.id), httponly=True, samesite="lax", max_age=60 * 60 * 12,
        secure=request.url.scheme == "https" or get_settings().web_base_url.startswith("https://"),
    )
    return response


@app.get("/logout")
async def logout():
    response = RedirectResponse(url="/login", status_code=302)
    response.delete_cookie(SESSION_COOKIE_NAME)
    return response


@app.get("/")
async def index():
    return RedirectResponse(url="/dashboard", status_code=302)


@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard(
    request: Request,
    department_id: Annotated[int | None, BeforeValidator(lambda value: None if value == "" else value)] = None,
    status_filter: str | None = None,
    priority_filter: str | None = None,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_db_session),
):
    actor = Actor.from_user(user)
    if not can_view_dashboard(actor):
        return templates.TemplateResponse(
            request, "login.html", {"error": "Sizda boshqaruv panelidan foydalanish huquqi yo'q."}, status_code=403
        )

    all_tasks = await task_service.list_all_tasks(session, limit=100000)

    tasks = all_tasks
    if department_id:
        tasks = [t for t in tasks if t.department_id == department_id]
    if status_filter:
        tasks = [t for t in tasks if t.status.value == status_filter]
    if priority_filter:
        tasks = [t for t in tasks if t.priority.value == priority_filter]

    total = len(all_tasks)
    by_status = {s: 0 for s in TaskStatus}
    for tk in all_tasks:
        by_status[tk.status] += 1
    completed = by_status[TaskStatus.COMPLETED]
    completion_rate = (completed / total * 100) if total else 0.0
    due_soon = await task_service.list_tasks_due_within(session, 7)

    completed_on_time = sum(
        1 for t in all_tasks
        if t.status == TaskStatus.COMPLETED and t.actual_completion_date and t.deadline
        and t.actual_completion_date <= t.deadline
    )
    on_time_rate = (completed_on_time / completed * 100) if completed else 0.0

    completion_days = [
        (t.actual_completion_date - t.assigned_date).days
        for t in all_tasks
        if t.status == TaskStatus.COMPLETED and t.actual_completion_date and t.assigned_date
    ]
    avg_completion_days = (sum(completion_days) / len(completion_days)) if completion_days else None

    kpis = [
        ("Jami vazifalar", total),
        ("✅ Bajarilgan", by_status[TaskStatus.COMPLETED]),
        ("🔧 Jarayonda", by_status[TaskStatus.IN_PROGRESS]),
        ("⚠️ Muddati o'tgan", by_status[TaskStatus.OVERDUE]),
        ("⛔ To'xtatilgan", by_status[TaskStatus.PENDING_BLOCKED]),
        ("📥 Tasdiqlashda", by_status[TaskStatus.SUBMITTED_FOR_REVIEW]),
        ("7 kun ichida muddati tugaydi", len(due_soon)),
        ("Bajarilish darajasi", f"{completion_rate:.1f}%"),
        ("O'z vaqtida bajarish", f"{on_time_rate:.1f}%"),
        ("O'rtacha bajarish (kun)", f"{avg_completion_days:.1f}" if avg_completion_days is not None else "—"),
    ]

    departments = (await session.execute(select(Department).order_by(Department.name))).scalars().all()
    user_ids = {t.primary_responsible_id for t in tasks if t.primary_responsible_id}
    users_by_id: dict[int, User] = {}
    if user_ids:
        rows = (await session.execute(select(User).where(User.id.in_(user_ids)))).scalars().all()
        users_by_id = {u.id: u for u in rows}
    dept_by_id = {d.id: d for d in departments}

    rows = []
    for t in sorted(tasks, key=lambda x: (x.deadline or dt.date.max)):
        rows.append(
            {
                "task": t,
                "department_name": dept_by_id.get(t.department_id).name if t.department_id in dept_by_id else "—",
                "responsible_name": users_by_id.get(t.primary_responsible_id).full_name
                if t.primary_responsible_id in users_by_id else "—",
                "is_overdue": t.status == TaskStatus.OVERDUE,
            }
        )

    return templates.TemplateResponse(
        request,
        "dashboard.html",
        {
            "user": user,
            "kpis": kpis,
            "rows": rows,
            "departments": departments,
            "statuses": list(TaskStatus),
            "priorities": list(Priority),
            "selected_department": department_id,
            "selected_status": status_filter,
            "selected_priority": priority_filter,
        },
    )


@app.get("/dashboard/export.xlsx")
async def export_xlsx(
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_db_session),
):
    actor = Actor.from_user(user)
    if not can_view_dashboard(actor):
        return RedirectResponse(url="/login", status_code=303)

    wb = await build_register_workbook(session)
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=task_register_export.xlsx"},
    )

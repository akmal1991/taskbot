# Running this imported project

This is the original Python 3.13 / aiogram / FastAPI application. Keep its
structure and stack. PostgreSQL stores application data; Redis is optional.
With `REDIS_URL` unset, unfinished Telegram wizards reset on process restart,
but saved users and tasks remain in PostgreSQL.

## Development

- Click **Run** to start the `Start application` workflow: `python3 main.py`.
- The entrypoint applies the existing Alembic migrations to the development
  database, then starts Telegram polling, scheduled jobs, and the dashboard.
- The dashboard binds to `0.0.0.0:5000`.
- Runtime dependencies are pinned in `requirements.txt`; test-only dependencies
  are in `requirements-dev.txt`. Python packages are installed in `.pythonlibs`
  using `PIP_TARGET` / `PYTHONPATH`, not a virtual environment.

## Configuration

- `DATABASE_URL` is supplied by Replit's PostgreSQL database.
- `BOT_TOKEN` must be saved in Secrets using a real token from @BotFather.
- Dashboard cookie signing uses `WEB_SECRET_KEY` if supplied, otherwise the
  existing Replit `SESSION_SECRET`. Never use the development placeholder for
  a shared instance.
- `BOOTSTRAP_SUPER_ADMIN_TELEGRAM_ID` must be the first administrator's numeric
  Telegram user ID, not a username. The bot's `/myid` command shows the sender's
  own ID. On first `/start`, that account is approved as Super Admin.
- In development, login links use `REPLIT_DEV_DOMAIN` automatically unless
  `WEB_BASE_URL` is explicitly set.
- Send `/start` to the bot to register, then `/weblogin` to obtain the one-time
  dashboard login link. The dashboard is intentionally not publicly accessible.

## Verification and data safety

Run `python3 -m pytest -q`. Each database test creates its own random schema,
uses only that schema in its search path, and drops only that schema afterward.
Application tables in `public` are never truncated. The database account needs
permission to create schemas. Test signing keys are isolated from deployment
credentials, and Telegram delivery tests never contact the external API.
Do not bypass dashboard authentication to test UI.

## Before publishing

Publishing is separate from running the development preview. Use a continuously
running process for Telegram long polling and scheduled jobs. Obtain the actual
published URL and set `WEB_BASE_URL` to it. Do not guess a production URL.
For Replit-managed production PostgreSQL, publishing applies the development
schema; `main.py` skips startup migrations when `REPLIT_DEPLOYMENT=1`, rather
than applying production DDL at application startup.
Run only one polling instance per bot token; development and production need
different tokens if both are running at once.

See `docs/AUDIT_RESULTS.md` for audit scope, verification results, and limits.

"""Combined entrypoint for single-process hosts (Replit, or any platform
that only runs one "start" command rather than several containers/services).

Runs Alembic migrations, then the Telegram bot + scheduler and the FastAPI
web dashboard together in one asyncio event loop. For a multi-process host
(Docker Compose, systemd on a VPS) use `python -m app.bot.main` and
`uvicorn app.web.main:app` as two separate processes instead — either way
runs the exact same application code.
"""
from __future__ import annotations

import asyncio
import logging
import os
import subprocess
import sys

import uvicorn
from aiogram import Bot
from aiogram.client.default import DefaultBotProperties
from aiogram.utils.token import TokenValidationError, validate_token

from app.bot.main import build_dispatcher
from app.core.config import get_settings
from app.core.db import dispose_engine
from app.scheduler.runner import build_scheduler
from app.web.main import app as web_app

logger = logging.getLogger(__name__)


def _run_migrations() -> None:
    """Apply any pending Alembic migrations before anything starts serving
    traffic. Runs as a plain subprocess (not an in-process Alembic call) so
    its own logging/exit-code behaviour stays exactly what `alembic upgrade
    head` gives you on the command line."""
    logger.info("Applying database migrations...")
    result = subprocess.run([sys.executable, "-m", "alembic", "upgrade", "head"], capture_output=True, text=True)
    if result.returncode != 0:
        logger.error("Migration failed:\n%s", result.stdout + result.stderr)
        raise SystemExit(1)
    logger.info("Migrations applied.\n%s", result.stdout.strip())


async def _run_bot() -> None:
    settings_ = get_settings()
    bot = Bot(token=settings_.bot_token, default=DefaultBotProperties(parse_mode=settings_.bot_parse_mode))
    dp = build_dispatcher()

    scheduler = build_scheduler(bot)
    scheduler.start()
    logger.info("Scheduler started with jobs: %s", [j.id for j in scheduler.get_jobs()])

    try:
        await dp.start_polling(bot)
    finally:
        scheduler.shutdown(wait=False)
        await bot.session.close()


async def _run_web() -> None:
    settings_ = get_settings()
    config = uvicorn.Config(
        web_app, host=settings_.web_host, port=settings_.web_port, log_level="info",
        # Login links contain bearer credentials; never put query strings in logs.
        access_log=False,
    )
    server = uvicorn.Server(config)
    await server.serve()


async def _main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    settings_ = get_settings()

    if not settings_.bot_token:
        logger.error(
            "BOT_TOKEN is not set. On Replit: add it under Tools -> Secrets "
            "as BOT_TOKEN, using the token @BotFather gave you, then rerun."
        )
        raise SystemExit(1)
    try:
        validate_token(settings_.bot_token)
    except TokenValidationError:
        logger.error("BOT_TOKEN has an invalid format. Replace it securely with the complete @BotFather token.")
        raise SystemExit(1) from None
    if len(settings_.web_secret_key) < 32 or settings_.web_secret_key.startswith("CHANGE_ME"):
        logger.error("Set SESSION_SECRET or WEB_SECRET_KEY to a strong secret of at least 32 characters.")
        raise SystemExit(1)

    # Run bot polling and the web dashboard concurrently in this one
    # process. If either crashes, bring the whole process down rather than
    # silently running half a system — the host's restart policy (Replit's
    # "Always On"/Deployments, or systemd's Restart=on-failure) brings it
    # back up.
    workers = [asyncio.create_task(_run_bot()), asyncio.create_task(_run_web())]
    try:
        done, _ = await asyncio.wait(workers, return_when=asyncio.FIRST_COMPLETED)
        for worker in done:
            worker.result()
    finally:
        for worker in workers:
            if not worker.done():
                worker.cancel()
        await asyncio.gather(*workers, return_exceptions=True)
        await dispose_engine()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    # Replit publishes the managed production schema separately. Keep the
    # imported migration step for local/development hosts, not published apps.
    if os.environ.get("REPLIT_DEPLOYMENT") != "1":
        _run_migrations()
    asyncio.run(_main())

---
name: Runtime and scan consistency
description: Avoid acting on dependency versions that differ from the application's actual interpreter.
---

Verify dependency scan package versions against the active Python interpreter
and imported package metadata before selecting upgrades.

**Why:** During the imported-project audit, the scanner initially reported
older package versions than those actually loaded by the application.
Treating every initial finding as a runtime defect would have led to
unnecessary or incompatible dependency changes.

**How to apply:** When findings and installed requirements disagree, check
the active interpreter and `importlib.metadata` versions, validate the
resolved dependency constraints, and rerun the scan after deliberate changes.
Do not dismiss findings solely because versions differ.

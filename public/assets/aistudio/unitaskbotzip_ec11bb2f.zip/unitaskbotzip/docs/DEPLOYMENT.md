# Deployment Guide

## External services / paid infrastructure required

This system was deliberately kept to infrastructure a university IT
department can run itself, with no mandatory paid third-party API:

| Need | Options | Cost |
|---|---|---|
| Telegram Bot API | A bot token from `@BotFather` | Free |
| Somewhere to run the process 24/7 | A Linux VM/VPS (Docker or native, see `docs/VPS_SETUP_NO_DOCKER.md`), or [Replit](https://replit.com) (see `docs/REPLIT_SETUP.md`) via its Reserved VM Deployments. Outbound HTTPS is all that's needed for Telegram's webhook-free long polling — no inbound port required for the bot itself. | A small VPS (~$5–6/mo) or Replit's Deployments pricing |
| PostgreSQL | Self-hosted via the included `db` container, or any managed Postgres (e.g. a cloud provider's managed DB) if preferred | Free if self-hosted; managed DB pricing otherwise |
| Redis | Self-hosted via the included `redis` container, or a managed Redis | Free if self-hosted |
| A domain + TLS certificate | Only needed if you want the web dashboard reachable at a real URL (`WEB_BASE_URL`) rather than accessed over a VPN/internal network | Domain registration + a free TLS cert (e.g. Let's Encrypt) is the typical path |

Nothing in this system calls OpenAI, a paid SMS gateway, or any other
metered external API. The only recurring cost beyond what the university
already has is hosting, if it doesn't already have a server to put this on.

## Pre-flight checklist

1. **Get a real bot token** from `@BotFather` on Telegram. Put it in
   `.env` as `BOT_TOKEN` — the placeholder value in `.env.example` will not
   work.
2. **Pick a strong `POSTGRES_PASSWORD` and `WEB_SECRET_KEY`.** Generate the
   latter with `python -c "import secrets; print(secrets.token_urlsafe(48))"`.
3. **Set `WEB_BASE_URL`** to wherever the dashboard will actually be
   reachable (e.g. `https://tasks.yourdomain.edu`, or
   `http://10.0.0.5:8080` on an internal network). This is what
   `/weblogin` links point to — get it right before anyone relies on it.
4. **Get your own numeric Telegram user ID** and set
   `BOOTSTRAP_SUPER_ADMIN_TELEGRAM_ID` so you aren't locked out on first
   run (see `docs/ADMIN_MANUAL.md` §1).
5. **Decide department names up front** — see `docs/ADMIN_MANUAL.md` §3
   for how to seed them.

## Running it

```bash
docker compose up -d --build
docker compose logs -f migrate   # should exit 0 after applying migrations
docker compose logs -f bot       # should show "Scheduler started with jobs: [...]"
                                  # and aiogram's polling start — no exceptions
```

Then, from Telegram, send `/start` to your bot from the
`BOOTSTRAP_SUPER_ADMIN_TELEGRAM_ID` account and confirm you're auto-approved.

If the web dashboard is wanted:

```bash
curl -I http://localhost:${WEB_PORT:-8080}/login   # should return 200
```

and then `/weblogin` from Telegram once you have an account, to confirm the
full login round trip against your real deployment.

## What was and wasn't verified in this project's own development environment

Everything in the service layer — task lifecycle, RBAC, escalation
timing/recipients, notification dedup, Excel import/export round-tripping,
and the web dashboard's auth flow and KPI rendering — was developed and
tested against a **real** PostgreSQL 16 and Redis 7 instance (21 automated
tests, `pytest -q`, no mocks). The aiogram `Dispatcher` was confirmed to
build with every router registered in the correct order, and the
APScheduler `AsyncIOScheduler` was confirmed to build with all three jobs.

Two things could **not** be exercised in the sandbox this project was
built in, and should be your first checks on a real deployment:

1. **No real Telegram bot token was available during development** (per
   explicit instruction to deliver code + instructions rather than a live
   deployment from that environment), so no message was ever actually sent
   to or received from the real Telegram Bot API. The bot logic itself —
   what each handler does once a message arrives — is the same logic the
   automated tests exercise directly; what's unverified is specifically the
   aiogram ⇄ Telegram network link. Confirm `/start` works end-to-end as
   your very first step after deployment.
2. **Docker Compose was not built/run end-to-end in that sandbox**: its
   network policy blocks pulling base images from Docker Hub
   (`registry-1.docker.io` returned a policy 403). `docker compose config`
   validated the compose file's syntax, and the application underneath
   it is the same code the test suite runs — but the containers themselves
   were never started together there. On a normal host with internet
   access to Docker Hub, `docker compose up -d --build` should work as
   written; treat the checklist above as the actual first-run
   verification, and if anything in the container wiring needs
   adjustment, it will show up immediately in `docker compose logs`.

## Updating a running deployment

```bash
git pull   # or however you receive updates to this codebase
docker compose up -d --build   # rebuilds images; `migrate` reapplies only new migrations
```

Alembic migrations are additive and idempotent (`alembic upgrade head`
only applies what hasn't been applied yet), so this is safe to run
repeatedly.

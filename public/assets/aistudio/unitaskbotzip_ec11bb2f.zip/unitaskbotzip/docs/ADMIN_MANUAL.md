# Administrator Manual

## 1. First run: becoming the first Super Administrator

1. Get your own numeric Telegram user ID (not your `@username`) — forward
   any message to `@userinfobot`, or check `@RawDataBot`.
2. Set `BOOTSTRAP_SUPER_ADMIN_TELEGRAM_ID=<your numeric ID>` in `.env`
   before first starting the bot.
3. Send `/start` to the bot from that Telegram account. You are
   auto-approved as the first Super Administrator — no registration
   request, no waiting.
4. Anyone else who sends `/start` instead goes through the normal
   registration flow (full name → phone → department → requested role)
   and lands in your **Foydalanuvchilarni boshqarish / User Management**
   queue as a pending request.

You can leave `BOOTSTRAP_SUPER_ADMIN_TELEGRAM_ID` set after this — the
check only fires if no `User` row exists yet for that Telegram ID, so it
is a no-op on every subsequent `/start` from that account.

## 2. Approving registrations

Main menu → **Foydalanuvchilarni boshqarish** (Super Administrator only)
lists every pending `RegistrationRequest` with inline **Approve**/**Reject**
buttons. Approving creates the `User` row with the role and department the
person requested; you can change either afterward (see below). Rejecting
asks for a short reason, which is stored and shown to the person.

There is currently no in-bot "change a user's role" menu button — that is
done via `app.services.users.set_user_role()` / `set_user_active()`,
callable from a Python shell inside the running container:

```bash
docker compose exec bot python - <<'PY'
import asyncio
from app.core.db import session_scope
from app.services import users as user_service
from app.services.permissions import Actor
from app.models.enums import UserRole

async def main():
    async with session_scope() as session:
        admin = await user_service.get_user_by_telegram_id(session, YOUR_TELEGRAM_ID)
        target = await user_service.get_user_by_telegram_id(session, TARGET_TELEGRAM_ID)
        await user_service.set_user_role(
            session, actor=Actor.from_user(admin), user_id=target.id, new_role=UserRole.VICE_RECTOR
        )

asyncio.run(main())
PY
```

(Promoting this to a proper admin menu button is a natural next increment
if the university wants it — the service function and its RBAC/audit
logging already exist and are tested.)

## 3. Departments

Departments are created the same way today — via `app.services.departments`
functions — since the spec's acceptance criteria focus on task workflow and
did not ask for a dedicated department-management bot menu. Every task
creation and registration flow already lists existing departments by
number, so set these up once, early:

```bash
docker compose exec bot python - <<'PY'
import asyncio
from app.core.db import session_scope
from app.services import departments as dept_service, users as user_service
from app.services.permissions import Actor

async def main():
    async with session_scope() as session:
        admin = await user_service.get_user_by_telegram_id(session, YOUR_TELEGRAM_ID)
        actor = Actor.from_user(admin)
        await dept_service.create_department(session, actor=actor, name="O'quv ishlari bo'limi")
        await dept_service.create_department(session, actor=actor, name="Moliya bo'limi")
        # ... one call per department

asyncio.run(main())
PY
```

Set a department's head (needed for level-1 escalation to have a
recipient) with `dept_service.set_department_head(session, actor=actor,
department_id=..., head_user_id=...)`.

## 4. Configuring escalation & reminder timing

All in `.env`, read once at process start (restart the `bot` container
after changing them):

| Variable | Default | Meaning |
|---|---|---|
| `ESCALATION_DEPT_HEAD_DAYS` | 1 | Days overdue before the department head is notified |
| `ESCALATION_VICE_RECTOR_DAYS` | 3 | Days overdue before all Vice-Rectors are notified |
| `ESCALATION_RECTOR_DAYS` | 7 | Days overdue before all Rectors/Executive Directors are notified |
| `REMINDER_DAYS_BEFORE` | `[7,3,1]` | Days before deadline to send a pre-deadline reminder |
| `OVERDUE_REMINDER_INTERVAL_HOURS` | 24 | How often an overdue task's responsible employee is re-reminded |

## 5. Excel import/export

- **Export**: any role that can see the dashboard (`/weblogin`-eligible
  roles) gets a full register download as an `.xlsx` from the bot's
  **Hisobotlar** menu, or from the web dashboard's "Excel yuklab olish"
  button. Both call the same `app/excel_io/export.py:build_register_workbook`.
- **Import** (active Super Administrator only): `app/excel_io/import_.py:import_register(session, actor=...,
  file_path=...)` reads a workbook in the same column layout the export
  produces (see `app/excel_io/columns.py`), matches existing tasks by
  `Public Code` when present (updates them, recording a `TaskHistory`
  entry on any status change) and creates new ones otherwise. Missing
  departments are auto-created; a name that matches more than one
  registered user is left unresolved rather than guessed, and is reported
  as a warning rather than silently assigned to the wrong person. One bad
  row never rolls back previously-imported rows in the same file (each row
  is its own database savepoint) — see `tests/test_excel_io.py` for the
  exact behavior this is tested against, including a full export → edit →
  re-import round trip that preserves the task's Public Code.
- The university's 92-row legacy register was **not** auto-imported as seed
  data into this system, per the explicit choice made during requirements
  gathering (the import feature itself is built and tested; running it
  against that specific file is a one-time action for whoever stands the
  system up — run the import once against that file through the handler
  above, review the `ImportReport.warnings`/`errors` it returns, and fix
  any ambiguous name matches by hand before relying on the result).

## 6. Monitoring the system itself

- `docker compose logs -f bot` / `web` / `migrate` — application logs.
- Scheduler jobs and their cadence are listed in `app/scheduler/runner.py`:
  overdue sweep + escalation hourly, reminders daily at 08:00
  `Asia/Tashkent`, notification-queue flush every 2 minutes. A stuck/slow
  job logs rather than silently disappearing (`max_instances=1,
  coalesce=True` on every job prevents pile-ups if one run takes too long).
- `AuditLog` rows (queryable directly in Postgres, or via a small script
  using `app.models.audit.AuditLog`) record who did what, when, to which
  entity — the durable record for "who changed this and why" questions.

# Architecture

## Overview

```
                      ┌─────────────────┐
   Telegram  <──────▶ │   aiogram bot   │──┐
    users             │  (polling)      │  │
                      └─────────────────┘  │
                               │            │  shared
                               ▼            │  AsyncSession
                      ┌─────────────────┐   │  per request/update
                      │ services layer  │◀──┘
                      │ (RBAC, lifecycle│
                      │ escalation,     │
                      │ notifications)  │
                      └────────┬────────┘
                               │
                 ┌─────────────┼──────────────┐
                 ▼             ▼              ▼
          ┌───────────┐ ┌───────────┐  ┌─────────────┐
          │ PostgreSQL│ │  Redis    │  │ APScheduler │
          │  (source  │ │ (FSM      │  │ (reminders, │
          │  of truth)│ │  storage) │  │ escalation, │
          └───────────┘ └───────────┘  │ notif flush)│
                 ▲                      └─────────────┘
                 │
          ┌──────┴──────┐        ┌──────────────┐
          │ FastAPI web │◀──────▶│ browser      │
          │ dashboard   │        │ (read-only)  │
          └─────────────┘        └──────────────┘
```

The bot, the scheduler, and the web dashboard are three processes (three
Docker containers) that all talk to the same Postgres database through the
same `app/services/*` functions — there is exactly one place the task
lifecycle rules, RBAC checks, and escalation logic live, so the bot and the
dashboard can never disagree about what's allowed.

## Why PostgreSQL, not Excel

The original 92-row Excel register (ToshTech's existing work plan) is a
point-in-time snapshot someone edits by hand: no concurrency control, no
audit trail, no enforced workflow (anyone could type "Bajarildi" in a
status cell without any evidence or approval). The spec explicitly asks for
a database-driven system with Excel as import/export only, which is what
this project builds: `app/excel_io/import_.py` and `export.py` let you
bring the old register in and generate fresh register exports for
meetings, but PostgreSQL — not any `.xlsx` file — is what the application
reads and writes during normal operation.

## Task lifecycle (state machine)

```
CREATED ──▶ ASSIGNED ──▶ ACKNOWLEDGED ──▶ IN_PROGRESS ──▶ SUBMITTED_FOR_REVIEW ──▶ COMPLETED
               │              │                │                   │
               │              │                ▼                   ▼
               │              │          PENDING_BLOCKED      RETURNED_FOR_REVISION
               │              │                │                   │
               └──────────────┴────────────────┴───────────────────┘
                                     (any of these) ──▶ CANCELLED

OVERDUE is layered on top of ASSIGNED/ACKNOWLEDGED/IN_PROGRESS/
PENDING_BLOCKED/RETURNED_FOR_REVISION once the deadline passes. It is set
only by the scheduler (never by a person) and is automatically cleared the
moment the task moves again (progress logged, deadline extended, etc.) —
a COMPLETED or CANCELLED task is never, ever flagged OVERDUE.
```

The full transition table is `ALLOWED_TRANSITIONS` in
`app/models/enums.py` — it is the single source of truth, enforced in
`app/services/tasks.py`'s `_transition()` helper. Every manual status
change in the bot and every status change implied by an API call goes
through it; there is no code path that writes `task.status` directly.

**A task can never reach COMPLETED by progress percentage alone.** Setting
progress to 100% moves a task to `IN_PROGRESS` at most — reaching
`COMPLETED` requires `submit_for_review()` (by the responsible employee)
followed by `approve_task()` (by the approver, see below), which is a
separate, explicit step. This is enforced in code and covered by
`tests/test_task_lifecycle.py::test_cannot_complete_by_progress_percent_alone`.

## Approval chain

Per the university's decision (recorded during requirements gathering): the
sole approver for a task is **the person who assigned it** —
`Task.assigned_by_id`. There is no separate "approver" role to configure.
`can_approve_or_return()` in `app/services/permissions.py` additionally
hard-blocks self-approval regardless of role: an employee can never approve
their own task even if they are, by some data error, also recorded as its
assigner.

## Escalation chain

Per the university's decision:

| Days overdue | Who is notified               |
|--------------|--------------------------------|
| 1 day        | the task's department head     |
| 3 days       | all active Vice-Rectors        |
| 7 days       | all active Rectors / Executive Directors |

Each level fires exactly once per task (`EscalationEvent` has a unique
constraint on `(task_id, level)`), so re-running the hourly sweep never
sends a duplicate escalation. Configurable via `ESCALATION_DEPT_HEAD_DAYS`
/ `ESCALATION_VICE_RECTOR_DAYS` / `ESCALATION_RECTOR_DAYS` in `.env`.

## Notifications & reminders

`app/services/notifications.py` enqueues rows into a `notifications` table
with a unique `dedup_key` (e.g. `reminder:{task_id}:days_before:3`) so the
same reminder is never sent twice even if the scheduler job runs more than
once in close succession. `app/bot/notifier.py`'s `flush_notification_queue`
drains that queue over the Telegram API every 2 minutes, handling rate
limits (`TelegramRetryAfter` — left queued for the next pass) and blocked
bots (`TelegramForbiddenError` — marked failed, logged) without crashing the
scheduler loop.

Default reminder schedule (configurable via `REMINDER_DAYS_BEFORE`):
7/3/1 days before deadline, on the deadline date, and then daily while
overdue. A separate "missing progress" reminder fires for tasks still at
0% a configurable number of days after assignment.

## RBAC

`app/services/permissions.py` is a set of pure functions — `can_create_task`,
`can_view_task`, `can_approve_or_return`, etc. — that take an `Actor`
(id, role, department, active flag) and return a plain `bool`, with no
database access of their own. That makes every rule unit-testable in
isolation and keeps "is this allowed?" answerable the same way whether the
caller is a bot handler or the web dashboard.

Roles (highest to lowest rank): **Super Administrator**, **Rector /
Executive Director**, **Vice-Rector**, **Department Head**, **Employee**
(Responsible Employee), **Observer/Auditor** (read-only).

## Identity & registration

Telegram `username` is never used as an identity key — it can change or be
unset. `User.telegram_id` (the numeric Telegram user ID) is the only
identity key, and the only way to get a `User` row is through
`RegistrationRequest` → Super Administrator approval (`app/services/users.py`).
There is one bootstrap exception: the Telegram ID in
`BOOTSTRAP_SUPER_ADMIN_TELEGRAM_ID` is auto-approved as the very first Super
Administrator on first `/start`, so the system is never stuck with nobody
able to approve anybody else. That variable should be cleared (or left set
harmlessly, since it only fires once — the check also looks up whether that
user already exists) once the first admin is confirmed.

## Redis is optional

`REDIS_URL` backs aiogram's FSM storage (in-progress registration/task
wizards), and nothing else — not the scheduler, not notifications, not the
database. If it's left unset, `app/bot/main.py` falls back to an in-memory
store automatically. On a single always-on process (Replit, a small VPS)
that's a fine trade-off: a wizard a user is mid-way through resets if the
process restarts, but nothing ever gets written to Postgres until a wizard
actually completes, so there is no data-loss exposure either way. Set
`REDIS_URL` when you have Redis available and want wizard state to survive
restarts; otherwise just leave it blank.

## Web dashboard authentication

There is no username/password system for the dashboard. A user who already
has a Telegram-verified account sends `/weblogin` to the bot; the bot issues
a single-use, 10-minute `WebLoginToken` (`app/services/web_auth.py`) and
sends a link built from `WEB_BASE_URL`. Visiting that link exchanges the
token for a signed, `itsdangerous`-based session cookie good for 12 hours
(`app/web/auth.py`). The dashboard itself is gated by the same
`can_view_dashboard()` rule the bot's `/weblogin` command and Excel-export
button use — Super Admin, Rector, Observer, Vice-Rector, and Department Head.

## Audit trail

`app/services/audit.py`'s `log_action()` is called from essentially every
mutating service function (registration approval, role changes, task
transitions, reassignment, deadline changes, etc.), writing an immutable
`AuditLog` row with actor, action, entity type/id, and a JSON detail blob.
`TaskHistory` additionally records the full before/after status trail for
every task, independent of `AuditLog`, so a task's own history is visible
without cross-referencing the audit log.

## Database schema

13 tables (see `migrations/versions/3efeda83a32a_initial_schema.py` for the
authoritative definition): `departments`, `users`, `registration_requests`,
`tasks`, `task_assignees`, `task_history`, `task_comments`,
`task_attachments`, `deadline_extension_requests`, `notifications`,
`escalation_events`, `audit_logs`, plus `web_login_tokens` (added in the
second migration for dashboard auth). `departments.head_user_id` and
`users.department_id` are mutually dependent FKs; the migration creates
`users` first and adds the `departments → users` FK afterward via a
separate `op.create_foreign_key` call to avoid the circular-dependency
chicken-and-egg problem at table-creation time.

## Known simplifications (and why)

- **No department-scoped dashboard filtering by role yet.** The dashboard
  currently shows the same cross-department register to everyone who passes
  `can_view_dashboard()` (Vice-Rector and Department Head included). The
  spec didn't ask for role-scoped dashboard rows explicitly, and the
  university didn't raise it during requirements gathering; the `rows`
  computation in `app/web/main.py` is already filterable by department, so
  scoping a Department Head to only their own department is a small,
  contained change if wanted later.
- **No real Telegram bot token was available during development**, per the
  university's explicit choice to receive code + instructions rather than a
  live deployment from this environment. Every service-layer and lifecycle
  test runs against a real Postgres database with no mocking; the aiogram
  `Dispatcher` and APScheduler `AsyncIOScheduler` were verified to build
  correctly with all routers/jobs registered, but no live message was ever
  sent to a real Telegram chat from this environment. See
  `docs/DEPLOYMENT.md` for exactly what to check on first real run.

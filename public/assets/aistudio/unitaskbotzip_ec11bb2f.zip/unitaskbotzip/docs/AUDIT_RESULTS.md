# Audit and repair results

## Scope and fixes

Reviewed the Python bot, FastAPI dashboard, database models/migrations,
permission rules, task lifecycle, scheduled work, notification delivery,
Excel import/export, configuration, dependencies, and tests. The existing
stack, dashboard design, and documented global manager-dashboard visibility
were retained.

- Corrected PostgreSQL async driver/TLS URL handling and Replit configuration.
- Isolated database tests in temporary schemas instead of truncating live
  application tables.
- Made one-time login redemption atomic; rejected inactive accounts and
  malformed sessions; enforced strong signing keys and secure HTTPS cookies.
- Prevented group-chat disclosures and unauthorized department-task listing.
  Inactive accounts and observers can no longer bypass mutation restrictions.
- Added safe HTML rendering and plain-text Telegram notifications.
- Fixed notification deduplication without rolling back unrelated work,
  permanent-failure retries, rate-limit timing, and transient-error backoff.
  Assignment, review, approval, return, and reassignment now queue notifications.
- Serialized task-code allocation and task mutations to prevent concurrency
  collisions and duplicate approvals. Protected the final active administrator.
- Fixed rejected-registration resubmission and extension-review partial writes.
- Fixed Excel status updates in fresh sessions, code collisions across files,
  subset-column imports, row-result counts, and failed-row cache handling.
  Exports preserve user input as literal cells, never executable formulas.
- Fixed blank department filters, task-list pagination, explicit evidence
  attachment selection, form cancellation, non-text form input, and missing
  task-card actions.
- Corrected local-calendar calculations and scheduler timezone, custom reminder
  windows, overdue intervals, and reminders after deadline/assignee changes.
- Pinned security-sensitive dependencies; disabled bearer-link access logging.
  Published Replit apps no longer run schema migrations at startup.

## Verified locally

```text
Python: 3.13.11
python3 -m compileall -q app tests main.py: passed
python3 -m pytest -q: 98 passed
Direct requirements + installed dependency metadata: 0 conflicts
Dependency security scan: 0 critical, high, moderate, low, or informational findings
```

The suite covers registration/approval, role restrictions, task creation,
assignment, progress, blocking, review/return/approval, deadline extensions,
reminders/escalation, notifications, database-backed dashboard login/rendering,
Excel round trips, formula safety, and concurrent login/code/approval operations.
Telegram delivery tests simulate API success, permanent failures, rate limits,
and transient network failures; they send no real messages.

The static scanner reported four template-response warnings. These were
reviewed against Jinja autoescaping and a passing HTML-injection regression
test; no raw HTML bypass was introduced. The privacy scanner could not produce
a result because of a scanner schema error, so this is not a claim that every
automated scanner completed successfully.

## Live verification and remaining setup

The combined application is running: development migrations succeeded,
Telegram authenticated the bot and began long polling, the scheduler started
all four jobs, and the dashboard bound to port 5000. The proxied login page
returns HTTP 200; the favicon returns 204. The login-page screenshot was
verified with no browser-console errors.

The administrator's numeric bootstrap ID has been configured. The owner
should now send `/start` in the bot's private chat, followed by `/weblogin`.
The suite verifies that only the configured account can bootstrap as an
administrator. A real user's complete task-management conversation was not
performed by the automated audit.

The saved secret contained a full BotFather reply rather than just its token.
The loader now accepts that known message format only when it contains exactly
one token, without displaying or changing the stored secret. Raw token-only
values are still preferred. The token posted in chat must remain revoked;
rotation itself cannot be independently verified by the application.

No production database changes or publishing were performed. No authentication
bypass was added. Database-backed authenticated pages were tested through the
ASGI test client; an authenticated browser session was not visually verified.

## Run

1. Keep the newly rotated `BOT_TOKEN` in Secrets. Keep `SESSION_SECRET` (or set a
   strong `WEB_SECRET_KEY`); never use the development placeholder.
2. Click **Run**, or execute `python3 main.py`. Development migrations run first,
   followed by bot polling, the scheduler, and the dashboard on port 5000.
3. The first administrator's ID is already configured in this workspace.
   Send `/start` to bootstrap that account. For a new installation, use `/myid`
   to obtain the ID, configure `BOOTSTRAP_SUPER_ADMIN_TELEGRAM_ID`, and restart.
4. Use `/weblogin` in the bot's private chat to get a short-lived, single-use
   dashboard link. Other users register with `/start` and require admin approval.
5. Run only one polling instance for each token. Do not run development and
   production concurrently with the same token.

For a clean installation, run `pip install -r requirements.txt`; for tests add
`pip install -r requirements-dev.txt`. PostgreSQL and schema-creation permission
are required for integration tests. On Replit, `DATABASE_URL` is already managed
and package installation uses the configured `.pythonlibs` target.

# Running on Replit

This project is set up to run on Replit as a **single process**: the
`.replit` file and `main.py` (repo root) start the Telegram bot, its
scheduler, and the web dashboard together in one program, since a Repl
only runs one "start" command. Redis is not required — FSM state
(in-progress registration/task wizards) falls back to in-memory storage
automatically, which is the right trade-off for a single always-on
process (see the comment in `.env.example` / `app/core/config.py` for why
that's safe).

## 1. Create the Repl

- On replit.com: **Create App/Repl** → **Import from a local folder/zip**
  (or **Upload files**) → upload everything from the extracted project
  (not the `.venv` folder — it isn't needed, Replit manages its own
  environment).
- Language: Python 3.13 (the `.replit` file already declares this).

## 2. Add a PostgreSQL database

Pick whichever of these your Replit plan offers:

**Option A — Replit's built-in Database tool** (if your account has it):
Tools → **Database** (sometimes called **PostgreSQL**) → create one. Copy
the `DATABASE_URL` it gives you — it'll look like
`postgresql://user:pass@host/dbname`. That's fine as-is: this app
auto-rewrites it to use the async driver it needs (see the comment in
`app/core/config.py` if you're curious why).

**Option B — a free external Postgres** (works regardless of plan):
create a free project at [neon.tech](https://neon.tech) or
[supabase.com](https://supabase.com), copy its connection string the same
way.

Either way, you end up with one `DATABASE_URL` value to paste into
Secrets below.

## 3. Set Secrets (Tools → Secrets, the padlock icon)

| Key | Value |
|---|---|
| `BOT_TOKEN` | Your real token from @BotFather |
| `DATABASE_URL` | The connection string from step 2 |
| `WEB_SECRET_KEY` | Optional when Replit's `SESSION_SECRET` exists; otherwise use a securely generated signing key of at least 32 characters |
| `WEB_BASE_URL` | Optional in development (the preview domain is detected); set the actual published URL before publishing |
| `BOOTSTRAP_SUPER_ADMIN_TELEGRAM_ID` | Your numeric Telegram ID; send `/myid` to this bot to see it |
| `BOT_PARSE_MODE` | `HTML` (optional, this is the default) |

Leave `REDIS_URL` unset — that's intentional, see the note above.

## 4. Run it

Dependencies are already installed in this workspace. In a clean import,
install them with `pip install -r requirements.txt`. Click **Run** to:
- apply database migrations (`alembic upgrade head`)
- start the bot (polling) + scheduler + web dashboard together

Watch the console for the scheduler's job list and aiogram starting to
poll, with no exceptions. Then send `/start` to your bot on Telegram and
confirm you're auto-approved as Super Administrator.

## 5. Keeping it running 24/7

A Repl you just click "Run" on **stops when you close the tab or the Repl
goes idle** — fine for testing, not for a bot people depend on daily.
For that, use **Replit Deployments** (the "Deploy" button in the Repl):

- Choose **Reserved VM** deployment (not Autoscale — Autoscale deployments
  spin down between requests, which would drop the bot's long-polling
  connection and your scheduler's background jobs).
- Publish. Use the exact published URL shown by Replit as the value
  for `WEB_BASE_URL`, so `/weblogin` links sent on Telegram point
  somewhere real. Update the Secret and redeploy if you set a placeholder
  first.
- Reserved VM deployments run continuously and are a paid feature on
  Replit (priced by vCPU/RAM/hours) — check current Replit pricing; it's
  usually inexpensive for a workload this light.

## Updating the code later

Edit files directly in the Replit editor (or re-upload changed files), then
click **Run** again (or **Redeploy** if you're using a Deployment) —
`main.py` applies Alembic migrations automatically in development. On Replit
published apps (`REPLIT_DEPLOYMENT=1`) it skips startup migrations; use the
managed database schema publishing flow instead of running production DDL
at application startup.

Only one polling instance may use a Telegram token at a time. Use separate
tokens if both development and production are running.

## Tests

Install test dependencies with `pip install -r requirements-dev.txt`, then run:

```sh
python3 -m compileall -q app tests main.py
python3 -m pytest -q
pip check
```

Database tests use isolated random schemas, not application tables. Telegram
delivery is simulated in local tests; live bot authentication must also be
checked with a valid, privately stored token. See `AUDIT_RESULTS.md`.

## If something doesn't start

- **"BOT_TOKEN is not set"** — you're missing the Secret, or it's in `.env`
  instead of Secrets (Replit Secrets are the right place; a `.env` file
  also works if you uploaded one, but Secrets are preferred so the token
  never ends up in a file you might accidentally share).
- **A database connection error** — double check `DATABASE_URL` was pasted
  exactly as your provider gave it, including the password.
- **The bot starts but `/weblogin` links don't work** — `WEB_BASE_URL` is
  probably still the placeholder; set it to your actual Replit URL (step 5)
  and restart.

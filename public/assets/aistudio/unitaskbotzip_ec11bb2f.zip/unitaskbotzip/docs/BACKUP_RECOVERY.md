# Backup & Recovery

PostgreSQL is the only state that matters for recovery — Redis holds only
transient FSM state (in-progress bot conversations) and the scheduler's
own coordination, both safely reconstructible from nothing if lost.

## Backup

With the Docker Compose setup, back up the `db` container's database with
`pg_dump`, run from the host (or from a sidecar with network access to the
`db` service):

```bash
docker compose exec -T db pg_dump -U "${POSTGRES_USER:-uni_task_bot}" "${POSTGRES_DB:-uni_task_bot}" \
  | gzip > "backup_$(date +%Y%m%d_%H%M%S).sql.gz"
```

Run this on a schedule (cron, or your platform's scheduled-job equivalent)
— daily at minimum, and before every deployment that includes a database
migration. Keep backups somewhere other than the same host (off-site or a
separate storage volume) — a backup that lives next to the database it
protects does not survive a disk failure.

A reasonable retention policy for a university task-tracking system:
daily backups kept for 30 days, weekly backups kept for a year. Adjust to
your institution's actual document-retention policy — `AuditLog` and
`TaskHistory` rows are themselves part of what a retention policy should
account for, since they are the system's record of who approved what and
when.

## Restore

**Tested procedure.** The dump → drop → recreate → restore sequence below
was verified directly against this project's real Postgres instance (not
simulated): `pg_dump` the test database, gzip it, create a scratch
database, restore into it, and confirm both the table list (all 14 tables)
and `alembic_version` came back correct. That verification used `psql`/
`pg_dump` directly against the local Postgres server rather than through
`docker compose exec`, because Docker itself could not be run in this
project's development sandbox (see `docs/DEPLOYMENT.md`) — the SQL-level
restore mechanics are identical either way; only the wrapping command
changes. Run it for real:

```bash
# 1. Stop the app containers so nothing writes while you restore (db/redis can stay up)
docker compose stop bot web

# 2. Drop and recreate the target database (adjust name if restoring to a fresh instance)
docker compose exec -T db psql -U "${POSTGRES_USER:-uni_task_bot}" -d postgres \
  -c "DROP DATABASE IF EXISTS ${POSTGRES_DB:-uni_task_bot};"
docker compose exec -T db psql -U "${POSTGRES_USER:-uni_task_bot}" -d postgres \
  -c "CREATE DATABASE ${POSTGRES_DB:-uni_task_bot} OWNER ${POSTGRES_USER:-uni_task_bot};"

# 3. Restore from the gzipped dump
gunzip -c backup_20260101_020000.sql.gz | docker compose exec -T db \
  psql -U "${POSTGRES_USER:-uni_task_bot}" -d "${POSTGRES_DB:-uni_task_bot}"

# 4. Bring the app back up — migrate runs automatically and should report
#    "no new migrations" if the backup was already on the current schema
#    version, or apply only what's missing if it predates a later change
docker compose up -d migrate bot web
docker compose logs -f migrate
```

**Verification after restore** — don't consider a restore successful until
you've confirmed:

- `docker compose exec db psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "SELECT count(*) FROM tasks;"`
  returns the expected row count (compare against what you expected at
  backup time).
- The bot responds normally to `/mytasks` from a known test account and
  shows the tasks you expect.
- `alembic_version` (`SELECT * FROM alembic_version;`) matches the latest
  revision in `migrations/versions/` — if it's behind, `docker compose up
  migrate` will bring it forward; if this check fails after that, stop and
  investigate before letting the bot resume taking writes.

## Point-in-time recovery (optional, for larger deployments)

A nightly `pg_dump` only protects you up to the last backup. If losing up
to a day of task updates is unacceptable, enable PostgreSQL's WAL archiving
(`archive_mode = on` + `archive_command`, or a managed Postgres provider's
built-in point-in-time-recovery feature) so you can restore to any moment,
not just the last nightly snapshot. This is a Postgres-operations concern
independent of this application's code, and is the right upgrade path if
the university's risk tolerance calls for it.

## What is NOT backed up by this procedure, and why that's fine

- **Redis** (FSM state, scheduler coordination): intentionally not backed
  up. Losing it mid-conversation means a user's in-progress multi-step form
  (e.g. halfway through creating a task) resets and they re-enter it — mildly
  annoying, never data-losing, since nothing is written to Postgres until a
  wizard actually completes.
- **Uploaded Telegram attachments**: stored by Telegram itself
  (`telegram_file_id` is what's kept in `task_attachments`), not re-hosted
  by this application, so there is nothing additional to back up for them
  as long as the bot's Telegram account and the original chat still exist.

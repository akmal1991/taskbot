# VPS Setup Without Docker (Ubuntu)

Tested target: a small VPS (1 vCPU / 1GB RAM / 20GB NVMe is enough for this
workload). Run every command below over SSH as root (or with `sudo`).

## 0. Swap (recommended on a 1GB-RAM box)

Postgres + Redis + Python can get tight on 1GB. A 1GB swap file is cheap
insurance against an out-of-memory kill during a burst (e.g. an Excel
export of a large register):

```bash
fallocate -l 1G /swapfile
chmod 600 /swapfile
mkswap /swapfile
swapon /swapfile
echo '/swapfile none swap sw 0 0' >> /etc/fstab
```

## 1. System packages

```bash
apt update && apt upgrade -y
apt install -y python3.13 python3.13-venv python3-pip \
    postgresql postgresql-contrib redis-server \
    build-essential libpq-dev git

# If Ubuntu's default repo doesn't have Python 3.13 (older Ubuntu releases):
#   add-apt-repository ppa:deadsnakes/ppa && apt update
# then run the install line above again.
```

## 2. PostgreSQL: create the database and user

```bash
sudo -u postgres psql <<'SQL'
CREATE USER uni_task_bot WITH PASSWORD 'CHANGE_ME_STRONG_PASSWORD';
CREATE DATABASE uni_task_bot OWNER uni_task_bot;
SQL
```

## 3. Redis: confirm it's running

```bash
systemctl enable --now redis-server
redis-cli ping   # should print PONG
```

## 4. Create a dedicated, unprivileged user for the app

```bash
useradd --system --create-home --shell /bin/bash uni_task_bot
mkdir -p /opt/uni_task_bot
chown uni_task_bot:uni_task_bot /opt/uni_task_bot
```

## 5. Get the code onto the server

From your own machine (where you extracted the tarball I sent):

```bash
scp -r uni_task_bot/* root@YOUR_SERVER_IP:/opt/uni_task_bot/
```

(or `git clone` if you've pushed it to a repo instead.)

Then on the server:

```bash
chown -R uni_task_bot:uni_task_bot /opt/uni_task_bot
```

## 6. Python environment

```bash
su - uni_task_bot
cd /opt/uni_task_bot
python3.13 -m venv .venv
.venv/bin/pip install -r requirements.txt
```

## 7. Configure `.env`

```bash
cp .env.example .env
nano .env
```

Set at minimum:
- `BOT_TOKEN` — your real token from @BotFather
- `DATABASE_URL=postgresql+asyncpg://uni_task_bot:CHANGE_ME_STRONG_PASSWORD@localhost:5432/uni_task_bot`
- `REDIS_URL=redis://localhost:6379/0`
- `WEB_SECRET_KEY` — generate with `python3 -c "import secrets; print(secrets.token_urlsafe(48))"`
- `WEB_BASE_URL` — `http://YOUR_SERVER_IP:8080` to start (add a real domain + TLS later if you want `/weblogin` links to look nicer — see note at the bottom)
- `BOOTSTRAP_SUPER_ADMIN_TELEGRAM_ID` — your numeric Telegram ID

## 8. Apply database migrations

```bash
.venv/bin/alembic upgrade head
exit   # back to root
```

## 9. Install as systemd services (so it survives reboots/disconnects)

```bash
cp /opt/uni_task_bot/scripts/systemd/uni-task-bot.service /etc/systemd/system/
cp /opt/uni_task_bot/scripts/systemd/uni-task-bot-web.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now uni-task-bot
systemctl enable --now uni-task-bot-web
```

## 10. Check it's actually running

```bash
systemctl status uni-task-bot        # should say "active (running)"
journalctl -u uni-task-bot -f        # live logs — look for the scheduler
                                      # starting and no exceptions
curl -I http://localhost:8080/login  # should return "200 OK"
```

Then, from Telegram, send `/start` to your bot and confirm you're
auto-approved as Super Administrator.

## Opening the dashboard port to the outside world

By default most VPS providers only open 22 (SSH). To reach the dashboard
from your browser at `http://YOUR_SERVER_IP:8080`:

```bash
ufw allow 22/tcp
ufw allow 8080/tcp
ufw enable
```

(If the provider also has its own firewall/security-group panel, open port
8080 there too.)

## Updating later

```bash
su - uni_task_bot
cd /opt/uni_task_bot
# replace changed files (scp new ones over, or git pull)
.venv/bin/pip install -r requirements.txt   # if dependencies changed
.venv/bin/alembic upgrade head              # applies any new migrations
exit
systemctl restart uni-task-bot uni-task-bot-web
```

## Optional: a real domain + HTTPS for the dashboard

`http://YOUR_SERVER_IP:8080` works but isn't encrypted and looks like an IP
address in the `/weblogin` link people get on Telegram. If you later point
a domain at this server, put `nginx` + `certbot` (Let's Encrypt) in front
of port 8080 as a reverse proxy, and update `WEB_BASE_URL` to the `https://`
domain. This is a standard nginx+certbot setup, not specific to this
project — ask if you want the exact nginx config for it.

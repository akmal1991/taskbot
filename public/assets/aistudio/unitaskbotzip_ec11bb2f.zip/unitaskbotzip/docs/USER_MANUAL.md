# User Manual

Everything is done through Telegram buttons and guided, step-by-step forms
— no commands to memorize beyond `/start` (register / open the main menu),
`/help`, `/mytasks` (jump straight to your task list), and `/weblogin`
(get a web-dashboard link, for roles that have dashboard access).

## Getting an account

Send `/start` to the bot. If this is your first time, you'll be asked for
your full name, phone number (or `-` to skip), department, and the role
you're requesting. A Super Administrator then approves or rejects the
request — you'll get a message either way. Until approved, the bot won't
show you the main menu.

## Main menu

What you see depends on your role. Everyone gets:

- **Mening vazifalarim (My Tasks)** — tasks assigned to you
- **Hisobotlar (Reports)** — a summary; managers also get the full Excel
  register attached

Managers (Super Admin / Rector / Vice-Rector / Department Head) additionally get:

- **Men tayinlagan vazifalar (Tasks Assigned by Me)**
- **Bo'lim vazifalari (Department Tasks)**
- **Yangi vazifa yaratish (Create New Task)**
- **Tasdiqlashni kutayotganlar (Pending Approvals)** — tasks waiting for
  your sign-off, because you're the one who assigned them
- **Muddati o'tganlar (Overdue Tasks)**

Super Administrator also gets **Foydalanuvchilarni boshqarish (User
Management)** to approve/reject registrations.

## Creating a task (managers)

Tap **Yangi vazifa yaratish** and answer the prompts in order: title,
description, expected outcome / acceptance criteria, source reference (who
asked for this — a meeting, a letter, a directive), department, the
specific person responsible, priority (Critical/High/Medium/Low), and
deadline (`dd.mm.yyyy`, or `-` for none). The task gets a permanent code
like `T-2026-0001` and a notification is queued for the responsible person.
The delivery worker runs every two minutes.

## Working your own tasks

Open a task from **Mening vazifalarim** to see its card and the buttons
valid for its current state:

- **Qabul qilish (Acknowledge)** — confirm you've seen it
- **Jarayonni yangilash (Update Progress)** — enter 0–100%; this also
  implicitly starts the task if you hadn't tapped Acknowledge yet
- **Tasdiqlashga topshirish (Submit for Review)** — once your work is
  done, this sends it to whoever assigned the task for approval. **Setting
  progress to 100% does not finish the task by itself** — review and
  approval always are a separate, required step.
- **Tўxtatish (Block)** — if you're stuck, state the reason, what support
  you need, and a proposed resolution date; this is visible to your
  manager immediately
- Attach photos/documents any time as evidence — just send them to the
  bot; they're linked to your active task automatically if you only have
  one in progress or awaiting review, otherwise open the specific task
  card first and tap **Dalil biriktirish (Attach evidence)**, then send the
  file. This explicitly selects which task receives it.

Use `/cancel` to leave an unfinished form, `/start` to reopen the main menu,
and `/myid` to see your numeric Telegram ID. All bot interactions are private
chat only; do not invoke login commands in groups.

## Approving or returning a task (whoever assigned it)

Open the task from **Tasdiqlashni kutayotganlar** once its responsible
employee submits it for review:

- **Tasdiqlash (Approve)** — marks it Completed, records today as the
  completion date
- **Qaytarish (Return for revision)** — state what's missing; the task
  goes back to In Progress for the employee to fix and resubmit

You can never approve a task you are the primary responsible person for,
even if you're also its assigner — the bot blocks that action.

## Reminders and escalation (what to expect)

- You'll get a reminder 7, 3, and 1 day(s) before a deadline, on the
  deadline date itself, and then once a day while it's overdue.
- If a task sits overdue, your department head is notified first; if it's
  still unresolved after a few more days, Vice-Rectors and then the
  Rector/Executive Director are looped in automatically. This isn't a
  punishment mechanism by itself — it's there so a stuck task doesn't sit
  silently forgotten.

## Changing your language

Main menu → **Sozlamalar (Settings)** → pick Uzbek (Cyrillic), Uzbek
(Latin), or Russian.

## The web dashboard

If your role has dashboard access (Super Admin, Rector, Observer,
Vice-Rector, Department Head), send `/weblogin` to the bot. You'll get a
link, valid for 10 minutes and usable once, that logs you straight into a
browser-based view with KPIs, filters by department/status/priority, and
an Excel download — no password to remember, because the link itself is
your credential for that one sign-in. If it expires before you click it,
just send `/weblogin` again for a new one.
